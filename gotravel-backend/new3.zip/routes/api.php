<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TravelController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Travel API Routes
Route::prefix('travels')->group(function () {
    Route::get('/', [TravelController::class, 'index']);           // GET /api/travels
    Route::post('/', [TravelController::class, 'store']);          // POST /api/travels
    Route::get('/cities', [TravelController::class, 'getCities']); // GET /api/travels/cities
    Route::get('/{id}', [TravelController::class, 'show']);        // GET /api/travels/{id}
    Route::put('/{id}', [TravelController::class, 'update']);      // PUT /api/travels/{id}
    Route::patch('/{id}', [TravelController::class, 'update']);    // PATCH /api/travels/{id}
    Route::delete('/{id}', [TravelController::class, 'destroy']);  // DELETE /api/travels/{id}
});

// Route untuk frontend Gotravel
Route::prefix('v1')->group(function () {
    Route::get('/travels/search', [TravelController::class, 'index']); // Compatible with frontend
});