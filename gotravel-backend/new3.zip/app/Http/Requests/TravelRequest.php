<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TravelRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $rules = [
            'agent_name' => 'required|string|max:100',
            'from_city' => 'required|string|max:50',
            'to_city' => 'required|string|max:50',
            'depart_time' => 'required|date_format:H:i',
            'arrival_time' => 'required|date_format:H:i|after:depart_time',
            'duration' => 'required|string|max:20',
            'price' => 'required|integer|min:0',
            'seats' => 'required|integer|min:1|max:20',
            'type' => 'required|in:Shuttle Car,Private Car',
            'rating' => 'nullable|numeric|min:0|max:5',
            'reviews' => 'nullable|integer|min:0',
            'facilities' => 'nullable|string',
            'image' => 'nullable|string|max:255',
            'description' => 'nullable|string',
        ];

        // For update, make fields sometimes required
        if ($this->isMethod('patch') || $this->isMethod('put')) {
            foreach ($rules as $field => $rule) {
                if ($field !== 'depart_time' && $field !== 'arrival_time') {
                    $rules[$field] = str_replace('required', 'sometimes|required', $rule);
                }
            }

            // Special rule for arrival_time in update
            if ($this->has('depart_time') || $this->has('arrival_time')) {
                $rules['arrival_time'] = 'sometimes|required|date_format:H:i|after:depart_time';
            }
        }

        return $rules;
    }

    /**
     * Custom validation messages
     */
    public function messages(): array
    {
        return [
            'arrival_time.after' => 'Waktu kedatangan harus setelah waktu keberangkatan.',
            'type.in' => 'Tipe harus Shuttle Car atau Private Car.',
            'price.min' => 'Harga tidak boleh negatif.',
            'seats.max' => 'Jumlah kursi maksimal 20.',
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation()
    {
        if ($this->has('facilities') && is_array($this->facilities)) {
            $this->merge([
                'facilities' => json_encode($this->facilities),
            ]);
        }
    }
}