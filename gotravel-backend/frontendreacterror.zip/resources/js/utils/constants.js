export const APP_NAME = 'MayTravel';
export const API_BASE_URL = '/api';

export const USER_ROLES = {
    USER: 'user',
    AGENT: 'agent',
    ADMIN: 'admin',
};

export const BOOKING_STATUS = {
    PENDING: 'pending',
    CONFIRMED: 'confirmed',
    CANCELLED: 'cancelled',
    COMPLETED: 'completed',
};

export const AGENT_STATUS = {
    PENDING: 'pending',
    APPROVED: 'approved',
    REJECTED: 'rejected',
};

