import api from './api';

export const agentService = {
    getStats: () => {
        return api.get('/agent/stats');
    },
    
    getBookings: () => {
        return api.get('/agent/bookings');
    },
    
    getTravels: () => {
        return api.get('/agent/travels');
    },
    
    getTravel: (id) => {
        return api.get(`/agent/travels/${id}`);
    },
    
    createTravel: (data) => {
        return api.post('/agent/travels', data);
    },
    
    updateTravel: (id, data) => {
        return api.put(`/agent/travels/${id}`, data);
    },
    
    deleteTravel: (id) => {
        return api.delete(`/agent/travels/${id}`);
    },
    
    createPickupLocation: (travelId, data) => {
        return api.post(`/agent/travels/${travelId}/pickup-locations`, data);
    },
    
    updatePickupLocation: (travelId, id, data) => {
        return api.put(`/agent/travels/${travelId}/pickup-locations/${id}`, data);
    },
    
    deletePickupLocation: (travelId, id) => {
        return api.delete(`/agent/travels/${travelId}/pickup-locations/${id}`);
    },
};

