import api from './api';

export const bookingService = {
    create: (data) => {
        return api.post('/bookings', data);
    },
    
    getAll: () => {
        return api.get('/bookings');
    },
    
    getById: (id) => {
        return api.get(`/bookings/${id}`);
    },
    
    updateStatus: (id, status) => {
        return api.patch(`/bookings/${id}/status`, { status });
    },
    
    cancel: (id) => {
        return api.delete(`/bookings/${id}`);
    },
};

