import api from './api';

export const adminService = {
    getDashboardStats: () => {
        return api.get('/admin/stats');
    },
    
    getAllUsers: () => {
        return api.get('/admin/users');
    },
    
    getAllAgents: () => {
        return api.get('/admin/agents');
    },
    
    getAllBookings: () => {
        return api.get('/admin/bookings');
    },
    
    updateAgentStatus: (id, status) => {
        return api.patch(`/admin/agents/${id}/status`, { status });
    },
    
    deleteUser: (id) => {
        return api.delete(`/admin/users/${id}`);
    },
};

