import api from './api';

export const authService = {
    login: (email, password, loginType = 'user') => {
        return api.post('/auth/login', { email, password, login_type: loginType });
    },
    
    register: (data) => {
        return api.post('/auth/register', data);
    },
    
    registerAgent: (data) => {
        return api.post('/auth/register-agent', data);
    },
    
    logout: () => {
        return api.post('/auth/logout');
    },
    
    me: () => {
        return api.get('/auth/me');
    },
};

