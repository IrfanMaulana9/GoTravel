import api from './api';

export const travelService = {
    getAll: (params = {}) => {
        return api.get('/travels', { params });
    },
    
    getById: (id) => {
        return api.get(`/travels/${id}`);
    },
    
    getCities: () => {
        return api.get('/travels/cities');
    },
    
    getPickupLocations: (travelId) => {
        return api.get(`/travels/${travelId}/pickup-locations`);
    },
};

