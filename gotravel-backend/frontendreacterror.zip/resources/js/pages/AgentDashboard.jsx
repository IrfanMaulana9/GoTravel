import React, { useState, useEffect } from "react";
import { agentService, bookingService } from "../services";
import { formatCurrency } from "../utils/helpers";
import Loading from "../components/Common/Loading";

const AgentDashboard = () => {
    const [stats, setStats] = useState(null);
    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [statsRes, bookingsRes] = await Promise.all([
                agentService.getStats(),
                agentService.getBookings(),
            ]);
            setStats(statsRes.data.data);
            setBookings(bookingsRes.data.data || []);
        } catch (error) {
            console.error("Error loading data:", error);
        } finally {
            setLoading(false);
        }
    };

    const handleStatusUpdate = async (id, status) => {
        try {
            await bookingService.updateStatus(id, status);
            loadData();
        } catch (error) {
            alert("Gagal mengupdate status");
        }
    };

    if (loading) return <Loading />;

    return (
        <div className="container my-5" style={{ paddingTop: "100px" }}>
            <h2 className="mb-4">Dashboard Agen</h2>

            {stats && (
                <div className="row mb-4">
                    <div className="col-md-3">
                        <div className="dashboard-card p-4 text-center">
                            <h3>{stats.total_bookings || 0}</h3>
                            <p>Total Booking</p>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="dashboard-card p-4 text-center">
                            <h3>{stats.pending_bookings || 0}</h3>
                            <p>Pending</p>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="dashboard-card p-4 text-center">
                            <h3>{stats.confirmed_bookings || 0}</h3>
                            <p>Confirmed</p>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="dashboard-card p-4 text-center">
                            <h3>{formatCurrency(stats.total_revenue || 0)}</h3>
                            <p>Total Revenue</p>
                        </div>
                    </div>
                </div>
            )}

            <div className="dashboard-card p-4">
                <h4 className="mb-4">Daftar Booking</h4>
                {bookings.length > 0 ? (
                    <div className="table-responsive">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Kode Booking</th>
                                    <th>Penumpang</th>
                                    <th>Tanggal</th>
                                    <th>Total Harga</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                {bookings.map((booking) => (
                                    <tr key={booking.id}>
                                        <td>{booking.booking_code}</td>
                                        <td>{booking.passenger_name}</td>
                                        <td>{booking.travel_date}</td>
                                        <td>
                                            {formatCurrency(
                                                booking.total_price
                                            )}
                                        </td>
                                        <td>
                                            <span
                                                className={`badge bg-${
                                                    booking.status ===
                                                    "confirmed"
                                                        ? "success"
                                                        : booking.status ===
                                                          "pending"
                                                        ? "warning"
                                                        : "danger"
                                                }`}
                                            >
                                                {booking.status}
                                            </span>
                                        </td>
                                        <td>
                                            {booking.status === "pending" && (
                                                <>
                                                    <button
                                                        className="btn btn-sm btn-success me-2"
                                                        onClick={() =>
                                                            handleStatusUpdate(
                                                                booking.id,
                                                                "confirmed"
                                                            )
                                                        }
                                                    >
                                                        Konfirmasi
                                                    </button>
                                                    <button
                                                        className="btn btn-sm btn-danger"
                                                        onClick={() =>
                                                            handleStatusUpdate(
                                                                booking.id,
                                                                "cancelled"
                                                            )
                                                        }
                                                    >
                                                        Tolak
                                                    </button>
                                                </>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <p>Belum ada booking</p>
                )}
            </div>
        </div>
    );
};

export default AgentDashboard;
