import React, { useState, useEffect } from 'react';
import { travelService, bookingService } from '../services';
import { formatCurrency, formatDate } from '../utils/helpers';
import Loading from '../components/Common/Loading';

const Booking = () => {
    const [cities, setCities] = useState([]);
    const [travels, setTravels] = useState([]);
    const [searchData, setSearchData] = useState({
        from: '',
        to: '',
        date: ''
    });
    const [selectedTravel, setSelectedTravel] = useState(null);
    const [bookingData, setBookingData] = useState({
        passenger_name: '',
        passenger_phone: '',
        passenger_email: '',
        seats_booked: 1
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    useEffect(() => {
        loadCities();
    }, []);

    const loadCities = async () => {
        try {
            const response = await travelService.getCities();
            setCities(response.data.data || []);
        } catch (error) {
            console.error('Error loading cities:', error);
        }
    };

    const handleSearch = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        try {
            const response = await travelService.getAll(searchData);
            setTravels(response.data.data || []);
        } catch (error) {
            setError('Gagal mencari travel');
        } finally {
            setLoading(false);
        }
    };

    const handleBooking = async (e) => {
        e.preventDefault();
        if (!selectedTravel) return;
        
        setLoading(true);
        setError('');
        try {
            const response = await bookingService.create({
                ...bookingData,
                travel_id: selectedTravel.id,
                travel_date: searchData.date
            });
            setSuccess('Booking berhasil!');
            setSelectedTravel(null);
            setBookingData({
                passenger_name: '',
                passenger_phone: '',
                passenger_email: '',
                seats_booked: 1
            });
        } catch (error) {
            setError(error.response?.data?.message || 'Booking gagal');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container my-5" style={{ paddingTop: '100px' }}>
            <h2 className="mb-4">Booking Travel</h2>
            
            {success && (
                <div className="alert alert-success" role="alert">
                    {success}
                </div>
            )}
            
            {error && (
                <div className="alert alert-danger" role="alert">
                    {error}
                </div>
            )}

            <div className="row">
                <div className="col-md-4">
                    <div className="dashboard-card p-4">
                        <h4 className="mb-3">Cari Perjalanan</h4>
                        <form onSubmit={handleSearch}>
                            <div className="mb-3">
                                <label className="form-label">Dari</label>
                                <select
                                    className="form-control"
                                    value={searchData.from}
                                    onChange={(e) => setSearchData({...searchData, from: e.target.value})}
                                    required
                                >
                                    <option value="">Pilih Kota</option>
                                    {cities.map(city => (
                                        <option key={city} value={city}>{city}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Ke</label>
                                <select
                                    className="form-control"
                                    value={searchData.to}
                                    onChange={(e) => setSearchData({...searchData, to: e.target.value})}
                                    required
                                >
                                    <option value="">Pilih Kota</option>
                                    {cities.map(city => (
                                        <option key={city} value={city}>{city}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Tanggal</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    value={searchData.date}
                                    onChange={(e) => setSearchData({...searchData, date: e.target.value})}
                                    required
                                />
                            </div>
                            <button type="submit" className="btn btn-primary w-100" disabled={loading}>
                                {loading ? 'Mencari...' : 'Cari'}
                            </button>
                        </form>
                    </div>
                </div>
                
                <div className="col-md-8">
                    {selectedTravel ? (
                        <div className="dashboard-card p-4">
                            <h4 className="mb-3">Form Booking</h4>
                            <form onSubmit={handleBooking}>
                                <div className="mb-3">
                                    <label className="form-label">Nama Penumpang</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        value={bookingData.passenger_name}
                                        onChange={(e) => setBookingData({...bookingData, passenger_name: e.target.value})}
                                        required
                                    />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Nomor Telepon</label>
                                    <input
                                        type="tel"
                                        className="form-control"
                                        value={bookingData.passenger_phone}
                                        onChange={(e) => setBookingData({...bookingData, passenger_phone: e.target.value})}
                                        required
                                    />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Email</label>
                                    <input
                                        type="email"
                                        className="form-control"
                                        value={bookingData.passenger_email}
                                        onChange={(e) => setBookingData({...bookingData, passenger_email: e.target.value})}
                                        required
                                    />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Jumlah Kursi</label>
                                    <input
                                        type="number"
                                        className="form-control"
                                        min="1"
                                        value={bookingData.seats_booked}
                                        onChange={(e) => setBookingData({...bookingData, seats_booked: parseInt(e.target.value)})}
                                        required
                                    />
                                </div>
                                <div className="mb-3">
                                    <p><strong>Total Harga:</strong> {formatCurrency(selectedTravel.price * bookingData.seats_booked)}</p>
                                </div>
                                <button type="submit" className="btn btn-primary" disabled={loading}>
                                    {loading ? 'Memproses...' : 'Booking Sekarang'}
                                </button>
                                <button 
                                    type="button" 
                                    className="btn btn-secondary ms-2"
                                    onClick={() => setSelectedTravel(null)}
                                >
                                    Batal
                                </button>
                            </form>
                        </div>
                    ) : (
                        <div>
                            {travels.length > 0 ? (
                                travels.map(travel => (
                                    <div key={travel.id} className="dashboard-card p-4 mb-3">
                                        <div className="d-flex justify-content-between align-items-start">
                                            <div>
                                                <h5>{travel.from_city} → {travel.to_city}</h5>
                                                <p className="mb-1"><i className="fas fa-clock me-2"></i>{travel.departure_time}</p>
                                                <p className="mb-1"><i className="fas fa-chair me-2"></i>Kursi Tersedia: {travel.seats_available}</p>
                                                <p className="mb-0"><strong>{formatCurrency(travel.price)}</strong></p>
                                            </div>
                                            <button 
                                                className="btn btn-primary"
                                                onClick={() => setSelectedTravel(travel)}
                                            >
                                                Pilih
                                            </button>
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <div className="dashboard-card p-4 text-center">
                                    <p>Silakan cari perjalanan terlebih dahulu</p>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Booking;

