import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Login = () => {
    const { login } = useAuth();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        login_type: 'user'
    });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        const result = await login(formData.email, formData.password, formData.login_type);
        
        if (result.success) {
            // Redirect based on user role
            if (result.user.is_admin) {
                navigate('/admin');
            } else if (result.user.is_agent) {
                navigate('/agent-dashboard');
            } else {
                navigate('/user-dashboard');
            }
        } else {
            setError(result.message || 'Login gagal');
        }
        
        setLoading(false);
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    return (
        <div className="login-container" style={{
            background: 'linear-gradient(135deg, var(--primary-blue) 0%, var(--secondary-blue) 100%)',
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '2rem 0'
        }}>
            <div className="login-card" style={{
                background: 'white',
                borderRadius: '20px',
                boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
                overflow: 'hidden',
                maxWidth: '400px',
                width: '100%'
            }}>
                <div className="login-header" style={{
                    background: 'linear-gradient(135deg, var(--primary-blue), var(--secondary-blue))',
                    color: 'white',
                    padding: '2rem',
                    textAlign: 'center'
                }}>
                    <h2><i className="fas fa-sign-in-alt me-2"></i>Login</h2>
                </div>
                <div className="login-body" style={{ padding: '2rem' }}>
                    {error && (
                        <div className="alert alert-danger" role="alert">
                            {error}
                        </div>
                    )}
                    <form onSubmit={handleSubmit}>
                        <div className="mb-3">
                            <label className="form-label">Tipe Login</label>
                            <select 
                                className="form-control"
                                name="login_type"
                                value={formData.login_type}
                                onChange={handleChange}
                            >
                                <option value="user">User</option>
                                <option value="agent">Agent</option>
                            </select>
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Email</label>
                            <input
                                type="email"
                                className="form-control"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Password</label>
                            <input
                                type="password"
                                className="form-control"
                                name="password"
                                value={formData.password}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <button 
                            type="submit" 
                            className="btn btn-primary w-100"
                            disabled={loading}
                            style={{
                                background: 'linear-gradient(135deg, var(--primary-blue), var(--secondary-blue))',
                                border: 'none',
                                borderRadius: '10px',
                                padding: '0.75rem',
                                fontWeight: '600',
                                transition: 'all 0.3s ease',
                                width: '100%'
                            }}
                        >
                            {loading ? 'Loading...' : 'Login'}
                        </button>
                    </form>
                    <div className="mt-3 text-center">
                        <p>Belum punya akun? <Link to="/register">Daftar di sini</Link></p>
                        <p><Link to="/agent-registration">Daftar sebagai Agen</Link></p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;

