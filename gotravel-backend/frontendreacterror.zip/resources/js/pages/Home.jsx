import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Home = () => {
    const { isAuthenticated, user } = useAuth();
    const [stats, setStats] = useState({
        agents: 0,
        users: 0,
        bookings: 0,
        cities: 50
    });

    useEffect(() => {
        // Animate counters when component mounts
        const animateCounters = () => {
            const counters = document.querySelectorAll('.stat-number');
            counters.forEach(counter => {
                const target = parseInt(counter.getAttribute('data-count') || counter.textContent || 0);
                if (target === 0) return;
                
                const duration = 2000;
                const step = target / (duration / 16);
                let current = 0;
                
                const timer = setInterval(() => {
                    current += step;
                    if (current >= target) {
                        current = target;
                        clearInterval(timer);
                    }
                    counter.textContent = Math.floor(current);
                }, 16);
            });
        };

        // Delay animation slightly
        setTimeout(animateCounters, 500);
    }, []);

    return (
        <>
            {/* Hero Section */}
            <section className="hero-section" id="home" style={{ paddingTop: '80px' }}>
                <div className="floating-element">
                    <i className="fas fa-bus fa-3x" style={{color: 'rgba(255,255,255,0.1)'}}></i>
                </div>
                <div className="floating-element">
                    <i className="fas fa-map-marker-alt fa-2x" style={{color: 'rgba(255,255,255,0.1)'}}></i>
                </div>
                <div className="floating-element">
                    <i className="fas fa-ticket-alt fa-2x" style={{color: 'rgba(255,255,255,0.1)'}}></i>
                </div>
                
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-6 hero-content">
                            <h1 className="hero-title">
                                Jelajahi Indonesia dengan <span className="text-warning">MayTravel</span>
                            </h1>
                            <p className="hero-subtitle">
                                Platform travel terpercaya yang menghubungkan Anda dengan agen travel terbaik di seluruh Indonesia. Nikmati perjalanan yang aman, nyaman, dan terjangkau.
                            </p>
                            {isAuthenticated ? (
                                <Link to="/booking" className="hero-btn">
                                    <i className="fas fa-search me-2"></i>Cari Perjalanan
                                </Link>
                            ) : (
                                <Link to="/register" className="hero-btn">
                                    <i className="fas fa-rocket me-2"></i>Mulai Perjalanan
                                </Link>
                            )}
                        </div>
                        <div className="col-lg-6 text-center">
                            <div className="hero-image">
                                <i className="fas fa-map fa-10x pulse" style={{color: 'rgba(255,255,255,0.2)'}}></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div className="scroll-indicator">
                    <i className="fas fa-chevron-down fa-2x"></i>
                </div>
            </section>

            {/* Stats Section */}
            <section className="stats-section">
                <div className="container">
                    <div className="row g-4">
                        <div className="col-lg-3 col-md-6">
                            <div className="stat-card loading">
                                <div className="stat-number" data-count={stats.agents}>0</div>
                                <div className="stat-label">Agen Terpercaya</div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <div className="stat-card loading">
                                <div className="stat-number" data-count={stats.users}>0</div>
                                <div className="stat-label">Pengguna Aktif</div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <div className="stat-card loading">
                                <div className="stat-number" data-count={stats.bookings}>0</div>
                                <div className="stat-label">Perjalanan Sukses</div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <div className="stat-card loading">
                                <div className="stat-number" data-count={stats.cities}>0</div>
                                <div className="stat-label">Kota Tujuan</div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Features Section */}
            <section className="features-section" id="features">
                <div className="container">
                    <h2 className="section-title">Mengapa Memilih MayTravel?</h2>
                    
                    <div className="row g-4">
                        <div className="col-lg-4 col-md-6">
                            <div className="feature-card">
                                <div className="feature-icon">
                                    <i className="fas fa-shield-alt"></i>
                                </div>
                                <h3 className="feature-title">Aman & Terpercaya</h3>
                                <p className="feature-description">
                                    Semua agen travel telah terverifikasi dan memiliki izin resmi. Keamanan perjalanan Anda adalah prioritas utama kami.
                                </p>
                            </div>
                        </div>
                        
                        <div className="col-lg-4 col-md-6">
                            <div className="feature-card">
                                <div className="feature-icon">
                                    <i className="fas fa-money-bill-wave"></i>
                                </div>
                                <h3 className="feature-title">Harga Transparan</h3>
                                <p className="feature-description">
                                    Bandingkan harga dari berbagai agen travel secara real-time. Tidak ada biaya tersembunyi, semua transparan.
                                </p>
                            </div>
                        </div>
                        
                        <div className="col-lg-4 col-md-6">
                            <div className="feature-card">
                                <div className="feature-icon">
                                    <i className="fas fa-clock"></i>
                                </div>
                                <h3 className="feature-title">Booking Instan</h3>
                                <p className="feature-description">
                                    Proses booking yang cepat dan mudah. Konfirmasi langsung tanpa perlu menunggu lama.
                                </p>
                            </div>
                        </div>
                        
                        <div className="col-lg-4 col-md-6">
                            <div className="feature-card">
                                <div className="feature-icon">
                                    <i className="fas fa-headset"></i>
                                </div>
                                <h3 className="feature-title">Support 24/7</h3>
                                <p className="feature-description">
                                    Tim customer service kami siap membantu Anda kapan saja. Hubungi kami melalui berbagai channel komunikasi.
                                </p>
                            </div>
                        </div>
                        
                        <div className="col-lg-4 col-md-6">
                            <div className="feature-card">
                                <div className="feature-icon">
                                    <i className="fas fa-mobile-alt"></i>
                                </div>
                                <h3 className="feature-title">Mobile Friendly</h3>
                                <p className="feature-description">
                                    Akses platform kami dari mana saja menggunakan smartphone. Interface yang responsif dan user-friendly.
                                </p>
                            </div>
                        </div>
                        
                        <div className="col-lg-4 col-md-6">
                            <div className="feature-card">
                                <div className="feature-icon">
                                    <i className="fas fa-route"></i>
                                </div>
                                <h3 className="feature-title">Rute Lengkap</h3>
                                <p className="feature-description">
                                    Jangkauan ke seluruh Indonesia dengan berbagai pilihan rute dan jadwal keberangkatan yang fleksibel.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="cta-section">
                <div className="container">
                    <div className="cta-content">
                        <h2 className="cta-title">Siap Memulai Perjalanan Anda?</h2>
                        <p className="cta-subtitle">
                            Bergabunglah dengan ribuan traveler yang telah mempercayai MayTravel untuk perjalanan mereka.
                        </p>
                        <div className="cta-buttons">
                            {!isAuthenticated ? (
                                <>
                                    <Link to="/register" className="cta-btn cta-btn-primary">
                                        <i className="fas fa-user-plus me-2"></i>Daftar Sekarang
                                    </Link>
                                    <Link to="/agent-registration" className="cta-btn cta-btn-secondary">
                                        <i className="fas fa-building me-2"></i>Daftar Sebagai Agen
                                    </Link>
                                </>
                            ) : (
                                <Link 
                                    to={user?.is_agent ? '/agent-dashboard' : '/booking'} 
                                    className="cta-btn cta-btn-primary"
                                >
                                    <i className="fas fa-rocket me-2"></i>Mulai Sekarang
                                </Link>
                            )}
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
};

export default Home;
