import React, { useState, useEffect } from 'react';
import { adminService } from '../../services';
import { formatCurrency, formatDate } from '../../utils/helpers';
import Loading from '../../components/Common/Loading';

const AdminBookings = () => {
    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadBookings();
    }, []);

    const loadBookings = async () => {
        try {
            const response = await adminService.getAllBookings();
            setBookings(response.data.data || []);
        } catch (error) {
            console.error('Error loading bookings:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <Loading />;

    return (
        <div className="container my-5" style={{ paddingTop: '100px' }}>
            <h2 className="mb-4">Manajemen Bookings</h2>
            
            <div className="dashboard-card p-4">
                <div className="table-responsive">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Kode Booking</th>
                                <th>Penumpang</th>
                                <th>Rute</th>
                                <th>Tanggal</th>
                                <th>Total Harga</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {bookings.map(booking => (
                                <tr key={booking.id}>
                                    <td>{booking.booking_code}</td>
                                    <td>{booking.passenger_name}</td>
                                    <td>{booking.travel?.from_city} → {booking.travel?.to_city}</td>
                                    <td>{formatDate(booking.travel_date)}</td>
                                    <td>{formatCurrency(booking.total_price)}</td>
                                    <td>
                                        <span className={`badge bg-${booking.status === 'confirmed' ? 'success' : booking.status === 'pending' ? 'warning' : 'danger'}`}>
                                            {booking.status}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default AdminBookings;

