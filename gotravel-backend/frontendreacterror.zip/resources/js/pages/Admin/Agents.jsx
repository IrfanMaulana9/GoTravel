import React, { useState, useEffect } from 'react';
import { adminService } from '../../services';
import Loading from '../../components/Common/Loading';

const AdminAgents = () => {
    const [agents, setAgents] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadAgents();
    }, []);

    const loadAgents = async () => {
        try {
            const response = await adminService.getAllAgents();
            setAgents(response.data.data || []);
        } catch (error) {
            console.error('Error loading agents:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleStatusUpdate = async (id, status) => {
        try {
            await adminService.updateAgentStatus(id, status);
            loadAgents();
        } catch (error) {
            alert('Gagal mengupdate status');
        }
    };

    if (loading) return <Loading />;

    return (
        <div className="container my-5" style={{ paddingTop: '100px' }}>
            <h2 className="mb-4">Manajemen Agents</h2>
            
            <div className="dashboard-card p-4">
                <div className="table-responsive">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Perusahaan</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            {agents.map(agent => (
                                <tr key={agent.id}>
                                    <td>{agent.name}</td>
                                    <td>{agent.email}</td>
                                    <td>{agent.company_name}</td>
                                    <td>
                                        <span className={`badge bg-${agent.status === 'approved' ? 'success' : agent.status === 'pending' ? 'warning' : 'danger'}`}>
                                            {agent.status}
                                        </span>
                                    </td>
                                    <td>
                                        {agent.status === 'pending' && (
                                            <>
                                                <button 
                                                    className="btn btn-sm btn-success me-2"
                                                    onClick={() => handleStatusUpdate(agent.id, 'approved')}
                                                >
                                                    Approve
                                                </button>
                                                <button 
                                                    className="btn btn-sm btn-danger"
                                                    onClick={() => handleStatusUpdate(agent.id, 'rejected')}
                                                >
                                                    Reject
                                                </button>
                                            </>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default AdminAgents;

