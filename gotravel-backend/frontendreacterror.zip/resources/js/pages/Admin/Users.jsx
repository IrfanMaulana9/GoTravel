import React, { useState, useEffect } from 'react';
import { adminService } from '../../services';
import Loading from '../../components/Common/Loading';

const AdminUsers = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadUsers();
    }, []);

    const loadUsers = async () => {
        try {
            const response = await adminService.getAllUsers();
            setUsers(response.data.data || []);
        } catch (error) {
            console.error('Error loading users:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Apakah Anda yakin ingin menghapus user ini?')) return;
        
        try {
            await adminService.deleteUser(id);
            loadUsers();
        } catch (error) {
            alert('Gagal menghapus user');
        }
    };

    if (loading) return <Loading />;

    return (
        <div className="container my-5" style={{ paddingTop: '100px' }}>
            <h2 className="mb-4">Manajemen Users</h2>
            
            <div className="dashboard-card p-4">
                <div className="table-responsive">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map(user => (
                                <tr key={user.id}>
                                    <td>{user.name}</td>
                                    <td>{user.email}</td>
                                    <td>
                                        <span className="badge bg-info">
                                            {user.is_admin ? 'Admin' : user.is_agent ? 'Agent' : 'User'}
                                        </span>
                                    </td>
                                    <td>
                                        <button 
                                            className="btn btn-sm btn-danger"
                                            onClick={() => handleDelete(user.id)}
                                        >
                                            Hapus
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default AdminUsers;

