import React, { useState, useEffect } from 'react';
import { adminService } from '../../services';
import Loading from '../../components/Common/Loading';

const AdminDashboard = () => {
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadStats();
    }, []);

    const loadStats = async () => {
        try {
            const response = await adminService.getDashboardStats();
            setStats(response.data.data);
        } catch (error) {
            console.error('Error loading stats:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <Loading />;

    return (
        <div className="container my-5" style={{ paddingTop: '100px' }}>
            <h2 className="mb-4">Admin Dashboard</h2>
            
            {stats && (
                <div className="row mb-4">
                    <div className="col-md-3">
                        <div className="dashboard-card p-4 text-center">
                            <h3>{stats.total_users || 0}</h3>
                            <p>Total Users</p>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="dashboard-card p-4 text-center">
                            <h3>{stats.total_agents || 0}</h3>
                            <p>Total Agents</p>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="dashboard-card p-4 text-center">
                            <h3>{stats.pending_agents || 0}</h3>
                            <p>Pending Agents</p>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="dashboard-card p-4 text-center">
                            <h3>{stats.total_bookings || 0}</h3>
                            <p>Total Bookings</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdminDashboard;

