import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Register = () => {
    const { register } = useAuth();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        password_confirmation: ''
    });
    const [error, setError] = useState('');
    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setErrors({});
        setLoading(true);

        const result = await register(formData);
        
        if (result.success) {
            navigate('/login');
        } else {
            setError(result.message || 'Registrasi gagal');
            if (result.errors) {
                setErrors(result.errors);
            }
        }
        
        setLoading(false);
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    return (
        <div className="login-container" style={{
            background: 'linear-gradient(135deg, var(--primary-blue) 0%, var(--secondary-blue) 100%)',
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '2rem 0'
        }}>
            <div className="login-card" style={{
                background: 'white',
                borderRadius: '20px',
                boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
                overflow: 'hidden',
                maxWidth: '500px',
                width: '100%'
            }}>
                <div className="login-header" style={{
                    background: 'linear-gradient(135deg, var(--primary-blue), var(--secondary-blue))',
                    color: 'white',
                    padding: '2rem',
                    textAlign: 'center'
                }}>
                    <h2><i className="fas fa-user-plus me-2"></i>Registrasi</h2>
                </div>
                <div className="login-body" style={{ padding: '2rem' }}>
                    {error && (
                        <div className="alert alert-danger" role="alert">
                            {error}
                        </div>
                    )}
                    <form onSubmit={handleSubmit}>
                        <div className="mb-3">
                            <label className="form-label">Nama Lengkap</label>
                            <input
                                type="text"
                                className="form-control"
                                name="name"
                                value={formData.name}
                                onChange={handleChange}
                                required
                            />
                            {errors.name && <div className="text-danger small">{errors.name[0]}</div>}
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Email</label>
                            <input
                                type="email"
                                className="form-control"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                required
                            />
                            {errors.email && <div className="text-danger small">{errors.email[0]}</div>}
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Password</label>
                            <input
                                type="password"
                                className="form-control"
                                name="password"
                                value={formData.password}
                                onChange={handleChange}
                                required
                            />
                            {errors.password && <div className="text-danger small">{errors.password[0]}</div>}
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Konfirmasi Password</label>
                            <input
                                type="password"
                                className="form-control"
                                name="password_confirmation"
                                value={formData.password_confirmation}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <button 
                            type="submit" 
                            className="btn btn-primary w-100"
                            disabled={loading}
                            style={{
                                background: 'linear-gradient(135deg, var(--primary-blue), var(--secondary-blue))',
                                border: 'none',
                                borderRadius: '10px',
                                padding: '0.75rem',
                                fontWeight: '600',
                                transition: 'all 0.3s ease',
                                width: '100%'
                            }}
                        >
                            {loading ? 'Loading...' : 'Daftar'}
                        </button>
                    </form>
                    <div className="mt-3 text-center">
                        <p>Sudah punya akun? <Link to="/login">Login di sini</Link></p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Register;

