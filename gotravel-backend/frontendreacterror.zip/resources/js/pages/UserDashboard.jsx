import React, { useState, useEffect } from 'react';
import { bookingService } from '../services';
import { formatCurrency, formatDate } from '../utils/helpers';
import Loading from '../components/Common/Loading';

const UserDashboard = () => {
    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadBookings();
    }, []);

    const loadBookings = async () => {
        try {
            const response = await bookingService.getAll();
            setBookings(response.data.data || []);
        } catch (error) {
            console.error('Error loading bookings:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleCancel = async (id) => {
        if (!window.confirm('Apakah Anda yakin ingin membatalkan booking ini?')) return;
        
        try {
            await bookingService.cancel(id);
            loadBookings();
        } catch (error) {
            alert('Gagal membatalkan booking');
        }
    };

    if (loading) return <Loading />;

    return (
        <div className="container my-5" style={{ paddingTop: '100px' }}>
            <h2 className="mb-4">Dashboard Pengguna</h2>
            
            <div className="dashboard-card p-4">
                <h4 className="mb-4">Riwayat Booking</h4>
                {bookings.length > 0 ? (
                    <div className="table-responsive">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Kode Booking</th>
                                    <th>Rute</th>
                                    <th>Tanggal</th>
                                    <th>Jumlah Kursi</th>
                                    <th>Total Harga</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                {bookings.map(booking => (
                                    <tr key={booking.id}>
                                        <td>{booking.booking_code}</td>
                                        <td>{booking.travel?.from_city} → {booking.travel?.to_city}</td>
                                        <td>{formatDate(booking.travel_date)}</td>
                                        <td>{booking.seats_booked}</td>
                                        <td>{formatCurrency(booking.total_price)}</td>
                                        <td>
                                            <span className={`badge bg-${booking.status === 'confirmed' ? 'success' : booking.status === 'pending' ? 'warning' : 'danger'}`}>
                                                {booking.status}
                                            </span>
                                        </td>
                                        <td>
                                            {booking.status === 'pending' && (
                                                <button 
                                                    className="btn btn-sm btn-danger"
                                                    onClick={() => handleCancel(booking.id)}
                                                >
                                                    Batal
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <p>Belum ada booking</p>
                )}
            </div>
        </div>
    );
};

export default UserDashboard;

