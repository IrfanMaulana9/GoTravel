import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

const Navbar = () => {
    const { isAuthenticated, user, logout, getUserRole } = useAuth();
    const navigate = useNavigate();
    const [scrolled, setScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    const userRole = getUserRole();

    return (
        <nav className={`navbar navbar-expand-lg fixed-top ${scrolled ? 'scrolled' : ''}`} id="mainNavbar">
            <div className="container">
                <Link className="navbar-brand" to="/">
                    <i className="fas fa-car me-2"></i>MayTravel
                </Link>
                
                <button 
                    className="navbar-toggler" 
                    type="button" 
                    data-bs-toggle="collapse" 
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>
                
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav ms-auto">
                        <li className="nav-item">
                            <Link className="nav-link" to="/#home">Beranda</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/#features">Fitur</Link>
                        </li>
                        {isAuthenticated ? (
                            <>
                                {userRole === 'user' && (
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/user-dashboard">
                                            <i className="fas fa-user me-1"></i>Dashboard
                                        </Link>
                                    </li>
                                )}
                                {userRole === 'agent' && (
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/agent-dashboard">
                                            <i className="fas fa-building me-1"></i>Dashboard
                                        </Link>
                                    </li>
                                )}
                                {userRole === 'admin' && (
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/admin">
                                            <i className="fas fa-user-shield me-1"></i>Admin
                                        </Link>
                                    </li>
                                )}
                                <li className="nav-item">
                                    <button className="nav-link btn-link" onClick={handleLogout} style={{ background: 'none', border: 'none' }}>
                                        Logout
                                    </button>
                                </li>
                            </>
                        ) : (
                            <>
                                <li className="nav-item">
                                    <Link className="nav-link" to="/login">
                                        <i className="fas fa-sign-in-alt me-1"></i>Login
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link" to="/agent-registration">Daftar Agen</Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link" to="/admin">
                                        <i className="fas fa-user-shield me-1"></i>Admin
                                    </Link>
                                </li>
                            </>
                        )}
                    </ul>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;

