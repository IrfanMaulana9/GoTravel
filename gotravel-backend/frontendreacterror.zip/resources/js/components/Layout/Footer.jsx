import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
    return (
        <footer className="footer">
            <div className="container">
                <div className="footer-content">
                    <div className="footer-section">
                        <h5><i className="fas fa-route me-2"></i>MayTravel</h5>
                        <p>Platform travel terpercaya yang menghubungkan Anda dengan agen travel terbaik di Indonesia.</p>
                        <div className="social-icons">
                            <a href="#" className="social-icon"><i className="fab fa-facebook-f"></i></a>
                            <a href="#" className="social-icon"><i className="fab fa-twitter"></i></a>
                            <a href="#" className="social-icon"><i className="fab fa-instagram"></i></a>
                            <a href="#" className="social-icon"><i className="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    
                    <div className="footer-section">
                        <h5>Layanan</h5>
                        <ul className="list-unstyled">
                            <li><Link to="/booking">Booking Travel</Link></li>
                            <li><Link to="/agent-registration">Daftar Agen</Link></li>
                            <li><a href="#">Travel Insurance</a></li>
                            <li><a href="#">Customer Support</a></li>
                        </ul>
                    </div>
                    
                    <div className="footer-section">
                        <h5>Perusahaan</h5>
                        <ul className="list-unstyled">
                            <li><a href="#">Tentang Kami</a></li>
                            <li><a href="#">Karir</a></li>
                            <li><a href="#">Press Release</a></li>
                            <li><a href="#">Partnership</a></li>
                        </ul>
                    </div>
                    
                    <div className="footer-section">
                        <h5>Bantuan</h5>
                        <ul className="list-unstyled">
                            <li><a href="#">Pusat Bantuan</a></li>
                            <li><a href="#">FAQ</a></li>
                            <li><a href="#">Syarat & Ketentuan</a></li>
                            <li><a href="#">Kebijakan Privasi</a></li>
                        </ul>
                    </div>
                </div>
                
                <div className="footer-bottom">
                    <p>&copy; 2024 MayTravel. Semua hak cipta dilindungi undang-undang.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;

