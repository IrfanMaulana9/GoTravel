<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TravelController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AgentController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\PickupLocationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

Route::prefix('auth')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/register-agent', [AuthController::class, 'registerAgent']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:api');
    Route::get('/me', [AuthController::class, 'me'])->middleware('auth:api');
});

Route::prefix('travels')->group(function () {
    Route::get('/', [TravelController::class, 'index']);
    Route::get('/cities', [TravelController::class, 'getCities']);
    Route::get('/{id}', [TravelController::class, 'show']);
    Route::get('/{id}/pickup-locations', [PickupLocationController::class, 'index']);
});

Route::middleware(['auth:api', 'agent'])->prefix('agent')->group(function () {
    // Statistics
    Route::get('/stats', [AgentController::class, 'getStats']);
    Route::get('/bookings', [AgentController::class, 'getBookings']);

    // Travel management
    Route::get('/travels', [AgentController::class, 'getTravels']);
    Route::get('/travels/{id}', [AgentController::class, 'getTravel']);
    Route::post('/travels', [AgentController::class, 'createTravel']);
    Route::put('/travels/{id}', [AgentController::class, 'updateTravel']);
    Route::delete('/travels/{id}', [AgentController::class, 'deleteTravel']);

    // Pickup location management for agent's travels
    Route::post('/travels/{travelId}/pickup-locations', [PickupLocationController::class, 'store']);
    Route::get('/travels/{travelId}/pickup-locations/{id}', [PickupLocationController::class, 'show']);
    Route::put('/travels/{travelId}/pickup-locations/{id}', [PickupLocationController::class, 'update']);
    Route::delete('/travels/{travelId}/pickup-locations/{id}', [PickupLocationController::class, 'destroy']);
});

Route::middleware(['auth:api', 'admin'])->prefix('admin')->group(function () {
    Route::get('/stats', [AdminController::class, 'getDashboardStats']);
    Route::get('/users', [AdminController::class, 'getAllUsers']);
    Route::get('/agents', [AdminController::class, 'getAllAgents']);
    Route::get('/bookings', [AdminController::class, 'getAllBookings']);
    Route::patch('/agents/{id}/status', [AdminController::class, 'updateAgentStatus']);
    Route::delete('/users/{id}', [AdminController::class, 'deleteUser']);
});

Route::middleware('auth:api')->prefix('bookings')->group(function () {
    Route::post('/', [BookingController::class, 'store']);
    Route::get('/', [BookingController::class, 'index']);
    Route::get('/{id}', [BookingController::class, 'show']);
    Route::patch('/{id}/status', [BookingController::class, 'updateStatus']);
    Route::delete('/{id}', [BookingController::class, 'cancel']);
});

Route::prefix('geocode')->group(function () {
    Route::post('/search', [PickupLocationController::class, 'geocode']);
    Route::post('/reverse', [PickupLocationController::class, 'reverseGeocode']);
});

Route::prefix('v1')->group(function () {
    Route::get('/travels/search', [TravelController::class, 'index']);
});
