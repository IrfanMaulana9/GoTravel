<?php

use Illuminate\Support\Facades\Route;

// Serve React SPA for all routes (except API routes and Vite assets)
// Vite assets are handled automatically by Laravel Vite plugin
Route::get('/{any}', function () {
    return view('welcome');
})->where('any', '^(?!api|build|storage|@vite).*$');
