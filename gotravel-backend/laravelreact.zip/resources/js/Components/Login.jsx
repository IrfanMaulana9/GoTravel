"use client"

import { useState } from "react"
import { Car, Eye, EyeOff } from "lucide-react"

export default function Login({ onNavigate, setUser }) {
  const [showPassword, setShowPassword] = useState(false)
  const [credentials, setCredentials] = useState({ username: "", password: "" })

  const handleLogin = () => {
    // Mock login - in real app would call API
    setUser({ name: "Ahmad Wijaya", role: "user" })
    onNavigate("user-dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2D4CC8] to-[#4F6FE6] flex items-center justify-center px-6">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Car size={32} className="text-[#2D4CC8]" />
            <span className="text-3xl font-bold text-[#2D4CC8]">GoTravel</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-800">Selamat Datang Kembali</h2>
          <p className="text-gray-600">Masuk ke akun Anda</p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Username</label>
            <input
              type="text"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
              placeholder="Masukkan username"
              value={credentials.username}
              onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                placeholder="Masukkan password"
                value={credentials.password}
                onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          <button
            onClick={handleLogin}
            className="w-full bg-[#2D4CC8] text-white py-3 rounded-lg font-bold hover:bg-[#1e3a8a] transition shadow-lg hover:shadow-xl"
          >
            Masuk
          </button>
        </div>

        <div className="mt-6 text-center text-sm text-gray-600">
          Belum punya akun?{" "}
          <button onClick={() => onNavigate("register")} className="text-[#2D4CC8] font-semibold hover:underline">
            Daftar sekarang
          </button>
          <br />
          <button
            onClick={() => onNavigate("agent-registration")}
            className="text-[#2D4CC8] font-semibold hover:underline"
          >
            Daftar sebagai agen
          </button>
        </div>

        <button
          onClick={() => onNavigate("landing")}
          className="mt-6 w-full text-gray-600 hover:text-gray-800 transition"
        >
          Kembali ke Beranda
        </button>
      </div>
    </div>
  )
}
