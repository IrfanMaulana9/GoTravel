"use client"

import { useEffect } from "react"
import { Head, Link, useForm } from "@inertiajs/react"
import route from "ziggy-js" // Import route from ziggy-js

export default function Login({ status, canResetPassword }) {
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: false,
  })

  useEffect(() => {
    return () => {
      reset("password")
    }
  }, [])

  const submit = (e) => {
    e.preventDefault()
    post(route("login"))
  }

  return (
    <>
      <Head title="Log in" />
      <div
        style={{
          minHeight: "100vh",
          background: "linear-gradient(135deg, #2b5ed7 0%, #1e3a8a 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "2rem",
        }}
      >
        <div
          style={{
            maxWidth: "400px",
            width: "100%",
            background: "white",
            borderRadius: "1rem",
            padding: "2rem",
            boxShadow: "0 20px 25px -5px rgba(0,0,0,0.1)",
          }}
        >
          <div style={{ textAlign: "center", marginBottom: "2rem" }}>
            <div
              style={{
                width: "60px",
                height: "60px",
                background: "#2b5ed7",
                borderRadius: "0.75rem",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "0 auto 1rem",
              }}
            >
              <span style={{ fontSize: "2rem" }}>🚗</span>
            </div>
            <h2
              style={{
                fontSize: "1.75rem",
                fontWeight: "700",
                marginBottom: "0.5rem",
              }}
            >
              GoTravel
            </h2>
            <p style={{ color: "#6b7280" }}>Masuk ke akun Anda</p>
          </div>

          {status && (
            <div
              style={{
                padding: "0.75rem",
                background: "#dcfce7",
                color: "#166534",
                borderRadius: "0.5rem",
                marginBottom: "1rem",
              }}
            >
              {status}
            </div>
          )}

          <form onSubmit={submit}>
            <div style={{ marginBottom: "1rem" }}>
              <label
                style={{
                  display: "block",
                  marginBottom: "0.5rem",
                  fontWeight: "500",
                }}
              >
                Email
              </label>
              <input
                type="email"
                value={data.email}
                onChange={(e) => setData("email", e.target.value)}
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  border: "1px solid #e5e7eb",
                  borderRadius: "0.5rem",
                  fontSize: "1rem",
                }}
                autoComplete="username"
                autoFocus
              />
              {errors.email && (
                <div style={{ color: "#dc2626", fontSize: "0.875rem", marginTop: "0.25rem" }}>{errors.email}</div>
              )}
            </div>

            <div style={{ marginBottom: "1rem" }}>
              <label
                style={{
                  display: "block",
                  marginBottom: "0.5rem",
                  fontWeight: "500",
                }}
              >
                Password
              </label>
              <input
                type="password"
                value={data.password}
                onChange={(e) => setData("password", e.target.value)}
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  border: "1px solid #e5e7eb",
                  borderRadius: "0.5rem",
                  fontSize: "1rem",
                }}
                autoComplete="current-password"
              />
              {errors.password && (
                <div style={{ color: "#dc2626", fontSize: "0.875rem", marginTop: "0.25rem" }}>{errors.password}</div>
              )}
            </div>

            <div style={{ marginBottom: "1.5rem" }}>
              <label style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                <input
                  type="checkbox"
                  checked={data.remember}
                  onChange={(e) => setData("remember", e.target.checked)}
                />
                <span style={{ fontSize: "0.875rem" }}>Ingat saya</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={processing}
              style={{
                width: "100%",
                padding: "0.75rem",
                background: "#2b5ed7",
                color: "white",
                border: "none",
                borderRadius: "0.5rem",
                fontWeight: "600",
                fontSize: "1rem",
                cursor: processing ? "not-allowed" : "pointer",
                opacity: processing ? 0.7 : 1,
              }}
            >
              {processing ? "Loading..." : "Masuk"}
            </button>

            <div
              style={{
                marginTop: "1rem",
                textAlign: "center",
                fontSize: "0.875rem",
              }}
            >
              {canResetPassword && (
                <Link href="/forgot-password" style={{ color: "#2b5ed7", textDecoration: "none" }}>
                  Lupa password?
                </Link>
              )}
              <div style={{ marginTop: "0.5rem" }}>
                Belum punya akun?{" "}
                <Link href="/register" style={{ color: "#2b5ed7", textDecoration: "none" }}>
                  Daftar di sini
                </Link>
              </div>
            </div>
          </form>
        </div>
      </div>
    </>
  )
}
