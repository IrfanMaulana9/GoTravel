"use client"

import { useEffect } from "react"
import { Head, Link, useForm, route } from "@inertiajs/react"

export default function Register() {
  const { data, setData, post, processing, errors, reset } = useForm({
    name: "",
    email: "",
    password: "",
    password_confirmation: "",
  })

  useEffect(() => {
    return () => {
      reset("password", "password_confirmation")
    }
  }, [])

  const submit = (e) => {
    e.preventDefault()
    post(route("register"))
  }

  return (
    <>
      <Head title="Register" />
      <div
        style={{
          minHeight: "100vh",
          background: "linear-gradient(135deg, #2b5ed7 0%, #1e3a8a 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "2rem",
        }}
      >
        <div
          style={{
            maxWidth: "500px",
            width: "100%",
            background: "white",
            borderRadius: "1rem",
            padding: "2rem",
            boxShadow: "0 20px 25px -5px rgba(0,0,0,0.1)",
          }}
        >
          <div style={{ textAlign: "center", marginBottom: "2rem" }}>
            <h2
              style={{
                fontSize: "1.75rem",
                fontWeight: "700",
                marginBottom: "0.5rem",
              }}
            >
              Daftar Akun Baru
            </h2>
            <p style={{ color: "#6b7280" }}>Bergabung dengan GoTravel</p>
          </div>

          <form onSubmit={submit}>
            <div style={{ marginBottom: "1rem" }}>
              <label
                style={{
                  display: "block",
                  marginBottom: "0.5rem",
                  fontWeight: "500",
                }}
              >
                Nama Lengkap
              </label>
              <input
                type="text"
                value={data.name}
                onChange={(e) => setData("name", e.target.value)}
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  border: "1px solid #e5e7eb",
                  borderRadius: "0.5rem",
                  fontSize: "1rem",
                }}
                autoComplete="name"
                autoFocus
                required
              />
              {errors.name && (
                <div style={{ color: "#dc2626", fontSize: "0.875rem", marginTop: "0.25rem" }}>{errors.name}</div>
              )}
            </div>

            <div style={{ marginBottom: "1rem" }}>
              <label
                style={{
                  display: "block",
                  marginBottom: "0.5rem",
                  fontWeight: "500",
                }}
              >
                Email
              </label>
              <input
                type="email"
                value={data.email}
                onChange={(e) => setData("email", e.target.value)}
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  border: "1px solid #e5e7eb",
                  borderRadius: "0.5rem",
                  fontSize: "1rem",
                }}
                autoComplete="username"
                required
              />
              {errors.email && (
                <div style={{ color: "#dc2626", fontSize: "0.875rem", marginTop: "0.25rem" }}>{errors.email}</div>
              )}
            </div>

            <div style={{ marginBottom: "1rem" }}>
              <label
                style={{
                  display: "block",
                  marginBottom: "0.5rem",
                  fontWeight: "500",
                }}
              >
                Password
              </label>
              <input
                type="password"
                value={data.password}
                onChange={(e) => setData("password", e.target.value)}
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  border: "1px solid #e5e7eb",
                  borderRadius: "0.5rem",
                  fontSize: "1rem",
                }}
                autoComplete="new-password"
                required
              />
              {errors.password && (
                <div style={{ color: "#dc2626", fontSize: "0.875rem", marginTop: "0.25rem" }}>{errors.password}</div>
              )}
            </div>

            <div style={{ marginBottom: "1.5rem" }}>
              <label
                style={{
                  display: "block",
                  marginBottom: "0.5rem",
                  fontWeight: "500",
                }}
              >
                Konfirmasi Password
              </label>
              <input
                type="password"
                value={data.password_confirmation}
                onChange={(e) => setData("password_confirmation", e.target.value)}
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  border: "1px solid #e5e7eb",
                  borderRadius: "0.5rem",
                  fontSize: "1rem",
                }}
                autoComplete="new-password"
                required
              />
              {errors.password_confirmation && (
                <div style={{ color: "#dc2626", fontSize: "0.875rem", marginTop: "0.25rem" }}>
                  {errors.password_confirmation}
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={processing}
              style={{
                width: "100%",
                padding: "0.75rem",
                background: "#2b5ed7",
                color: "white",
                border: "none",
                borderRadius: "0.5rem",
                fontWeight: "600",
                fontSize: "1rem",
                cursor: processing ? "not-allowed" : "pointer",
                opacity: processing ? 0.7 : 1,
              }}
            >
              {processing ? "Loading..." : "Daftar"}
            </button>

            <div
              style={{
                marginTop: "1rem",
                textAlign: "center",
                fontSize: "0.875rem",
              }}
            >
              Sudah punya akun?{" "}
              <Link href="/login" style={{ color: "#2b5ed7", textDecoration: "none" }}>
                Login di sini
              </Link>
            </div>
          </form>
        </div>
      </div>
    </>
  )
}
