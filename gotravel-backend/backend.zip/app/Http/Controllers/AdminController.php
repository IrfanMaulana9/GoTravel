<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Booking;
use App\Models\Travel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller
{
    /**
     * Get dashboard statistics
     */
    public function getStats()
    {
        $user = auth('api')->user();
        
        if (!$user || !$user->isAdmin()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 401);
        }
    {
        $stats = [
            'total_users' => User::where('role', 'user')->count(),
            'total_agents' => User::where('role', 'agent')->count(),
            'pending_agents' => User::where('role', 'agent')
                ->where('verification_status', 'pending')
                ->count(),
            'verified_agents' => User::where('role', 'agent')
                ->where('verification_status', 'verified')
                ->count(),
            'total_travels' => Travel::count(),
            'active_travels' => Travel::where('is_active', true)->count(),
            'total_bookings' => Booking::count(),
            'pending_bookings' => Booking::where('status', 'pending')->count(),
            'confirmed_bookings' => Booking::where('status', 'confirmed')->count(),
            'completed_bookings' => Booking::where('status', 'completed')->count(),
            'total_revenue' => Booking::where('payment_status', 'paid')
                ->sum('total_price'),
        ];

        return response()->json([
            'success' => true,
            'data' => $stats
        ]);
    }

    /**
     * Get all users
     */
    public function getAllUsers(Request $request)
    {
        $user = auth('api')->user();
        
        if (!$user || !$user->isAdmin()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $query = User::where('role', 'user');

        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        $users = $query->withCount('bookings')
            ->with(['bookings' => function($q) {
                $q->select('user_id', 'total_price', 'created_at')
                  ->where('payment_status', 'paid')
                  ->latest()
                  ->limit(1);
            }])
            ->orderBy('created_at', 'desc')
            ->paginate($request->integer('per_page', 15));

        // Add booking stats to each user
        $users->getCollection()->transform(function ($user) {
            $user->bookings_count = $user->bookings_count ?? 0;
            $user->total_spent = Booking::where('user_id', $user->id)
                ->where('payment_status', 'paid')
                ->sum('total_price');
            $lastBooking = Booking::where('user_id', $user->id)
                ->latest()
                ->first();
            $user->last_booking_date = $lastBooking ? $lastBooking->created_at->format('Y-m-d') : null;
            return $user;
        });

        return response()->json([
            'success' => true,
            'data' => $users
        ]);
    }

    /**
     * Get all agents
     */
    public function getAllAgents(Request $request)
    {
        $user = auth('api')->user();
        
        if (!$user || !$user->isAdmin()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $query = User::where('role', 'agent');

        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('business_name', 'like', "%{$search}%");
            });
        }

        if ($request->has('verification_status')) {
            $query->where('verification_status', $request->verification_status);
        }

        $agents = $query->withCount(['travels', 'agentBookings'])
            ->orderBy('created_at', 'desc')
            ->paginate($request->integer('per_page', 15));

        // Add stats to each agent
        $agents->getCollection()->transform(function ($agent) {
            $agent->travels_count = $agent->travels_count ?? 0;
            $agent->bookings_count = $agent->agent_bookings_count ?? 0;
            $agent->total_revenue = Booking::where('agent_id', $agent->id)
                ->where('payment_status', 'paid')
                ->sum('total_price');
            return $agent;
        });

        return response()->json([
            'success' => true,
            'data' => $agents
        ]);
    }

    /**
     * Update agent verification status
     */
    public function updateAgentStatus(Request $request, $id)
    {
        $user = auth('api')->user();
        
        if (!$user || !$user->isAdmin()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $agent = User::where('role', 'agent')->findOrFail($id);

        $validator = Validator::make($request->all(), [
            'status' => 'required|in:pending,verified,rejected',
            'rejection_reason' => 'required_if:status,rejected|nullable|string|max:500',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validasi gagal',
                'errors' => $validator->errors()
            ], 422);
        }

        $agent->update([
            'verification_status' => $request->status,
            'rejection_reason' => $request->status === 'rejected' ? $request->rejection_reason : null,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Status verifikasi agen berhasil diperbarui',
            'data' => $agent
        ]);
    }

    /**
     * Get all bookings
     */
    public function getAllBookings(Request $request)
    {
        $user = auth('api')->user();
        
        if (!$user || !$user->isAdmin()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $query = Booking::with(['user', 'travel', 'agent']);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $bookings = $query->orderBy('created_at', 'desc')
            ->paginate($request->integer('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $bookings
        ]);
    }

    /**
     * Update user status (activate/deactivate)
     */
    public function updateUserStatus(Request $request, $id)
    {
        $admin = auth('api')->user();
        
        if (!$admin || !$admin->isAdmin()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $user = User::findOrFail($id);

        // For now, we can just return success
        // You can add an 'is_active' field to users table if needed
        return response()->json([
            'success' => true,
            'message' => 'Status user berhasil diperbarui',
            'data' => $user
        ]);
    }

    /**
     * Delete user
     */
    public function deleteUser($id)
    {
        $admin = auth('api')->user();
        
        if (!$admin || !$admin->isAdmin()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $user = User::findOrFail($id);

        if ($user->role === 'admin') {
            return response()->json([
                'success' => false,
                'message' => 'Tidak dapat menghapus admin'
            ], 400);
        }

        $user->delete();

        return response()->json([
            'success' => true,
            'message' => 'User berhasil dihapus'
        ]);
    }

    /**
     * Get all travels for admin
     */
    public function getAllTravels(Request $request)
    {
        $admin = auth('api')->user();
        
        if (!$admin || !$admin->isAdmin()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $query = Travel::with(['agent']);

        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('from_city', 'like', "%{$search}%")
                  ->orWhere('to_city', 'like', "%{$search}%")
                  ->orWhere('agent_name', 'like', "%{$search}%");
            });
        }

        if ($request->has('is_active')) {
            $query->where('is_active', $request->boolean('is_active'));
        }

        $travels = $query->orderBy('created_at', 'desc')
            ->paginate($request->integer('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $travels
        ]);
    }

    /**
     * Get reports/analytics data
     */
    public function getReports(Request $request)
    {
        $admin = auth('api')->user();
        
        if (!$admin || !$admin->isAdmin()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        // Monthly bookings for last 6 months
        $monthlyBookings = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = now()->subMonths($i);
            $monthlyBookings[] = [
                'month' => $month->format('M Y'),
                'bookings' => Booking::whereMonth('created_at', $month->month)
                    ->whereYear('created_at', $month->year)
                    ->count(),
                'revenue' => Booking::where('payment_status', 'paid')
                    ->whereMonth('created_at', $month->month)
                    ->whereYear('created_at', $month->year)
                    ->sum('total_price'),
            ];
        }

        // Booking status distribution
        $bookingStatus = [
            'pending' => Booking::where('status', 'pending')->count(),
            'confirmed' => Booking::where('status', 'confirmed')->count(),
            'completed' => Booking::where('status', 'completed')->count(),
            'cancelled' => Booking::where('status', 'cancelled')->count(),
        ];

        // Top agents by bookings
        $topAgentsQuery = Booking::selectRaw('agent_id, COUNT(*) as total_bookings, SUM(total_price) as total_revenue')
            ->where('payment_status', 'paid')
            ->groupBy('agent_id')
            ->orderByRaw('COUNT(*) DESC')
            ->limit(5)
            ->get();
        
        $topAgentsData = [];
        foreach ($topAgentsQuery as $item) {
            $agent = User::find($item->agent_id);
            if ($agent) {
                $topAgentsData[] = [
                    'agent_name' => $agent->business_name ?? $agent->name,
                    'total_bookings' => (int)$item->total_bookings,
                    'total_revenue' => (float)$item->total_revenue,
                ];
            }
        }

        // Top routes by bookings
        $topRoutesQuery = Booking::selectRaw('travel_id, COUNT(*) as total_bookings, SUM(total_price) as total_revenue')
            ->where('payment_status', 'paid')
            ->groupBy('travel_id')
            ->orderByRaw('COUNT(*) DESC')
            ->limit(5)
            ->get();
        
        $topRoutes = [];
        foreach ($topRoutesQuery as $item) {
            $travel = Travel::find($item->travel_id);
            if ($travel) {
                $totalBookings = (int)$item->total_bookings;
                $totalRevenue = (float)$item->total_revenue;
                $topRoutes[] = [
                    'route' => $travel->from_city . ' - ' . $travel->to_city,
                    'total_bookings' => $totalBookings,
                    'total_revenue' => $totalRevenue,
                    'avg_per_booking' => $totalBookings > 0 ? round($totalRevenue / $totalBookings, 2) : 0,
                ];
            }
        }

        return response()->json([
            'success' => true,
            'data' => [
                'monthly_bookings' => $monthlyBookings,
                'booking_status_distribution' => $bookingStatus,
                'top_agents' => $topAgentsData,
                'top_routes' => $topRoutes,
            ]
        ]);
    }
}

