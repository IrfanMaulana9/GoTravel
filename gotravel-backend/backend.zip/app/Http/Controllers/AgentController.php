<?php

namespace App\Http\Controllers;

use App\Models\Travel;
use App\Models\Booking;
use Illuminate\Http\Request;

class AgentController extends Controller
{
    /**
     * Get agent dashboard statistics
     */
    public function getStats()
    {
        $agent = auth('api')->user();

        if (!$agent) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated'
            ], 401);
        }

        // Get current month bookings for growth calculation
        $currentMonthBookings = Booking::where('agent_id', $agent->id)
            ->whereMonth('created_at', now()->month)
            ->whereYear('created_at', now()->year)
            ->count();
        
        $lastMonthBookings = Booking::where('agent_id', $agent->id)
            ->whereMonth('created_at', now()->subMonth()->month)
            ->whereYear('created_at', now()->subMonth()->year)
            ->count();

        $growthRate = $lastMonthBookings > 0 
            ? round((($currentMonthBookings - $lastMonthBookings) / $lastMonthBookings) * 100, 2)
            : ($currentMonthBookings > 0 ? 100 : 0);

        // Get monthly bookings for last 6 months
        $monthlyBookings = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = now()->subMonths($i);
            $monthlyBookings[] = [
                'month' => $month->format('M Y'),
                'bookings' => Booking::where('agent_id', $agent->id)
                    ->whereMonth('created_at', $month->month)
                    ->whereYear('created_at', $month->year)
                    ->count(),
                'revenue' => Booking::where('agent_id', $agent->id)
                    ->where('payment_status', 'paid')
                    ->whereMonth('created_at', $month->month)
                    ->whereYear('created_at', $month->year)
                    ->sum('total_price'),
            ];
        }

        // Get route performance
        $routePerformance = Booking::where('agent_id', $agent->id)
            ->with('travel')
            ->selectRaw('travel_id, COUNT(*) as total_bookings, SUM(total_price) as total_revenue')
            ->groupBy('travel_id')
            ->get()
            ->map(function ($item) {
                return [
                    'route' => $item->travel ? $item->travel->from_city . ' - ' . $item->travel->to_city : 'Unknown',
                    'total_bookings' => $item->total_bookings,
                    'total_revenue' => $item->total_revenue,
                    'avg_per_booking' => $item->total_bookings > 0 ? round($item->total_revenue / $item->total_bookings, 2) : 0,
                ];
            });

        // Get booking status distribution
        $bookingStatus = [
            'pending' => Booking::where('agent_id', $agent->id)->where('status', 'pending')->count(),
            'confirmed' => Booking::where('agent_id', $agent->id)->where('status', 'confirmed')->count(),
            'completed' => Booking::where('agent_id', $agent->id)->where('status', 'completed')->count(),
            'cancelled' => Booking::where('agent_id', $agent->id)->where('status', 'cancelled')->count(),
        ];

        $stats = [
            'total_travels' => Travel::where('agent_id', $agent->id)->count(),
            'active_travels' => Travel::where('agent_id', $agent->id)
                ->where('is_active', true)
                ->count(),
            'total_bookings' => Booking::where('agent_id', $agent->id)->count(),
            'pending_bookings' => $bookingStatus['pending'],
            'confirmed_bookings' => $bookingStatus['confirmed'],
            'completed_bookings' => $bookingStatus['completed'],
            'cancelled_bookings' => $bookingStatus['cancelled'],
            'monthly_bookings' => $currentMonthBookings,
            'growth_rate' => $growthRate,
            'total_revenue' => Booking::where('agent_id', $agent->id)
                ->where('payment_status', 'paid')
                ->sum('total_price'),
            'monthly_revenue' => Booking::where('agent_id', $agent->id)
                ->where('payment_status', 'paid')
                ->whereMonth('created_at', now()->month)
                ->whereYear('created_at', now()->year)
                ->sum('total_price'),
            'verification_status' => $agent->verification_status,
            'monthly_trend' => $monthlyBookings,
            'route_performance' => $routePerformance,
            'booking_status_distribution' => $bookingStatus,
        ];

        return response()->json([
            'success' => true,
            'data' => $stats
        ]);
    }

    /**
     * Get agent's travels
     */
    public function getTravels(Request $request)
    {
        $agent = auth('api')->user();
        
        if (!$agent) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated'
            ], 401);
        }

        $query = Travel::where('agent_id', $agent->id);

        if ($request->has('is_active')) {
            $query->where('is_active', $request->boolean('is_active'));
        }

        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('from_city', 'like', "%{$search}%")
                  ->orWhere('to_city', 'like', "%{$search}%");
            });
        }

        $travels = $query->orderBy('created_at', 'desc')
            ->paginate($request->integer('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $travels
        ]);
    }

    /**
     * Get agent's bookings
     */
    public function getBookings(Request $request)
    {
        $agent = auth('api')->user();
        
        if (!$agent) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated'
            ], 401);
        }

        $query = Booking::with(['user', 'travel'])
            ->where('agent_id', $agent->id);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $bookings = $query->orderBy('created_at', 'desc')
            ->paginate($request->integer('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $bookings
        ]);
    }
}

