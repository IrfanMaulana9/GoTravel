<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Booking;
use App\Models\Travel;
use App\Models\User;
use Carbon\Carbon;

class BookingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Delete existing bookings first (to avoid foreign key issues)
        Booking::query()->delete();

        // Get users and travels
        $users = User::where('role', 'user')->get();
        $travels = Travel::where('is_active', true)->get();

        if ($users->isEmpty() || $travels->isEmpty()) {
            $this->command->warn('Users atau Travels belum ada. Pastikan UserSeeder dan TravelSeeder sudah dijalankan.');
            return;
        }

        $bookings = [];

        // Create some bookings with different statuses
        foreach ($travels->take(5) as $index => $travel) {
            if ($travel->available_seats <= 0) continue;

            $user = $users->random();
            $quantity = rand(1, min(3, $travel->available_seats));
            $totalPrice = $travel->price * $quantity;

            // Different statuses for variety
            $statuses = ['pending', 'confirmed', 'completed'];
            $status = $statuses[$index % count($statuses)];
            
            $travelDate = Carbon::now()->addDays(rand(1, 30))->format('Y-m-d');
            
            $booking = Booking::create([
                'user_id' => $user->id,
                'travel_id' => $travel->id,
                'agent_id' => $travel->agent_id,
                'travel_date' => $travelDate,
                'quantity' => $quantity,
                'total_price' => $totalPrice,
                'status' => $status,
                'passenger_name' => $user->name,
                'passenger_phone' => $user->phone ?? '081234567890',
                'passenger_address' => $user->address ?? 'Alamat penumpang',
                'pickup_location' => 'Lokasi penjemputan',
                'notes' => 'Catatan khusus untuk pemesanan',
                'payment_method' => $status === 'completed' ? 'Transfer Bank' : null,
                'payment_status' => $status === 'completed' ? 'paid' : ($status === 'confirmed' ? 'paid' : 'pending'),
                'paid_at' => $status === 'completed' || $status === 'confirmed' ? Carbon::now()->subDays(rand(1, 5)) : null,
            ]);

            // Update available seats
            $travel->decrement('available_seats', $quantity);

            $bookings[] = $booking;
        }

        $this->command->info('Data booking berhasil di-seed! Total: ' . count($bookings) . ' bookings.');
    }
}

