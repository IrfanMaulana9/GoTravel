<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Review;
use App\Models\Booking;
use App\Models\Travel;

class ReviewSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Delete existing reviews first
        Review::query()->delete();

        // Get completed bookings
        $completedBookings = Booking::where('status', 'completed')
            ->get();

        if ($completedBookings->isEmpty()) {
            $this->command->warn('Tidak ada completed bookings. Review akan dibuat setelah ada completed bookings.');
            return;
        }

        $reviews = [];
        $ratings = [4, 5, 4, 5, 5, 4, 5, 4, 5, 5]; // Mostly positive ratings
        $comments = [
            'Pelayanan sangat baik, sopir ramah dan perjalanan nyaman.',
            'Travel tepat waktu, mobil bersih dan fasilitas lengkap.',
            'Sangat puas dengan pelayanannya, harga juga terjangkau.',
            'Recommended! Travel yang nyaman dan aman.',
            'Perjalanan lancar, driver profesional dan berpengalaman.',
            'Mobil baru dan bersih, AC dingin, sangat nyaman.',
            'Harga sesuai dengan pelayanan yang diberikan.',
            'Sangat membantu untuk perjalanan bisnis.',
            'Travel terbaik yang pernah saya gunakan!',
            'Pelayanan excellent, akan booking lagi next time.',
        ];

        foreach ($completedBookings->take(10) as $index => $booking) {
            $rating = $ratings[$index % count($ratings)];
            $comment = $comments[$index % count($comments)];

            $review = Review::create([
                'user_id' => $booking->user_id,
                'booking_id' => $booking->id,
                'travel_id' => $booking->travel_id,
                'agent_id' => $booking->agent_id,
                'rating' => $rating,
                'comment' => $comment,
            ]);

            // Update travel rating
            $booking->travel->updateRating();

            $reviews[] = $review;
        }

        $this->command->info('Data review berhasil di-seed! Total: ' . count($reviews) . ' reviews.');
    }
}

