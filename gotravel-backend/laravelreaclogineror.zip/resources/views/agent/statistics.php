<?php
require_once 'config/config.php';
require_once 'includes/booking.php';

// Require agent login
if (!isset($_SESSION['agent_id'])) {
    redirect('login.php');
}

$booking = new Booking();
$agentBookings = $booking->getAgentBookings($_SESSION['agent_id']);

// Calculate statistics
$totalBookings = count($agentBookings);
$pendingBookings = count(array_filter($agentBookings, function($b) { return $b['status'] === 'pending'; }));
$confirmedBookings = count(array_filter($agentBookings, function($b) { return $b['status'] === 'confirmed'; }));
$completedBookings = count(array_filter($agentBookings, function($b) { return $b['status'] === 'completed'; }));
$cancelledBookings = count(array_filter($agentBookings, function($b) { return $b['status'] === 'cancelled'; }));

$totalRevenue = array_sum(array_map(function($b) {
    return $b['status'] === 'confirmed' || $b['status'] === 'completed' ? $b['total_price'] : 0;
}, $agentBookings));

// Monthly statistics
$monthlyStats = [];
foreach ($agentBookings as $bookingItem) {
    $month = date('Y-m', strtotime($bookingItem['created_at']));
    if (!isset($monthlyStats[$month])) {
        $monthlyStats[$month] = ['bookings' => 0, 'revenue' => 0];
    }
    $monthlyStats[$month]['bookings']++;
    if ($bookingItem['status'] === 'confirmed' || $bookingItem['status'] === 'completed') {
        $monthlyStats[$month]['revenue'] += $bookingItem['total_price'];
    }
}

// Route statistics
$routeStats = [];
foreach ($agentBookings as $bookingItem) {
    $route = $bookingItem['from_city'] . ' - ' . $bookingItem['to_city'];
    if (!isset($routeStats[$route])) {
        $routeStats[$route] = ['bookings' => 0, 'revenue' => 0];
    }
    $routeStats[$route]['bookings']++;
    if ($bookingItem['status'] === 'confirmed' || $bookingItem['status'] === 'completed') {
        $routeStats[$route]['revenue'] += $bookingItem['total_price'];
    }
}

// Sort by bookings
arsort($routeStats);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Statistik Agen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
        }
        .stat-card {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
        }
        .stat-card.warning {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }
        .stat-card.success {
            background: linear-gradient(135deg, #10b981, #059669);
        }
        .stat-card.danger {
            background: linear-gradient(135deg, #ef4444, #dc2626);
        }
        .stat-card.info {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }
        .chart-container {
            position: relative;
            height: 400px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-car me-2"></i>MayTravel
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="agent-dashboard.php">
                    <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
                <a class="nav-link" href="manage-routes.php">
                    <i class="fas fa-route me-1"></i>Kelola Rute
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-chart-bar me-2 text-primary"></i>Statistik & Analitik</h2>
                <p class="text-muted">Analisis performa bisnis Anda</p>
            </div>
        </div>

        <!-- Overview Statistics -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalBookings; ?></div>
                    <div>Total Booking</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card warning">
                    <div class="stat-number"><?php echo $pendingBookings; ?></div>
                    <div>Menunggu</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card success">
                    <div class="stat-number"><?php echo $confirmedBookings + $completedBookings; ?></div>
                    <div>Berhasil</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card info">
                    <div class="stat-number">Rp <?php echo number_format($totalRevenue / 1000000, 1); ?>M</div>
                    <div>Total Pendapatan</div>
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="row mb-4">
            <div class="col-lg-8 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-chart-line me-2 text-primary"></i>Tren Booking Bulanan
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="monthlyChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-chart-pie me-2 text-primary"></i>Status Booking
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="statusChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Route Performance -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-route me-2 text-primary"></i>Performa Rute
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($routeStats)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-chart-bar fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Belum ada data</h5>
                                <p class="text-muted">Data performa rute akan muncul setelah ada booking</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Rute</th>
                                            <th>Total Booking</th>
                                            <th>Total Pendapatan</th>
                                            <th>Rata-rata per Booking</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($routeStats as $route => $stats): ?>
                                            <tr>
                                                <td><strong><?php echo $route; ?></strong></td>
                                                <td>
                                                    <span class="badge bg-primary"><?php echo $stats['bookings']; ?> booking</span>
                                                </td>
                                                <td>
                                                    <strong class="text-success">Rp <?php echo number_format($stats['revenue'], 0, ',', '.'); ?></strong>
                                                </td>
                                                <td>
                                                    Rp <?php echo number_format($stats['bookings'] > 0 ? $stats['revenue'] / $stats['bookings'] : 0, 0, ',', '.'); ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Monthly Chart
        const monthlyData = <?php echo json_encode($monthlyStats); ?>;
        const monthlyLabels = Object.keys(monthlyData).sort();
        const monthlyBookings = monthlyLabels.map(month => monthlyData[month].bookings);
        const monthlyRevenue = monthlyLabels.map(month => monthlyData[month].revenue);

        const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
        new Chart(monthlyCtx, {
            type: 'line',
            data: {
                labels: monthlyLabels.map(month => {
                    const date = new Date(month + '-01');
                    return date.toLocaleDateString('id-ID', { year: 'numeric', month: 'short' });
                }),
                datasets: [{
                    label: 'Jumlah Booking',
                    data: monthlyBookings,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y'
                }, {
                    label: 'Pendapatan (Rp)',
                    data: monthlyRevenue,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Jumlah Booking'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Pendapatan (Rp)'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                }
            }
        });

        // Status Chart
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: ['Menunggu', 'Terkonfirmasi', 'Selesai', 'Dibatalkan'],
                datasets: [{
                    data: [
                        <?php echo $pendingBookings; ?>,
                        <?php echo $confirmedBookings; ?>,
                        <?php echo $completedBookings; ?>,
                        <?php echo $cancelledBookings; ?>
                    ],
                    backgroundColor: [
                        '#f59e0b',
                        '#10b981',
                        '#3b82f6',
                        '#ef4444'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    </script>
</body>
</html>
