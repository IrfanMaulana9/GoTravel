<?php
require_once 'config/config.php';
require_once 'includes/booking.php';

// Require agent login
if (!isset($_SESSION['agent_id'])) {
    redirect('login.php');
}

$booking = new Booking();
$agentBookings = $booking->getAgentBookings($_SESSION['agent_id']);

// Handle booking status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $result = $booking->updateBookingStatus($_POST['booking_id'], $_POST['status'], $_SESSION['agent_id']);
    if ($result['success']) {
        $success = $result['message'];
        // Refresh bookings
        $agentBookings = $booking->getAgentBookings($_SESSION['agent_id']);
    } else {
        $error = $result['message'];
    }
}

// Calculate statistics
$totalBookings = count($agentBookings);
$pendingBookings = count(array_filter($agentBookings, function($b) { return $b['status'] === 'pending'; }));
$confirmedBookings = count(array_filter($agentBookings, function($b) { return $b['status'] === 'confirmed'; }));
$totalRevenue = array_sum(array_map(function($b) {
    return $b['status'] === 'confirmed' || $b['status'] === 'completed' ? $b['total_price'] : 0;
}, $agentBookings));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Dashboard Agen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .dashboard-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
            transition: all 0.3s ease;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }
        .stat-card {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
        }
        .stat-card.warning {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }
        .stat-card.success {
            background: linear-gradient(135deg, #10b981, #059669);
        }
        .stat-card.info {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-confirmed { background: #d1fae5; color: #065f46; }
        .status-cancelled { background: #fee2e2; color: #991b1b; }
        .status-completed { background: #dbeafe; color: #1e40af; }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border: none;
            border-radius: 10px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(30, 64, 175, 0.3);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-car me-2"></i>MayTravel
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    <i class="fas fa-building me-1"></i>
                    <?php echo htmlspecialchars($_SESSION['company_name']); ?>
                </span>
                <a class="nav-link" href="manage-routes.php">
                    <i class="fas fa-route me-1"></i>Kelola Rute
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-tachometer-alt me-2 text-primary"></i>Dashboard Agen</h2>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalBookings; ?></div>
                    <div>Total Booking</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card warning">
                    <div class="stat-number"><?php echo $pendingBookings; ?></div>
                    <div>Menunggu Konfirmasi</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card success">
                    <div class="stat-number"><?php echo $confirmedBookings; ?></div>
                    <div>Terkonfirmasi</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card info">
                    <div class="stat-number">Rp <?php echo number_format($totalRevenue / 1000000, 1); ?>M</div>
                    <div>Total Pendapatan</div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="dashboard-card card p-4">
                    <h5 class="mb-3"><i class="fas fa-bolt me-2 text-primary"></i>Aksi Cepat</h5>
                    <div class="row">
                        <div class="col-md-3 mb-2">
                            <a href="manage-routes.php" class="btn btn-primary w-100">
                                <i class="fas fa-plus me-2"></i>Tambah Rute
                            </a>
                        </div>
                        <div class="col-md-3 mb-2">
                            <a href="#bookings" class="btn btn-outline-primary w-100">
                                <i class="fas fa-list me-2"></i>Kelola Booking
                            </a>
                        </div>
                        <div class="col-md-3 mb-2">
                            <a href="agent-statistics.php" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-chart-bar me-2"></i>Statistik
                            </a>
                        </div>
                        <div class="col-md-3 mb-2">
                            <a href="contact-support.php" class="btn btn-outline-info w-100">
                                <i class="fas fa-headset me-2"></i>Bantuan
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bookings Management -->
        <div class="row" id="bookings">
            <div class="col-12">
                <div class="dashboard-card card">
                    <div class="card-header bg-transparent">
                        <h5 class="mb-0">
                            <i class="fas fa-clipboard-list me-2 text-primary"></i>Manajemen Booking
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($agentBookings)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Belum ada booking</h5>
                                <p class="text-muted">Booking akan muncul di sini ketika ada pengguna yang memesan rute Anda</p>
                                <a href="manage-routes.php" class="btn btn-primary">
                                    <i class="fas fa-plus me-2"></i>Tambah Rute
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Kode Booking</th>
                                            <th>Penumpang</th>
                                            <th>Rute</th>
                                            <th>Tanggal</th>
                                            <th>Kursi</th>
                                            <th>Total</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($agentBookings as $bookingItem): ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo $bookingItem['booking_code']; ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        <?php echo date('d/m/Y H:i', strtotime($bookingItem['created_at'])); ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($bookingItem['passenger_name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        <i class="fas fa-phone me-1"></i><?php echo $bookingItem['passenger_phone']; ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <?php echo $bookingItem['from_city']; ?> → <?php echo $bookingItem['to_city']; ?>
                                                    <br>
                                                    <small class="text-muted">
                                                        <i class="fas fa-car me-1"></i><?php echo $bookingItem['vehicle_type']; ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <?php echo date('d/m/Y', strtotime($bookingItem['travel_date'])); ?>
                                                    <br>
                                                    <small class="text-muted">
                                                        <?php echo date('H:i', strtotime($bookingItem['departure_time'])); ?> -
                                                        <?php echo date('H:i', strtotime($bookingItem['arrival_time'])); ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <span class="badge bg-primary"><?php echo $bookingItem['seats_booked']; ?> kursi</span>
                                                </td>
                                                <td>
                                                    <strong>Rp <?php echo number_format($bookingItem['total_price'], 0, ',', '.'); ?></strong>
                                                </td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $bookingItem['status']; ?>">
                                                        <?php
                                                        $statusLabels = [
                                                            'pending' => 'Menunggu',
                                                            'confirmed' => 'Terkonfirmasi',
                                                            'cancelled' => 'Dibatalkan',
                                                            'completed' => 'Selesai'
                                                        ];
                                                        echo $statusLabels[$bookingItem['status']] ?? $bookingItem['status'];
                                                        ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <button type="button" class="btn btn-outline-primary"
                                                                onclick="showBookingDetails(<?php echo htmlspecialchars(json_encode($bookingItem)); ?>)">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <?php if ($bookingItem['status'] === 'pending'): ?>
                                                            <button type="button" class="btn btn-outline-success"
                                                                    onclick="updateBookingStatus(<?php echo $bookingItem['id']; ?>, 'confirmed')">
                                                                <i class="fas fa-check"></i>
                                                            </button>
                                                            <button type="button" class="btn btn-outline-danger"
                                                                    onclick="updateBookingStatus(<?php echo $bookingItem['id']; ?>, 'cancelled')">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        <?php elseif ($bookingItem['status'] === 'confirmed'): ?>
                                                            <button type="button" class="btn btn-outline-info"
                                                                    onclick="updateBookingStatus(<?php echo $bookingItem['id']; ?>, 'completed')">
                                                                <i class="fas fa-flag-checkered"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Booking Details Modal -->
    <div class="modal fade" id="bookingDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-ticket-alt me-2"></i>Detail Booking
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="bookingDetailsContent">
                    <!-- Content will be populated by JavaScript -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Status Update Form (Hidden) -->
    <form id="statusUpdateForm" method="POST" style="display: none;">
        <input type="hidden" name="update_status" value="1">
        <input type="hidden" name="booking_id" id="statusBookingId">
        <input type="hidden" name="status" id="statusValue">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showBookingDetails(booking) {
            const statusLabels = {
                'pending': 'Menunggu Konfirmasi',
                'confirmed': 'Terkonfirmasi',
                'cancelled': 'Dibatalkan',
                'completed': 'Selesai'
            };

            const content = `
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Booking</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Kode Booking:</strong></td><td>${booking.booking_code}</td></tr>
                            <tr><td><strong>Status:</strong></td><td><span class="status-badge status-${booking.status}">${statusLabels[booking.status]}</span></td></tr>
                            <tr><td><strong>Tanggal Booking:</strong></td><td>${new Date(booking.created_at).toLocaleDateString('id-ID')}</td></tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Perjalanan</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Rute:</strong></td><td>${booking.from_city} → ${booking.to_city}</td></tr>
                            <tr><td><strong>Tanggal:</strong></td><td>${new Date(booking.travel_date).toLocaleDateString('id-ID')}</td></tr>
                            <tr><td><strong>Waktu:</strong></td><td>${booking.departure_time} - ${booking.arrival_time}</td></tr>
                            <tr><td><strong>Kendaraan:</strong></td><td>${booking.vehicle_type}</td></tr>
                            <tr><td><strong>Kursi:</strong></td><td>${booking.seats_booked} kursi</td></tr>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Penumpang</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Nama:</strong></td><td>${booking.passenger_name}</td></tr>
                            <tr><td><strong>Telepon:</strong></td><td>${booking.passenger_phone}</td></tr>
                            ${booking.passenger_email ? `<tr><td><strong>Email:</strong></td><td>${booking.passenger_email}</td></tr>` : ''}
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-primary">Total Pembayaran</h6>
                        <h4 class="text-success">Rp ${parseInt(booking.total_price).toLocaleString('id-ID')}</h4>
                    </div>
                </div>
                ${booking.notes ? `
                <div class="row">
                    <div class="col-12">
                        <h6 class="text-primary">Catatan</h6>
                        <p class="text-muted">${booking.notes}</p>
                    </div>
                </div>
                ` : ''}
            `;

            document.getElementById('bookingDetailsContent').innerHTML = content;
            new bootstrap.Modal(document.getElementById('bookingDetailsModal')).show();
        }

        function updateBookingStatus(bookingId, status) {
            const statusLabels = {
                'confirmed': 'mengkonfirmasi',
                'cancelled': 'membatalkan',
                'completed': 'menyelesaikan'
            };

            if (confirm(`Yakin ingin ${statusLabels[status]} booking ini?`)) {
                document.getElementById('statusBookingId').value = bookingId;
                document.getElementById('statusValue').value = status;
                document.getElementById('statusUpdateForm').submit();
            }
        }
    </script>
</body>
</html>
