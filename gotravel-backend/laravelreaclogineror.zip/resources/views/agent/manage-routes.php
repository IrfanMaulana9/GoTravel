<?php
require_once 'config/config.php';
require_once 'includes/route.php';

// Require agent login
if (!isset($_SESSION['agent_id'])) {
    redirect('login.php');
}

$route = new Route();
$error = '';
$success = '';

// Handle route creation/update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_route'])) {
        $routeData = [
            'agent_id' => $_SESSION['agent_id'],
            'from_city' => sanitize($_POST['from_city']),
            'to_city' => sanitize($_POST['to_city']),
            'departure_time' => sanitize($_POST['departure_time']),
            'arrival_time' => sanitize($_POST['arrival_time']),
            'price' => (float)$_POST['price'],
            'vehicle_type' => sanitize($_POST['vehicle_type']),
            'seats_total' => (int)$_POST['seats_total'],
            'description' => sanitize($_POST['description'])
        ];

        $result = $route->createRoute($routeData);
        if ($result['success']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['update_route'])) {
        $routeData = [
            'from_city' => sanitize($_POST['from_city']),
            'to_city' => sanitize($_POST['to_city']),
            'departure_time' => sanitize($_POST['departure_time']),
            'arrival_time' => sanitize($_POST['arrival_time']),
            'price' => (float)$_POST['price'],
            'vehicle_type' => sanitize($_POST['vehicle_type']),
            'seats_total' => (int)$_POST['seats_total'],
            'description' => sanitize($_POST['description']),
            'status' => sanitize($_POST['status'])
        ];

        $result = $route->updateRoute($_POST['route_id'], $routeData, $_SESSION['agent_id']);
        if ($result['success']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['delete_route'])) {
        $result = $route->deleteRoute($_POST['route_id'], $_SESSION['agent_id']);
        if ($result['success']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}

// Get agent routes
$agentRoutes = $route->getAgentRoutes($_SESSION['agent_id']);

$cities = ['Jakarta', 'Bandung', 'Surabaya', 'Yogyakarta', 'Semarang', 'Solo', 'Malang', 'Banyuwangi', 'Bogor', 'Madiun'];
$vehicleTypes = ['Minivan', 'SUV', 'Bus', 'Sedan', 'Hiace'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Kelola Rute</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border: none;
            border-radius: 10px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(30, 64, 175, 0.3);
        }
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e2e8f0;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--secondary-blue);
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
        .route-card {
            transition: all 0.3s ease;
            border-left: 4px solid var(--secondary-blue);
        }
        .route-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-active { background: #d1fae5; color: #065f46; }
        .status-inactive { background: #fee2e2; color: #991b1b; }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-car me-2"></i>MayTravel
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="agent-dashboard.php">
                    <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-route me-2 text-primary"></i>Kelola Rute</h2>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            </div>
        <?php endif; ?>

        <!-- Add Route Form -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-plus me-2 text-primary"></i>Tambah Rute Baru
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="create_route" value="1">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="from_city" class="form-label">Kota Asal *</label>
                                    <select class="form-select" id="from_city" name="from_city" required>
                                        <option value="">Pilih kota asal</option>
                                        <?php foreach ($cities as $city): ?>
                                            <option value="<?php echo $city; ?>"><?php echo $city; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="to_city" class="form-label">Kota Tujuan *</label>
                                    <select class="form-select" id="to_city" name="to_city" required>
                                        <option value="">Pilih kota tujuan</option>
                                        <?php foreach ($cities as $city): ?>
                                            <option value="<?php echo $city; ?>"><?php echo $city; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="departure_time" class="form-label">Waktu Berangkat *</label>
                                    <input type="time" class="form-control" id="departure_time" name="departure_time" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="arrival_time" class="form-label">Waktu Tiba *</label>
                                    <input type="time" class="form-control" id="arrival_time" name="arrival_time" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="price" class="form-label">Harga (Rp) *</label>
                                    <input type="number" class="form-control" id="price" name="price" min="0" step="1000" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="vehicle_type" class="form-label">Jenis Kendaraan *</label>
                                    <select class="form-select" id="vehicle_type" name="vehicle_type" required>
                                        <option value="">Pilih kendaraan</option>
                                        <?php foreach ($vehicleTypes as $type): ?>
                                            <option value="<?php echo $type; ?>"><?php echo $type; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="seats_total" class="form-label">Jumlah Kursi *</label>
                                    <input type="number" class="form-control" id="seats_total" name="seats_total" min="1" max="50" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="description" class="form-label">Deskripsi</label>
                                <textarea class="form-control" id="description" name="description" rows="3" placeholder="Deskripsi tambahan tentang rute ini..."></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Tambah Rute
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Routes List -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2 text-primary"></i>Daftar Rute Anda
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($agentRoutes)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-route fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Belum ada rute</h5>
                                <p class="text-muted">Tambahkan rute pertama Anda menggunakan form di atas</p>
                            </div>
                        <?php else: ?>
                            <div class="row">
                                <?php foreach ($agentRoutes as $routeItem): ?>
                                    <div class="col-lg-6 mb-3">
                                        <div class="route-card card">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-start mb-2">
                                                    <h6 class="mb-0">
                                                        <?php echo $routeItem['from_city']; ?> → <?php echo $routeItem['to_city']; ?>
                                                    </h6>
                                                    <span class="status-badge status-<?php echo $routeItem['status']; ?>">
                                                        <?php echo $routeItem['status'] === 'active' ? 'Aktif' : 'Nonaktif'; ?>
                                                    </span>
                                                </div>

                                                <div class="row mb-2">
                                                    <div class="col-6">
                                                        <small class="text-muted">Berangkat</small>
                                                        <div class="fw-bold"><?php echo date('H:i', strtotime($routeItem['departure_time'])); ?></div>
                                                    </div>
                                                    <div class="col-6">
                                                        <small class="text-muted">Tiba</small>
                                                        <div class="fw-bold"><?php echo date('H:i', strtotime($routeItem['arrival_time'])); ?></div>
                                                    </div>
                                                </div>

                                                <div class="row mb-2">
                                                    <div class="col-6">
                                                        <small class="text-muted">Harga</small>
                                                        <div class="fw-bold text-success">Rp <?php echo number_format($routeItem['price'], 0, ',', '.'); ?></div>
                                                    </div>
                                                    <div class="col-6">
                                                        <small class="text-muted">Kendaraan</small>
                                                        <div class="fw-bold"><?php echo $routeItem['vehicle_type']; ?></div>
                                                    </div>
                                                </div>

                                                <div class="mb-3">
                                                    <small class="text-muted">
                                                        <i class="fas fa-users me-1"></i>
                                                        <?php echo $routeItem['seats_available']; ?>/<?php echo $routeItem['seats_total']; ?> kursi tersedia
                                                    </small>
                                                </div>

                                                <?php if ($routeItem['description']): ?>
                                                    <p class="text-muted small mb-3"><?php echo htmlspecialchars($routeItem['description']); ?></p>
                                                <?php endif; ?>

                                                <div class="btn-group btn-group-sm w-100">
                                                    <button type="button" class="btn btn-outline-primary"
                                                            onclick="editRoute(<?php echo htmlspecialchars(json_encode($routeItem)); ?>)">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </button>
                                                    <button type="button" class="btn btn-outline-warning"
                                                            onclick="toggleRouteStatus(<?php echo $routeItem['id']; ?>, '<?php echo $routeItem['status'] === 'active' ? 'inactive' : 'active'; ?>')">
                                                        <i class="fas fa-toggle-<?php echo $routeItem['status'] === 'active' ? 'on' : 'off'; ?>"></i>
                                                        <?php echo $routeItem['status'] === 'active' ? 'Nonaktifkan' : 'Aktifkan'; ?>
                                                    </button>
                                                    <button type="button" class="btn btn-outline-danger"
                                                            onclick="deleteRoute(<?php echo $routeItem['id']; ?>)">
                                                        <i class="fas fa-trash"></i> Hapus
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Route Modal -->
    <div class="modal fade" id="editRouteModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-edit me-2"></i>Edit Rute
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="update_route" value="1">
                        <input type="hidden" name="route_id" id="edit_route_id">

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_from_city" class="form-label">Kota Asal *</label>
                                <select class="form-select" id="edit_from_city" name="from_city" required>
                                    <?php foreach ($cities as $city): ?>
                                        <option value="<?php echo $city; ?>"><?php echo $city; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_to_city" class="form-label">Kota Tujuan *</label>
                                <select class="form-select" id="edit_to_city" name="to_city" required>
                                    <?php foreach ($cities as $city): ?>
                                        <option value="<?php echo $city; ?>"><?php echo $city; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_departure_time" class="form-label">Waktu Berangkat *</label>
                                <input type="time" class="form-control" id="edit_departure_time" name="departure_time" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_arrival_time" class="form-label">Waktu Tiba *</label>
                                <input type="time" class="form-control" id="edit_arrival_time" name="arrival_time" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="edit_price" class="form-label">Harga (Rp) *</label>
                                <input type="number" class="form-control" id="edit_price" name="price" min="0" step="1000" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="edit_vehicle_type" class="form-label">Jenis Kendaraan *</label>
                                <select class="form-select" id="edit_vehicle_type" name="vehicle_type" required>
                                    <?php foreach ($vehicleTypes as $type): ?>
                                        <option value="<?php echo $type; ?>"><?php echo $type; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="edit_seats_total" class="form-label">Jumlah Kursi *</label>
                                <input type="number" class="form-control" id="edit_seats_total" name="seats_total" min="1" max="50" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_status" class="form-label">Status</label>
                                <select class="form-select" id="edit_status" name="status">
                                    <option value="active">Aktif</option>
                                    <option value="inactive">Nonaktif</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="edit_description" class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="edit_description" name="description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Hidden Forms -->
    <form id="statusForm" method="POST" style="display: none;">
        <input type="hidden" name="update_route" value="1">
        <input type="hidden" name="route_id" id="status_route_id">
        <input type="hidden" name="status" id="status_value">
    </form>

    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="delete_route" value="1">
        <input type="hidden" name="route_id" id="delete_route_id">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Prevent same city selection
        function setupCityValidation(fromId, toId) {
            document.getElementById(fromId).addEventListener('change', function() {
                const fromValue = this.value;
                const toSelect = document.getElementById(toId);

                Array.from(toSelect.options).forEach(option => {
                    option.disabled = option.value === fromValue;
                });

                if (toSelect.value === fromValue) {
                    toSelect.value = '';
                }
            });

            document.getElementById(toId).addEventListener('change', function() {
                const toValue = this.value;
                const fromSelect = document.getElementById(fromId);

                Array.from(fromSelect.options).forEach(option => {
                    option.disabled = option.value === toValue;
                });

                if (fromSelect.value === toValue) {
                    fromSelect.value = '';
                }
            });
        }

        // Setup validation for both forms
        setupCityValidation('from_city', 'to_city');
        setupCityValidation('edit_from_city', 'edit_to_city');

        function editRoute(route) {
            document.getElementById('edit_route_id').value = route.id;
            document.getElementById('edit_from_city').value = route.from_city;
            document.getElementById('edit_to_city').value = route.to_city;
            document.getElementById('edit_departure_time').value = route.departure_time;
            document.getElementById('edit_arrival_time').value = route.arrival_time;
            document.getElementById('edit_price').value = route.price;
            document.getElementById('edit_vehicle_type').value = route.vehicle_type;
            document.getElementById('edit_seats_total').value = route.seats_total;
            document.getElementById('edit_status').value = route.status;
            document.getElementById('edit_description').value = route.description || '';

            new bootstrap.Modal(document.getElementById('editRouteModal')).show();
        }

        function toggleRouteStatus(routeId, newStatus) {
            const action = newStatus === 'active' ? 'mengaktifkan' : 'menonaktifkan';
            if (confirm(`Yakin ingin ${action} rute ini?`)) {
                document.getElementById('status_route_id').value = routeId;
                document.getElementById('status_value').value = newStatus;
                document.getElementById('statusForm').submit();
            }
        }

        function deleteRoute(routeId) {
            if (confirm('Yakin ingin menghapus rute ini? Tindakan ini tidak dapat dibatalkan.')) {
                document.getElementById('delete_route_id').value = routeId;
                document.getElementById('deleteForm').submit();
            }
        }
    </script>
</body>
</html>
