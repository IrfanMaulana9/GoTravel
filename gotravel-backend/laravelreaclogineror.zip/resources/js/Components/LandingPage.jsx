"use client"

import { Car, Shield, CreditCard, Clock, Headphones, Smartphone, MapPin } from "lucide-react"

export default function LandingPage({ onNavigate }) {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="bg-[#2D4CC8] text-white px-6 py-4 shadow-lg fixed w-full top-0 z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Car size={28} />
            <span className="text-2xl font-bold">GoTravel</span>
          </div>
          <div className="flex gap-6 items-center">
            <button className="hover:text-blue-200 transition">Beranda</button>
            <button className="hover:text-blue-200 transition">Fitur</button>
            <button className="hover:text-blue-200 transition">Tentang</button>
            <button className="hover:text-blue-200 transition">Kontak</button>
            <button onClick={() => onNavigate("login")} className="hover:text-blue-200 transition">
              Login
            </button>
            <button onClick={() => onNavigate("agent-registration")} className="hover:text-blue-200 transition">
              Daftar Agen
            </button>
            <button className="bg-white text-[#2D4CC8] px-4 py-2 rounded-lg hover:bg-blue-50 transition">Admin</button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#2D4CC8] to-[#4F6FE6] text-white pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex-1">
            <h1 className="text-5xl font-bold mb-6 leading-tight">
              Jelajahi Indonesia
              <br />
              dengan <span className="text-yellow-300">GoTravel</span>
            </h1>
            <p className="text-xl mb-8 opacity-90">
              Platform travel terpercaya yang menghubungkan Anda
              <br />
              dengan agen travel terbaik di seluruh Indonesia. Nikmati
              <br />
              perjalanan yang aman, nyaman, dan terjangkau.
            </p>
            <button
              onClick={() => onNavigate("register")}
              className="bg-white text-[#2D4CC8] px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-50 transition inline-flex items-center gap-2"
            >
              <Car size={20} />
              Mulai Perjalanan
            </button>
          </div>
          <div className="flex-1 flex justify-center">
            <div className="w-64 h-64 bg-white/10 backdrop-blur-sm rounded-3xl flex items-center justify-center">
              <MapPin size={120} strokeWidth={1.5} />
            </div>
          </div>
        </div>
        <div className="text-center mt-12">
          <svg className="w-8 h-8 mx-auto animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-6 bg-white">
        <div className="max-w-7xl mx-auto grid grid-cols-4 gap-6">
          <div className="bg-white border-t-4 border-[#2D4CC8] rounded-xl p-6 text-center shadow-lg">
            <h2 className="text-5xl font-bold text-[#2D4CC8] mb-2">3</h2>
            <p className="text-gray-600 text-lg">Agen Terpercaya</p>
          </div>
          <div className="bg-white border-t-4 border-[#2D4CC8] rounded-xl p-6 text-center shadow-lg">
            <h2 className="text-5xl font-bold text-[#2D4CC8] mb-2">6</h2>
            <p className="text-gray-600 text-lg">Pengguna Aktif</p>
          </div>
          <div className="bg-white border-t-4 border-[#2D4CC8] rounded-xl p-6 text-center shadow-lg">
            <h2 className="text-5xl font-bold text-[#2D4CC8] mb-2">2</h2>
            <p className="text-gray-600 text-lg">Perjalanan Sukses</p>
          </div>
          <div className="bg-white border-t-4 border-[#2D4CC8] rounded-xl p-6 text-center shadow-lg">
            <h2 className="text-5xl font-bold text-[#2D4CC8] mb-2">50</h2>
            <p className="text-gray-600 text-lg">Kota Tujuan</p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#2D4CC8] mb-4">Mengapa Memilih GoTravel?</h2>
          </div>
          <div className="grid grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl text-center shadow-lg hover:shadow-xl transition">
              <div className="w-16 h-16 bg-[#2D4CC8] rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield size={32} color="white" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-[#2D4CC8]">Aman & Terpercaya</h3>
              <p className="text-gray-600">
                Semua agen travel telah terverifikasi dan memiliki izin resmi. Keamanan perjalanan Anda adalah prioritas
                utama kami.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl text-center shadow-lg hover:shadow-xl transition">
              <div className="w-16 h-16 bg-[#2D4CC8] rounded-full flex items-center justify-center mx-auto mb-4">
                <CreditCard size={32} color="white" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-[#2D4CC8]">Harga Transparan</h3>
              <p className="text-gray-600">
                Bandingkan harga dari berbagai agen travel secara jujur. Tidak ada biaya tersembunyi, semua transparan.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl text-center shadow-lg hover:shadow-xl transition">
              <div className="w-16 h-16 bg-[#2D4CC8] rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock size={32} color="white" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-[#2D4CC8]">Booking Instan</h3>
              <p className="text-gray-600">
                Proses booking yang cepat dan mudah. Konfirmasi langsung tanpa perlu menunggu lama.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl text-center shadow-lg hover:shadow-xl transition">
              <div className="w-16 h-16 bg-[#2D4CC8] rounded-full flex items-center justify-center mx-auto mb-4">
                <Headphones size={32} color="white" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-[#2D4CC8]">Support 24/7</h3>
              <p className="text-gray-600">
                Tim customer service kami siap membantu Anda kapan saja. Hubungi kami melalui berbagai channel
                komunikasi.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl text-center shadow-lg hover:shadow-xl transition">
              <div className="w-16 h-16 bg-[#2D4CC8] rounded-full flex items-center justify-center mx-auto mb-4">
                <Smartphone size={32} color="white" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-[#2D4CC8]">Mobile Friendly</h3>
              <p className="text-gray-600">
                Akses platform kami dari mana saja menggunakan smartphone. Interface yang responsif dan user-friendly.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl text-center shadow-lg hover:shadow-xl transition">
              <div className="w-16 h-16 bg-[#2D4CC8] rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin size={32} color="white" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-[#2D4CC8]">Rute Lengkap</h3>
              <p className="text-gray-600">
                Jangkauan ke seluruh Indonesia dengan berbagai pilihan rute dan jadwal keberangkatan yang fleksibel.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-gradient-to-br from-[#2D4CC8] to-[#4F6FE6] text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Siap Memulai Perjalanan Anda?</h2>
          <p className="text-xl mb-8 opacity-90">
            Bergabunglah dengan ribuan traveler yang telah mempercayai GoTravel untuk perjalanan mereka.
          </p>
          <div className="flex gap-4 justify-center">
            <button
              onClick={() => onNavigate("register")}
              className="bg-white text-[#2D4CC8] px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-50 transition"
            >
              Daftar Sekarang
            </button>
            <button
              onClick={() => onNavigate("agent-registration")}
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white/10 transition"
            >
              Daftar Sebagai Agen
            </button>
          </div>
          <div className="mt-8">
            <p className="mb-2">Sudah punya akun?</p>
            <button onClick={() => onNavigate("login")} className="text-white underline hover:text-blue-200 transition">
              Login di sini
            </button>
            <span className="mx-4">|</span>
            <button className="text-white underline hover:text-blue-200 transition">Daftar Pengguna</button>
          </div>
          <button
            onClick={() => onNavigate("landing")}
            className="mt-8 text-white underline hover:text-blue-200 transition flex items-center gap-2 mx-auto"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Kembali ke Beranda
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1e3a8a] text-white py-12 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Car size={24} />
              <span className="text-xl font-bold">GoTravel</span>
            </div>
            <p className="text-blue-200 text-sm">
              Platform travel terpercaya yang menghubungkan Anda dengan agen travel terbaik di Indonesia.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-4">Layanan</h4>
            <ul className="space-y-2 text-blue-200 text-sm">
              <li>
                <a href="#" className="hover:text-white transition">
                  Booking Travel
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Daftar Agen
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Travel Insurance
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Customer Support
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Perusahaan</h4>
            <ul className="space-y-2 text-blue-200 text-sm">
              <li>
                <a href="#" className="hover:text-white transition">
                  Tentang Kami
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Karir
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Press Release
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Partnership
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Bantuan</h4>
            <ul className="space-y-2 text-blue-200 text-sm">
              <li>
                <a href="#" className="hover:text-white transition">
                  Pusat Bantuan
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Syarat & Ketentuan
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Kebijakan Privasi
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-8 pt-8 border-t border-blue-700 text-center text-blue-200 text-sm">
          © 2025 GoTravel. Semua hak cipta dilindungi undang-undang.
        </div>
      </footer>
    </div>
  )
}
