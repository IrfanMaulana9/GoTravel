"use client"

import { useState } from "react"
import { Car, Plus, List, HelpCircle, LogOut, Eye, X } from "lucide-react"
import BookingModal from "./BookingModal"

export default function UserDashboard({ onNavigate, user }) {
  const [showBookingModal, setShowBookingModal] = useState(false)
  const [selectedRoute, setSelectedRoute] = useState(null)

  const stats = [
    { label: "Total Booking", value: "1", color: "from-blue-500 to-blue-600" },
    { label: "Terkonfirmasi", value: "0", color: "from-green-500 to-green-600" },
    { label: "Menunggu", value: "1", color: "from-yellow-500 to-yellow-600" },
    { label: "Selesai", value: "0", color: "from-gray-500 to-gray-600" },
  ]

  const bookings = [
    {
      code: "TRV20251218CD1C32",
      route: "Bandung → Jakarta",
      vehicle: "Minivan",
      seats: 1,
      date: "19/12/2025",
      time: "14:00 - 17:00",
      agent: "Travel Sejahtera",
      phone: "081234567890",
      price: 75000,
      status: "Menunggu",
    },
  ]

  const handleBooking = (route) => {
    setSelectedRoute(route)
    setShowBookingModal(true)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-[#2D4CC8] text-white px-6 py-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Car size={28} />
            <span className="text-2xl font-bold">GoTravel</span>
          </div>
          <div className="flex gap-4 items-center">
            <span className="text-sm">
              Selamat datang, <strong>{user?.name || "Ahmad Wijaya"}</strong>
            </span>
            <button className="flex items-center gap-2 hover:text-blue-200 transition">
              <Plus size={20} />
              Booking Baru
            </button>
            <button
              onClick={() => onNavigate("logout")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <LogOut size={20} />
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-[#2D4CC8] rounded-full flex items-center justify-center">
            <Car size={24} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800">Dashboard Pengguna</h1>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className={`bg-gradient-to-br ${stat.color} rounded-xl p-6 text-white shadow-lg`}>
              <h2 className="text-5xl font-bold mb-2">{stat.value}</h2>
              <p className="text-lg opacity-90">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center">
              <span className="text-white font-bold">⚡</span>
            </div>
            <h2 className="text-xl font-bold text-gray-800">Aksi Cepat</h2>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <button
              onClick={() => handleBooking(null)}
              className="bg-[#2D4CC8] text-white px-6 py-4 rounded-lg font-semibold hover:bg-[#1e3a8a] transition flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
            >
              <Plus size={20} />
              Booking Baru
            </button>
            <button className="bg-white border-2 border-[#2D4CC8] text-[#2D4CC8] px-6 py-4 rounded-lg font-semibold hover:bg-blue-50 transition flex items-center justify-center gap-2">
              <List size={20} />
              Lihat Semua Booking
            </button>
            <button className="bg-white border-2 border-cyan-500 text-cyan-600 px-6 py-4 rounded-lg font-semibold hover:bg-cyan-50 transition flex items-center justify-center gap-2">
              <HelpCircle size={20} />
              Bantuan
            </button>
          </div>
        </div>

        {/* Booking History */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-[#2D4CC8] to-[#4F6FE6] px-6 py-4 flex items-center gap-2">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <List size={20} className="text-[#2D4CC8]" />
            </div>
            <h2 className="text-xl font-bold text-white">Riwayat Booking</h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b-2 border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Kode Booking</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Rute</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Tanggal</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Waktu</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Agen</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Harga</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Status</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((booking, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50 transition">
                    <td className="px-6 py-4">
                      <div className="font-bold text-gray-800">{booking.code}</div>
                      <div className="text-xs text-gray-500">18/12/2025 04:06</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-semibold text-gray-800">{booking.route}</div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Car size={14} />
                        {booking.vehicle}
                        <span>•</span>
                        <span>{booking.seats} kursi</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-700">{booking.date}</td>
                    <td className="px-6 py-4 text-gray-700">{booking.time}</td>
                    <td className="px-6 py-4">
                      <div className="font-semibold text-gray-800">{booking.agent}</div>
                      <div className="text-xs text-gray-500">☎ {booking.phone}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-bold text-[#2D4CC8]">Rp {booking.price.toLocaleString()}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm font-semibold">
                        {booking.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition">
                          <Eye size={18} />
                        </button>
                        <button className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition">
                          <X size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {showBookingModal && <BookingModal route={selectedRoute} onClose={() => setShowBookingModal(false)} />}
    </div>
  )
}
