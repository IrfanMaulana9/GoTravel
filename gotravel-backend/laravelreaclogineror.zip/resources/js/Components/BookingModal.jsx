"use client"

import { useState } from "react"
import { X, Car, Check } from "lucide-react"

export default function BookingModal({ route, onClose }) {
  const [formData, setFormData] = useState({
    passengerName: "Ahmad Wijaya",
    phone: "",
    email: "",
    seats: 1,
    totalPrice: 75000,
    paymentMethod: "qris",
    notes: "",
  })

  const paymentMethods = [
    { id: "bca", label: "Transfer BCA", icon: "🏦" },
    { id: "bri", label: "Transfer BRI", icon: "🏦" },
    { id: "bni", label: "Transfer BNI", icon: "🏦" },
    { id: "qris", label: "QRIS", icon: "📱" },
  ]

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-6 z-50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#2D4CC8] rounded-lg flex items-center justify-center">
              <Car size={20} className="text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800">Form Booking</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition">
            <X size={24} />
          </button>
        </div>

        <div className="p-6">
          {/* Route Info */}
          <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl p-6 mb-6">
            <h3 className="font-bold text-[#2D4CC8] mb-3">Travel Sejahtera</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-semibold text-gray-700">Bandung → Jakarta</span>
                <div className="text-gray-600">14:00:00 - 17:00:00</div>
              </div>
              <div>
                <span className="font-semibold text-gray-700">Minivan</span>
                <div className="text-[#2D4CC8] font-bold">Rp 75.000</div>
              </div>
            </div>
          </div>

          {/* Passenger Info */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Nama Penumpang *</label>
              <input
                type="text"
                value={formData.passengerName}
                onChange={(e) => setFormData({ ...formData, passengerName: e.target.value })}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Nomor Telepon *</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-semibold text-gray-700 mb-2">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none"
              />
            </div>
          </div>

          {/* Booking Details */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Jumlah Kursi</label>
              <select
                value={formData.seats}
                onChange={(e) => setFormData({ ...formData, seats: Number.parseInt(e.target.value) })}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none"
              >
                <option value="1">1 Kursi</option>
                <option value="2">2 Kursi</option>
                <option value="3">3 Kursi</option>
                <option value="4">4 Kursi</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Total Harga</label>
              <input
                type="text"
                value={`Rp ${formData.totalPrice.toLocaleString()}`}
                readOnly
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg bg-gray-50"
              />
            </div>
          </div>

          {/* Payment Method */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-3">Metode Pembayaran *</label>
            <div className="grid grid-cols-2 gap-3">
              {paymentMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setFormData({ ...formData, paymentMethod: method.id })}
                  className={`p-4 rounded-lg border-2 transition font-semibold flex items-center gap-3 ${
                    formData.paymentMethod === method.id
                      ? "bg-[#2D4CC8] text-white border-[#2D4CC8]"
                      : "bg-white text-gray-700 border-gray-200 hover:border-[#2D4CC8]"
                  }`}
                >
                  <span className="text-2xl">{method.icon}</span>
                  <span>{method.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">Catatan Tambahan</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none"
              rows="3"
              placeholder="Catatan tambahan untuk agen (opsional)"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <button
              onClick={onClose}
              className="flex-1 px-6 py-3 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300 transition"
            >
              Batal
            </button>
            <button className="flex-1 px-6 py-3 bg-[#2D4CC8] text-white rounded-lg font-semibold hover:bg-[#1e3a8a] transition flex items-center justify-center gap-2 shadow-lg hover:shadow-xl">
              <Check size={20} />
              Konfirmasi Booking
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
