"use client"

import { useState } from "react"
import { Car, ArrowLeft, Eye, EyeOff } from "lucide-react"

export default function AgentRegistration({ onNavigate }) {
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    companyName: "",
    businessType: "",
    businessLicense: "",
    foundedYear: "",
    contactName: "",
    contactPhone: "",
    vehicleTypes: [],
    operatingCities: [],
    fleetSize: "",
    username: "",
    email: "",
    password: "",
  })

  const vehicleTypes = ["Minivan", "SUV", "Bus", "Sedan", "Hiace"]
  const cities = [
    "Jakarta",
    "Bandung",
    "Surabaya",
    "Yogyakarta",
    "Semarang",
    "Solo",
    "Malang",
    "Banyuwangi",
    "Bogor",
    "Madiun",
  ]

  const handleCheckbox = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: prev[field].includes(value) ? prev[field].filter((item) => item !== value) : [...prev[field], value],
    }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2D4CC8] to-[#4F6FE6] py-12 px-6">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#2D4CC8] to-[#4F6FE6] text-white p-8 text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <Car size={28} className="text-[#2D4CC8]" />
              </div>
            </div>
            <h1 className="text-3xl font-bold mb-2">Daftar Agen Travel</h1>
            <p className="text-blue-100">Bergabunglah dengan jaringan agen GoTravel</p>
          </div>

          <div className="p-8">
            {/* Informasi Perusahaan */}
            <div className="mb-8">
              <h2 className="text-xl font-bold text-[#2D4CC8] mb-4 border-b-2 border-blue-100 pb-2">
                Informasi Perusahaan
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Nama Perusahaan *</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                    placeholder="Nama perusahaan Anda"
                    value={formData.companyName}
                    onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Jenis Usaha</label>
                  <select
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                    value={formData.businessType}
                    onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                  >
                    <option value="">Pilih jenis usaha</option>
                    <option value="CV">CV</option>
                    <option value="PT">PT</option>
                    <option value="UD">UD</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Nomor Izin Usaha</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                    value={formData.businessLicense}
                    onChange={(e) => setFormData({ ...formData, businessLicense: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Tahun Berdiri</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                    value={formData.foundedYear}
                    onChange={(e) => setFormData({ ...formData, foundedYear: e.target.value })}
                  />
                </div>
              </div>
            </div>

            {/* Informasi Kontak */}
            <div className="mb-8">
              <h2 className="text-xl font-bold text-[#2D4CC8] mb-4 border-b-2 border-blue-100 pb-2">
                Informasi Kontak
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Nama Penanggung Jawab *</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                    value={formData.contactName}
                    onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Nomor Telepon *</label>
                  <input
                    type="tel"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                    value={formData.contactPhone}
                    onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                  />
                </div>
              </div>
            </div>

            {/* Layanan Travel */}
            <div className="mb-8">
              <h2 className="text-xl font-bold text-[#2D4CC8] mb-4 border-b-2 border-blue-100 pb-2">Layanan Travel</h2>
              <div className="mb-4">
                <label className="block text-sm font-semibold text-gray-700 mb-3">Jenis Kendaraan *</label>
                <div className="grid grid-cols-5 gap-3">
                  {vehicleTypes.map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => handleCheckbox("vehicleTypes", type)}
                      className={`px-4 py-3 rounded-lg border-2 transition font-medium ${
                        formData.vehicleTypes.includes(type)
                          ? "bg-[#2D4CC8] text-white border-[#2D4CC8]"
                          : "bg-white text-gray-700 border-gray-200 hover:border-[#2D4CC8]"
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">Kota Beroperasi *</label>
                <div className="grid grid-cols-3 gap-3">
                  {cities.map((city) => (
                    <button
                      key={city}
                      type="button"
                      onClick={() => handleCheckbox("operatingCities", city)}
                      className={`px-4 py-3 rounded-lg border-2 transition font-medium ${
                        formData.operatingCities.includes(city)
                          ? "bg-[#2D4CC8] text-white border-[#2D4CC8]"
                          : "bg-white text-gray-700 border-gray-200 hover:border-[#2D4CC8]"
                      }`}
                    >
                      {city}
                    </button>
                  ))}
                </div>
              </div>
              <div className="mt-4">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Jumlah Armada *</label>
                <input
                  type="number"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                  value={formData.fleetSize}
                  onChange={(e) => setFormData({ ...formData, fleetSize: e.target.value })}
                />
              </div>
            </div>

            {/* Informasi Akun */}
            <div className="mb-8">
              <h2 className="text-xl font-bold text-[#2D4CC8] mb-4 border-b-2 border-blue-100 pb-2">Informasi Akun</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Username *</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
                  <input
                    type="email"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Password *</label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Minimal 6 karakter</p>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button className="w-full bg-[#2D4CC8] text-white py-4 rounded-lg font-bold text-lg hover:bg-[#1e3a8a] transition shadow-lg hover:shadow-xl flex items-center justify-center gap-2">
              <Car size={20} />
              Daftar Sebagai Agen
            </button>

            <div className="mt-6 text-center text-sm text-gray-600">
              Sudah punya akun?{" "}
              <button onClick={() => onNavigate("login")} className="text-[#2D4CC8] font-semibold hover:underline">
                Login di sini
              </button>
              <br />
              Daftar sebagai pengguna?{" "}
              <button className="text-[#2D4CC8] font-semibold hover:underline">Daftar Pengguna</button>
            </div>

            <button
              onClick={() => onNavigate("landing")}
              className="mt-6 w-full text-gray-600 hover:text-gray-800 transition flex items-center justify-center gap-2"
            >
              <ArrowLeft size={16} />
              Kembali ke Beranda
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
