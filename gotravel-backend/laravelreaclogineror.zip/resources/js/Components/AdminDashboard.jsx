"use client"

import { Car, Users, Building, MapPin, LogOut, BarChart3, List, Clock } from "lucide-react"

export default function AdminDashboard({ onNavigate, user }) {
  const stats = [
    { label: "Total Users", value: "6", color: "from-blue-500 to-blue-600", icon: Users },
    { label: "Total Agen", value: "3", color: "from-green-500 to-green-600", icon: Building },
    { label: "Agen Pending", value: "0", color: "from-orange-500 to-orange-600", icon: Building },
    { label: "Total Booking", value: "3", color: "from-blue-600 to-blue-700", icon: BarChart3 },
    { label: "Total Rute", value: "8", color: "from-blue-500 to-blue-600", icon: MapPin },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-[#2D4CC8] text-white px-6 py-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Car size={28} />
            <span className="text-2xl font-bold">GoTravel Admin</span>
          </div>
          <div className="flex gap-4 items-center">
            <span className="text-sm">Admin: admin</span>
            <button className="flex items-center gap-2 hover:text-blue-200 transition">
              <BarChart3 size={20} />
              Dashboard
            </button>
            <button
              onClick={() => onNavigate("manage-agents")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <Building size={20} />
              Kelola Agen
            </button>
            <button
              onClick={() => onNavigate("manage-users")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <Users size={20} />
              Kelola User
            </button>
            <button
              onClick={() => onNavigate("manage-bookings")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <List size={20} />
              Kelola Booking
            </button>
            <button
              onClick={() => onNavigate("logout")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <LogOut size={20} />
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-[#2D4CC8] rounded-full flex items-center justify-center">
            <Car size={24} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800">Admin Dashboard</h1>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-5 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <div
                key={index}
                className={`bg-gradient-to-br ${stat.color} rounded-xl p-6 text-white shadow-lg hover:shadow-xl transition`}
              >
                <h2 className="text-5xl font-bold mb-2">{stat.value}</h2>
                <p className="text-lg opacity-90">{stat.label}</p>
              </div>
            )
          })}
        </div>

        {/* Pending Agents */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
              <Clock size={24} className="text-[#2D4CC8]" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800">Agen Menunggu Persetujuan</h2>
          </div>
          <div className="text-center py-12 text-gray-500">
            <p className="text-lg">Tidak ada agen yang menunggu persetujuan</p>
          </div>
        </div>
      </div>
    </div>
  )
}
