"use client"

import { Car, Building, LogOut, Eye, Edit, Users } from "lucide-react"

export default function ManageAgents({ onNavigate, user }) {
  const stats = [
    { label: "Total Agen", value: "3", color: "from-blue-500 to-blue-600" },
    { label: "Disetujui", value: "3", color: "from-green-500 to-green-600" },
    { label: "Menunggu", value: "0", color: "from-orange-500 to-orange-600" },
    { label: "Ditolak", value: "0", color: "from-red-500 to-red-600" },
  ]

  const agents = [
    {
      name: "Nusantara Travel",
      type: "CV",
      contact: "Jane Smith",
      email: "agent2@example.com",
      phone: "081234567891",
      routes: 3,
      bookings: 3,
      revenue: 1200000,
      registeredDate: "06/07/2025 22:55",
      status: "Disetujui",
    },
    {
      name: "Travel Sejahtera",
      type: "PT",
      contact: "John Doe",
      email: "agent1@example.com",
      phone: "081234567890",
      routes: 6,
      bookings: 6,
      revenue: 0,
      registeredDate: "06/07/2025 22:55",
      status: "Disetujui",
    },
    {
      name: "Test Travel Agency",
      type: "UD",
      contact: "Test Agent",
      email: "test@agent.com",
      phone: "081234567895",
      routes: 2,
      bookings: 0,
      revenue: 0,
      registeredDate: "06/07/2025 22:55",
      status: "Disetujui",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-[#2D4CC8] text-white px-6 py-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Car size={28} />
            <span className="text-2xl font-bold">GoTravel Admin</span>
          </div>
          <div className="flex gap-4 items-center">
            <button
              onClick={() => onNavigate("admin-dashboard")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <Car size={20} />
              Dashboard
            </button>
            <button className="flex items-center gap-2 hover:text-blue-200 transition">
              <Building size={20} />
              Kelola Agen
            </button>
            <button
              onClick={() => onNavigate("manage-users")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <Users size={20} />
              Kelola User
            </button>
            <button className="flex items-center gap-2 hover:text-blue-200 transition">Kelola Booking</button>
            <button
              onClick={() => onNavigate("logout")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <LogOut size={20} />
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-[#2D4CC8] rounded-full flex items-center justify-center">
            <Building size={24} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800">Kelola Agen</h1>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className={`bg-gradient-to-br ${stat.color} rounded-xl p-6 text-white shadow-lg`}>
              <h2 className="text-5xl font-bold mb-2">{stat.value}</h2>
              <p className="text-lg opacity-90">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Agents List */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-[#2D4CC8] to-[#4F6FE6] px-6 py-4 flex items-center gap-2">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <Building size={20} className="text-[#2D4CC8]" />
            </div>
            <h2 className="text-xl font-bold text-white">Daftar Agen</h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b-2 border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Perusahaan</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Kontak</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Statistik</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Tanggal Daftar</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Status</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {agents.map((agent, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50 transition">
                    <td className="px-6 py-4">
                      <div className="font-bold text-gray-800">{agent.name}</div>
                      <div className="text-sm text-gray-600">{agent.type}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-semibold text-gray-800">{agent.contact}</div>
                      <div className="text-xs text-gray-500">✉ {agent.email}</div>
                      <div className="text-xs text-gray-500">☎ {agent.phone}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-700">🚗 {agent.routes} rute</div>
                      <div className="text-sm text-gray-700">📋 {agent.bookings} booking</div>
                      <div className="text-sm font-semibold text-[#2D4CC8]">💰 Rp {agent.revenue.toLocaleString()}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-gray-700">{agent.registeredDate}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
                        {agent.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition">
                          <Eye size={18} />
                        </button>
                        <button className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition relative group">
                          <Edit size={18} />
                          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block">
                            <div className="bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                              Edit
                            </div>
                          </div>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
