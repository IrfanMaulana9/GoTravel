"use client"

import { useState } from "react"
import { Car, Plus, MapPin, List, LogOut, Edit, Power, Trash2 } from "lucide-react"

export default function ManageRoutes({ onNavigate, user }) {
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    fromCity: "",
    toCity: "",
    departureTime: "",
    arrivalTime: "",
    price: "",
    vehicleType: "",
    seats: "",
    description: "",
  })

  const routes = [
    {
      id: 1,
      from: "Jakarta",
      to: "Bandung",
      departure: "08:00",
      arrival: "11:00",
      price: 75000,
      vehicle: "Minivan",
      seats: 8,
      available: 8,
      status: "Aktif",
      description: "Perjalanan nyaman Jakarta-Bandung dengan AC dan WiFi",
    },
    {
      id: 2,
      from: "Bandung",
      to: "Jakarta",
      departure: "14:00",
      arrival: "17:00",
      price: 75000,
      vehicle: "Minivan",
      seats: 8,
      available: 6,
      status: "Aktif",
      description: "Perjalanan nyaman Bandung-Jakarta dengan AC dan WiFi",
    },
    {
      id: 3,
      from: "Jakarta",
      to: "Bogor",
      departure: "09:00",
      arrival: "10:30",
      price: 35000,
      vehicle: "Minivan",
      seats: 8,
      available: 8,
      status: "Aktif",
      description: "Rute cepat Jakarta-Bogor",
    },
  ]

  const cities = ["Jakarta", "Bandung", "Surabaya", "Yogyakarta", "Semarang", "Solo", "Malang", "Bogor"]
  const vehicleTypes = ["Minivan", "SUV", "Bus", "Sedan", "Hiace"]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-[#2D4CC8] text-white px-6 py-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Car size={28} />
            <span className="text-2xl font-bold">GoTravel</span>
          </div>
          <div className="flex gap-4 items-center">
            <button className="flex items-center gap-2 hover:text-blue-200 transition">
              <MapPin size={20} />
              Dashboard
            </button>
            <button
              onClick={() => onNavigate("logout")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <LogOut size={20} />
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-[#2D4CC8] rounded-full flex items-center justify-center">
            <MapPin size={24} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800">Kelola Rute</h1>
        </div>

        {/* Add Route Form */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 text-[#2D4CC8] font-semibold text-lg mb-4"
          >
            <Plus size={20} />
            Tambah Rute Baru
          </button>

          {showForm && (
            <div className="border-t pt-6">
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Kota Asal *</label>
                  <select className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none">
                    <option value="">Pilih kota asal</option>
                    {cities.map((city) => (
                      <option key={city} value={city}>
                        {city}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Kota Tujuan *</label>
                  <select className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none">
                    <option value="">Pilih kota tujuan</option>
                    {cities.map((city) => (
                      <option key={city} value={city}>
                        {city}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Waktu Berangkat *</label>
                  <input
                    type="time"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Waktu Tiba *</label>
                  <input
                    type="time"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Harga (Rp) *</label>
                  <input
                    type="number"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Jenis Kendaraan *</label>
                  <select className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none">
                    <option value="">Pilih kendaraan</option>
                    {vehicleTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Jumlah Kursi *</label>
                  <input
                    type="number"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none"
                  />
                </div>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Deskripsi</label>
                <textarea
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none"
                  rows="3"
                  placeholder="Deskripsi tambahan tentang rute ini..."
                />
              </div>
              <button className="bg-[#2D4CC8] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#1e3a8a] transition flex items-center gap-2">
                <Plus size={20} />
                Tambah Rute
              </button>
            </div>
          )}
        </div>

        {/* Routes List */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <List size={24} className="text-[#2D4CC8]" />
            <h2 className="text-2xl font-bold text-gray-800">Daftar Rute Anda</h2>
          </div>
        </div>

        <div className="grid gap-6">
          {routes.map((route) => (
            <div
              key={route.id}
              className="bg-white rounded-xl shadow-lg border-l-4 border-[#2D4CC8] overflow-hidden hover:shadow-xl transition"
            >
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-2xl font-bold text-gray-800">
                        {route.from} → {route.to}
                      </h3>
                      <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
                        {route.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600 mb-3">
                      <Car size={18} />
                      <span className="font-medium">{route.vehicle}</span>
                      <span className="mx-2">•</span>
                      <span>
                        {route.available}/{route.seats} kursi tersedia
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-600 mb-1">Harga</div>
                    <div className="text-2xl font-bold text-[#2D4CC8]">Rp {route.price.toLocaleString()}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="text-xs text-gray-600 mb-1">Berangkat</div>
                    <div className="text-xl font-bold text-gray-800">{route.departure}</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="text-xs text-gray-600 mb-1">Tiba</div>
                    <div className="text-xl font-bold text-gray-800">{route.arrival}</div>
                  </div>
                </div>

                <div className="bg-blue-50 p-3 rounded-lg mb-4">
                  <p className="text-gray-700 text-sm">{route.description}</p>
                </div>

                <div className="flex gap-3">
                  <button className="flex-1 bg-white border-2 border-[#2D4CC8] text-[#2D4CC8] px-4 py-2 rounded-lg font-semibold hover:bg-blue-50 transition flex items-center justify-center gap-2">
                    <Edit size={18} />
                    Edit
                  </button>
                  <button className="flex-1 bg-yellow-500 text-white px-4 py-2 rounded-lg font-semibold hover:bg-yellow-600 transition flex items-center justify-center gap-2">
                    <Power size={18} />
                    Nonaktifkan
                  </button>
                  <button className="flex-1 bg-red-500 text-white px-4 py-2 rounded-lg font-semibold hover:bg-red-600 transition flex items-center justify-center gap-2">
                    <Trash2 size={18} />
                    Hapus
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
