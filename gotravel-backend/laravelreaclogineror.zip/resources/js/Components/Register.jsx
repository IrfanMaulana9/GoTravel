"use client"

import { useState } from "react"
import { Car, Eye, EyeOff } from "lucide-react"

export default function Register({ onNavigate }) {
  const [showPassword, setShowPassword] = useState(false)

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2D4CC8] to-[#4F6FE6] flex items-center justify-center px-6 py-12">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Car size={32} className="text-[#2D4CC8]" />
            <span className="text-3xl font-bold text-[#2D4CC8]">GoTravel</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-800">Daftar Akun Baru</h2>
          <p className="text-gray-600">Buat akun untuk memulai perjalanan</p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Nama Lengkap</label>
            <input
              type="text"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
              placeholder="Masukkan nama lengkap"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Email</label>
            <input
              type="email"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
              placeholder="nama@email.com"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Nomor Telepon</label>
            <input
              type="tel"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
              placeholder="08123456789"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-lg focus:border-[#2D4CC8] focus:outline-none transition"
                placeholder="Minimal 6 karakter"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          <button className="w-full bg-[#2D4CC8] text-white py-3 rounded-lg font-bold hover:bg-[#1e3a8a] transition shadow-lg hover:shadow-xl">
            Daftar
          </button>
        </div>

        <div className="mt-6 text-center text-sm text-gray-600">
          Sudah punya akun?{" "}
          <button onClick={() => onNavigate("login")} className="text-[#2D4CC8] font-semibold hover:underline">
            Login di sini
          </button>
        </div>

        <button
          onClick={() => onNavigate("landing")}
          className="mt-6 w-full text-gray-600 hover:text-gray-800 transition"
        >
          Kembali ke Beranda
        </button>
      </div>
    </div>
  )
}
