"use client"

import { Car, Users, LogOut, Eye, Edit, Building } from "lucide-react"

export default function ManageUsers({ onNavigate, user }) {
  const stats = [
    { label: "Total User", value: "6", color: "from-blue-500 to-blue-600" },
    { label: "Aktif", value: "6", color: "from-green-500 to-green-600" },
    { label: "Tidak Aktif", value: "0", color: "from-orange-500 to-orange-600" },
    { label: "Ditangguhkan", value: "0", color: "from-red-500 to-red-600" },
  ]

  const users = [
    {
      name: "lala",
      joined: "29/10/2025",
      email: "lala@gmail.com",
      phone: "0219419",
      bookings: 0,
      revenue: 0,
      lastBooking: "Belum pernah booking",
      status: "Aktif",
    },
    {
      name: "rarasiu",
      joined: "30/09/2025",
      email: "rara@gmail.com",
      phone: "01828421",
      bookings: 1,
      revenue: 0,
      lastBooking: "30/09/2025",
      status: "Aktif",
    },
    {
      name: "papa",
      joined: "06/07/2025",
      email: "jklfsa@gmail.com",
      phone: "09821",
      bookings: 1,
      revenue: 400000,
      lastBooking: "07/07/2025",
      status: "Aktif",
    },
    {
      name: "Siti Nurhaliza",
      joined: "06/07/2025",
      email: "user2@example.com",
      phone: "081234567893",
      bookings: 0,
      revenue: 0,
      lastBooking: "Belum pernah booking",
      status: "Aktif",
    },
    {
      name: "Test User",
      joined: "06/07/2025",
      email: "test@user.com",
      phone: "081234567894",
      bookings: 0,
      revenue: 0,
      lastBooking: "Belum pernah booking",
      status: "Aktif",
    },
    {
      name: "Ahmad Wijaya",
      joined: "06/07/2025",
      email: "user1@example.com",
      phone: "081234567892",
      bookings: 1,
      revenue: 0,
      lastBooking: "18/12/2025",
      status: "Aktif",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-[#2D4CC8] text-white px-6 py-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Car size={28} />
            <span className="text-2xl font-bold">GoTravel Admin</span>
          </div>
          <div className="flex gap-4 items-center">
            <button
              onClick={() => onNavigate("admin-dashboard")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <Car size={20} />
              Dashboard
            </button>
            <button
              onClick={() => onNavigate("manage-agents")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <Building size={20} />
              Kelola Agen
            </button>
            <button className="flex items-center gap-2 hover:text-blue-200 transition">
              <Users size={20} />
              Kelola User
            </button>
            <button className="flex items-center gap-2 hover:text-blue-200 transition">Kelola Booking</button>
            <button
              onClick={() => onNavigate("logout")}
              className="flex items-center gap-2 hover:text-blue-200 transition"
            >
              <LogOut size={20} />
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-[#2D4CC8] rounded-full flex items-center justify-center">
            <Users size={24} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800">Kelola User</h1>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className={`bg-gradient-to-br ${stat.color} rounded-xl p-6 text-white shadow-lg`}>
              <h2 className="text-5xl font-bold mb-2">{stat.value}</h2>
              <p className="text-lg opacity-90">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Users List */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-[#2D4CC8] to-[#4F6FE6] px-6 py-4 flex items-center gap-2">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <Users size={20} className="text-[#2D4CC8]" />
            </div>
            <h2 className="text-xl font-bold text-white">Daftar User</h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b-2 border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">User</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Kontak</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Statistik Booking</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Status</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50 transition">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#2D4CC8] rounded-full flex items-center justify-center text-white font-bold">
                          {u.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-bold text-gray-800">{u.name}</div>
                          <div className="text-xs text-gray-500">Bergabung: {u.joined}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-700">✉ {u.email}</div>
                      <div className="text-sm text-gray-700">☎ {u.phone}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-700">📋 {u.bookings} booking</div>
                      <div className="text-sm font-semibold text-[#2D4CC8]">💰 Rp {u.revenue.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">⏰ {u.lastBooking}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
                        {u.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition">
                          <Eye size={18} />
                        </button>
                        <button className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition">
                          <Edit size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
