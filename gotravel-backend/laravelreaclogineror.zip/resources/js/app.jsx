import "../css/app.css"
import "./bootstrap"
import { createRoot } from "react-dom/client"
import { createInertiaApp } from "@inertiajs/react"

console.log("[v0] Initializing Inertia app...")

createInertiaApp({
  resolve: (name) => {
    console.log("[v0] Resolving page:", name)
    const pages = import.meta.glob("./Pages/**/*.jsx", { eager: true })
    const page = pages[`./Pages/${name}.jsx`]
    console.log("[v0] Page found:", !!page)
    return page
  },
  setup({ el, App, props }) {
    console.log("[v0] Setting up React app with props:", props)
    createRoot(el).render(<App {...props} />)
  },
  progress: {
    color: "#2b5ed7",
  },
})
