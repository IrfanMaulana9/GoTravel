import { Link } from "@inertiajs/react"

export default function AuthenticatedLayout({ header, children }) {
  return (
    <div style={{ minHeight: "100vh", background: "#f9fafb" }}>
      <nav style={{ background: "#2b5ed7", borderBottom: "1px solid #1e3a8a" }}>
        <div
          style={{
            maxWidth: "1280px",
            margin: "0 auto",
            padding: "0 1rem",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              height: "64px",
            }}
          >
            <div style={{ display: "flex", alignItems: "center" }}>
              <Link
                href="/"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.5rem",
                  textDecoration: "none",
                }}
              >
                <span style={{ fontSize: "1.5rem" }}>🚗</span>
                <span
                  style={{
                    fontSize: "1.25rem",
                    fontWeight: "700",
                    color: "white",
                  }}
                >
                  GoTravel
                </span>
              </Link>

              <div style={{ marginLeft: "2rem", display: "flex", gap: "1rem" }}>
                <Link
                  href="/dashboard"
                  style={{
                    padding: "0.5rem 1rem",
                    color: "white",
                    textDecoration: "none",
                    borderBottom: "2px solid transparent",
                    transition: "border-color 0.2s",
                  }}
                >
                  Dashboard
                </Link>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
              <Link
                href="/profile"
                style={{
                  padding: "0.5rem 1rem",
                  color: "white",
                  textDecoration: "none",
                }}
              >
                Profile
              </Link>
              <Link
                href="/logout"
                method="post"
                as="button"
                style={{
                  padding: "0.5rem 1rem",
                  background: "rgba(255,255,255,0.1)",
                  color: "white",
                  border: "none",
                  borderRadius: "0.375rem",
                  cursor: "pointer",
                }}
              >
                Log Out
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {header && (
        <header style={{ background: "white", boxShadow: "0 1px 2px 0 rgba(0,0,0,0.05)" }}>
          <div
            style={{
              maxWidth: "1280px",
              margin: "0 auto",
              padding: "1.5rem 1rem",
            }}
          >
            {header}
          </div>
        </header>
      )}

      <main>{children}</main>
    </div>
  )
}
