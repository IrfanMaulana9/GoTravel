import { Head, Link } from "@inertiajs/react"

export default function Welcome({ auth, laravelVersion, phpVersion }) {
  return (
    <>
      <Head title="Welcome to GoTravel" />
      <div
        style={{
          minHeight: "100vh",
          background: "linear-gradient(135deg, #2b5ed7 0%, #1e3a8a 100%)",
        }}
      >
        {/* Header */}
        <header style={{ padding: "1rem 0", background: "rgba(255,255,255,0.1)" }}>
          <div
            className="container"
            style={{
              maxWidth: "1200px",
              margin: "0 auto",
              padding: "0 1rem",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
              <div
                style={{
                  width: "40px",
                  height: "40px",
                  background: "white",
                  borderRadius: "0.5rem",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <span style={{ fontSize: "1.5rem" }}>🚗</span>
              </div>
              <h1 style={{ color: "white", fontSize: "1.5rem", fontWeight: "700" }}>GoTravel</h1>
            </div>
            <nav style={{ display: "flex", gap: "1rem", alignItems: "center" }}>
              {auth.user ? (
                <Link
                  href="/dashboard"
                  style={{
                    padding: "0.5rem 1.5rem",
                    background: "white",
                    color: "#2b5ed7",
                    borderRadius: "0.5rem",
                    textDecoration: "none",
                    fontWeight: "600",
                  }}
                >
                  Dashboard
                </Link>
              ) : (
                <>
                  <Link
                    href="/login"
                    style={{
                      padding: "0.5rem 1.5rem",
                      background: "transparent",
                      color: "white",
                      border: "2px solid white",
                      borderRadius: "0.5rem",
                      textDecoration: "none",
                      fontWeight: "600",
                    }}
                  >
                    Log in
                  </Link>
                  <Link
                    href="/register"
                    style={{
                      padding: "0.5rem 1.5rem",
                      background: "white",
                      color: "#2b5ed7",
                      borderRadius: "0.5rem",
                      textDecoration: "none",
                      fontWeight: "600",
                    }}
                  >
                    Register
                  </Link>
                </>
              )}
            </nav>
          </div>
        </header>

        {/* Hero Section */}
        <section style={{ padding: "4rem 0" }}>
          <div className="container" style={{ maxWidth: "1200px", margin: "0 auto", padding: "0 1rem" }}>
            <div style={{ textAlign: "center", maxWidth: "800px", margin: "0 auto" }}>
              <h2
                style={{
                  fontSize: "3rem",
                  fontWeight: "800",
                  color: "white",
                  marginBottom: "1rem",
                }}
              >
                Jelajahi Indonesia dengan <span style={{ color: "#fbbf24" }}>GoTravel</span>
              </h2>
              <p
                style={{
                  fontSize: "1.25rem",
                  color: "rgba(255,255,255,0.9)",
                  marginBottom: "2rem",
                }}
              >
                Platform travel terpercaya yang menghubungkan Anda dengan agen travel terbaik di seluruh Indonesia.
                Nikmati perjalanan yang aman, nyaman, dan terjangkau.
              </p>
              <Link
                href="/register"
                style={{
                  display: "inline-block",
                  padding: "1rem 2rem",
                  background: "white",
                  color: "#2b5ed7",
                  borderRadius: "0.5rem",
                  textDecoration: "none",
                  fontWeight: "700",
                  fontSize: "1.125rem",
                }}
              >
                🚀 Mulai Perjalanan
              </Link>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section style={{ padding: "3rem 0" }}>
          <div
            className="container"
            style={{
              maxWidth: "1200px",
              margin: "0 auto",
              padding: "0 1rem",
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
              gap: "2rem",
            }}
          >
            {[
              { number: "3", label: "Agen Terpercaya" },
              { number: "6", label: "Pengguna Aktif" },
              { number: "2", label: "Perjalanan Sukses" },
              { number: "50", label: "Kota Tujuan" },
            ].map((stat, index) => (
              <div
                key={index}
                style={{
                  background: "white",
                  padding: "2rem",
                  borderRadius: "1rem",
                  textAlign: "center",
                  boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
                }}
              >
                <div
                  style={{
                    fontSize: "2.5rem",
                    fontWeight: "800",
                    color: "#2b5ed7",
                    marginBottom: "0.5rem",
                  }}
                >
                  {stat.number}
                </div>
                <div style={{ color: "#6b7280", fontWeight: "500" }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Footer */}
        <footer style={{ padding: "2rem 0", marginTop: "4rem", background: "rgba(0,0,0,0.2)" }}>
          <div
            className="container"
            style={{
              maxWidth: "1200px",
              margin: "0 auto",
              padding: "0 1rem",
              textAlign: "center",
              color: "white",
            }}
          >
            <p>© 2025 GoTravel. Platform travel terpercaya di Indonesia.</p>
            <p style={{ marginTop: "0.5rem", opacity: 0.7 }}>
              Laravel v{laravelVersion} | PHP v{phpVersion}
            </p>
          </div>
        </footer>
      </div>
    </>
  )
}
