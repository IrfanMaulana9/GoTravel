import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout"
import { Head } from "@inertiajs/react"

export default function Edit({ mustVerifyEmail, status }) {
  return (
    <AuthenticatedLayout header={<h2 className="text-xl font-semibold leading-tight text-gray-800">Profile</h2>}>
      <Head title="Profile" />

      <div className="py-12">
        <div className="mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8">
          <div className="bg-white p-4 shadow sm:rounded-lg sm:p-8">
            <div style={{ maxWidth: "600px" }}>
              <h3 style={{ fontSize: "1.125rem", fontWeight: "600", marginBottom: "1rem" }}>Profile Information</h3>
              <p style={{ color: "#6b7280", marginBottom: "1rem" }}>
                Update your account's profile information and email address.
              </p>
              {status === "profile-updated" && (
                <div
                  style={{
                    padding: "0.75rem",
                    background: "#dcfce7",
                    color: "#166534",
                    borderRadius: "0.5rem",
                    marginBottom: "1rem",
                  }}
                >
                  Profile updated successfully.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AuthenticatedLayout>
  )
}
