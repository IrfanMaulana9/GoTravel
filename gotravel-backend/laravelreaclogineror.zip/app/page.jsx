"use client"

import { useState } from "react"
import LandingPage from "../components/LandingPage"
import Login from "../components/Login"
import Register from "../components/Register"
import AdminDashboard from "../components/AdminDashboard"
import AgentDashboard from "../components/AgentDashboard"
import UserDashboard from "../components/UserDashboard"
import ManageRoutes from "../components/ManageRoutes"
import ManageAgents from "../components/ManageAgents"
import ManageUsers from "../components/ManageUsers"
import AgentRegistration from "../components/AgentRegistration"

export default function Home() {
  const [currentPage, setCurrentPage] = useState("landing")
  const [user, setUser] = useState(null)

  const renderPage = () => {
    switch (currentPage) {
      case "landing":
        return <LandingPage onNavigate={setCurrentPage} />
      case "login":
        return <Login onNavigate={setCurrentPage} setUser={setUser} />
      case "register":
        return <Register onNavigate={setCurrentPage} />
      case "agent-registration":
        return <AgentRegistration onNavigate={setCurrentPage} />
      case "admin-dashboard":
        return <AdminDashboard onNavigate={setCurrentPage} user={user} />
      case "agent-dashboard":
        return <AgentDashboard onNavigate={setCurrentPage} user={user} />
      case "user-dashboard":
        return <UserDashboard onNavigate={setCurrentPage} user={user} />
      case "manage-routes":
        return <ManageRoutes onNavigate={setCurrentPage} user={user} />
      case "manage-agents":
        return <ManageAgents onNavigate={setCurrentPage} user={user} />
      case "manage-users":
        return <ManageUsers onNavigate={setCurrentPage} user={user} />
      default:
        return <LandingPage onNavigate={setCurrentPage} />
    }
  }

  return <main>{renderPage()}</main>
}
