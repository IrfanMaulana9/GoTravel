import "./globals.css"

export const metadata = {
  title: "GoTravel - Platform Travel Terpercaya Indonesia",
  description: "Platform travel terpercaya yang menghubungkan Anda dengan agen travel terbaik di seluruh Indonesia",
  generator: "GoTravel",
}

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
