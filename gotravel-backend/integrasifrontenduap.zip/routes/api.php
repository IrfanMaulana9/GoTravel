<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TravelController;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::prefix('auth')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:api');
    Route::get('/me', [AuthController::class, 'me'])->middleware('auth:api');
});

Route::prefix('travels')->group(function () {
    Route::get('/', [TravelController::class, 'index']);           // GET /api/travels - Public
    Route::get('/cities', [TravelController::class, 'getCities']); // GET /api/travels/cities - Public
    Route::get('/{id}', [TravelController::class, 'show']);        // GET /api/travels/{id} - Public

    // Protected routes (requires authentication)
    Route::middleware('auth:api')->group(function () {
        Route::post('/', [TravelController::class, 'store']);          // POST /api/travels - Auth required
        Route::put('/{id}', [TravelController::class, 'update']);      // PUT /api/travels/{id} - Auth required
        Route::patch('/{id}', [TravelController::class, 'update']);    // PATCH /api/travels/{id} - Auth required
        Route::delete('/{id}', [TravelController::class, 'destroy']);  // DELETE /api/travels/{id} - Auth required
    });
});

// Route untuk frontend Gotravel
Route::prefix('v1')->group(function () {
    Route::get('/travels/search', [TravelController::class, 'index']); // Compatible with frontend - Public
});
