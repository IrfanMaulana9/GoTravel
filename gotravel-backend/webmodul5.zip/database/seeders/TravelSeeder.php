<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Travel;
use Illuminate\Support\Facades\DB;

class TravelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Clear existing data
        DB::table('travels')->truncate();

        $travels = [
            // Jakarta - Bandung Routes
            [
                'agent_name' => 'Jaya Travel',
                'from_city' => 'Jakarta',
                'to_city' => 'Bandung',
                'depart_time' => '08:00',
                'arrival_time' => '11:30',
                'duration' => '3.5 jam',
                'price' => 150000,
                'seats' => 8,
                'type' => 'Shuttle Car',
                'rating' => 4.8,
                'reviews' => 245,
                'facilities' => 'AC, WiFi, USB Charger',
                'image' => '🚐',
                'description' => 'Travel nyaman dengan fasilitas lengkap',
            ],
            [
                'agent_name' => 'Mitra Jaya',
                'from_city' => 'Jakarta',
                'to_city' => 'Bandung',
                'depart_time' => '09:00',
                'arrival_time' => '12:30',
                'duration' => '3.5 jam',
                'price' => 140000,
                'seats' => 6,
                'type' => 'Private Car',
                'rating' => 4.6,
                'reviews' => 189,
                'facilities' => 'AC, Minuman Gratis',
                'image' => '🚗',
                'description' => 'Private car eksklusif',
            ],
            // Surabaya - Malang Routes
            [
                'agent_name' => 'Ekspres Utama',
                'from_city' => 'Surabaya',
                'to_city' => 'Malang',
                'depart_time' => '07:30',
                'arrival_time' => '09:30',
                'duration' => '2 jam',
                'price' => 80000,
                'seats' => 10,
                'type' => 'Shuttle Car',
                'rating' => 4.7,
                'reviews' => 312,
                'facilities' => 'AC, WiFi, USB Charger, Snack',
                'image' => '🚐',
                'description' => 'Travel cepat Surabaya-Malang',
            ],
            // Yogyakarta - Solo Routes
            [
                'agent_name' => 'Nyaman Travel',
                'from_city' => 'Yogyakarta',
                'to_city' => 'Solo',
                'depart_time' => '10:00',
                'arrival_time' => '11:30',
                'duration' => '1.5 jam',
                'price' => 120000,
                'seats' => 8,
                'type' => 'Shuttle Car',
                'rating' => 4.5,
                'reviews' => 198,
                'facilities' => 'AC, Minuman Gratis',
                'image' => '🚐',
                'description' => 'Travel antar kota budaya',
            ],
            // Medan - Kuala Lumpur Routes
            [
                'agent_name' => 'Aman Jaya',
                'from_city' => 'Medan',
                'to_city' => 'Kuala Lumpur',
                'depart_time' => '06:00',
                'arrival_time' => '18:00',
                'duration' => '12 jam',
                'price' => 350000,
                'seats' => 7,
                'type' => 'Shuttle Car',
                'rating' => 4.7,
                'reviews' => 267,
                'facilities' => 'AC, WiFi, USB Charger, Makan, Air Mineral',
                'image' => '🚐',
                'description' => 'Travel internasional Medan-KL',
            ],
            // Bandung - Garut Routes
            [
                'agent_name' => 'Cepat Jaya',
                'from_city' => 'Bandung',
                'to_city' => 'Garut',
                'depart_time' => '07:00',
                'arrival_time' => '09:00',
                'duration' => '2 jam',
                'price' => 100000,
                'seats' => 5,
                'type' => 'Private Car',
                'rating' => 4.9,
                'reviews' => 156,
                'facilities' => 'AC, WiFi, USB Charger, Minuman Gratis, Snack',
                'image' => '🚗',
                'description' => 'Private car Bandung-Garut',
            ],
        ];

        foreach ($travels as $travel) {
            Travel::create($travel);
        }

        $this->command->info('Data travel berhasil di-seed!');
    }
}