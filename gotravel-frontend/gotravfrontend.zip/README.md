# MayTravel Frontend - React.js

Frontend aplikasi travel booking yang terintegrasi dengan Laravel backend API.

## Tech Stack

- **Framework**: Next.js 16 (App Router)
- **Language**: JavaScript (JSX)
- **Styling**: Tailwind CSS
- **UI Components**: shadcn/ui
- **HTTP Client**: Axios
- **State Management**: React Context API
- **Icons**: Lucide React

## Struktur Folder

```
├── app/                    # Next.js App Router pages
│   ├── page.jsx           # Homepage
│   ├── login/             # Login page
│   ├── register/          # Register page
│   ├── travels/           # Travel list & detail pages
│   └── layout.jsx         # Root layout
├── components/            # Reusable components
│   └── ui/               # shadcn/ui components
├── contexts/              # React Context
│   └── AuthContext.jsx   # Authentication context
├── lib/
│   ├── api.js            # API client & functions
│   └── utils.ts          # Utility functions
└── public/               # Static assets
```

## Fitur

### 1. Authentication
- **Register**: `/register` - Pendaftaran user baru
- **Login**: `/login` - Login dengan email & password
- **Logout**: Auto logout ketika token expired
- **Protected Routes**: Otomatis redirect ke login jika belum auth

### 2. Travel Management
- **List Travel**: `/travels` - Menampilkan semua travel dengan filter
- **Detail Travel**: `/travels/[id]` - Detail informasi travel
- **Search & Filter**: Filter berdasarkan kota, tipe, harga, dll
- **Pagination**: Navigate antar halaman hasil pencarian

## API Integration

### Base URL Configuration

```javascript
// .env.local
NEXT_PUBLIC_API_URL=http://localhost:8000/api
NEXT_PUBLIC_STORAGE_URL=http://localhost:8000/storage
```

### Authentication Flow

1. **Register**
```javascript
POST /api/auth/register
Body: { name, email, password, password_confirmation }
Response: { success, message, user }
```

2. **Login**
```javascript
POST /api/auth/login
Body: { email, password }
Response: { success, access_token, token_type, expires_in, user }
```

3. **Logout**
```javascript
POST /api/auth/logout
Headers: Authorization: Bearer {token}
Response: { success, message }
```

4. **Get User Info**
```javascript
GET /api/auth/me
Headers: Authorization: Bearer {token}
Response: { success, user }
```

### Travel API

1. **Get All Travels**
```javascript
GET /api/travels?search=&from_city=&to_city=&type=&min_price=&max_price=&sort_by=&order_by=&page=1&limit=10
Response: { success, data: [], pagination: {...}, filters: {...} }
```

2. **Get Travel Detail**
```javascript
GET /api/travels/{id}
Response: { success, data: {...} }
```

3. **Get Cities**
```javascript
GET /api/travels/cities
Response: { success, data: { all_cities: [], from_cities: [], to_cities: [] } }
```

4. **Create Travel** (Auth Required)
```javascript
POST /api/travels
Headers: Authorization: Bearer {token}
Body: FormData with travel data
Response: { success, message, data: {...} }
```

5. **Update Travel** (Auth Required)
```javascript
PATCH /api/travels/{id}
Headers: Authorization: Bearer {token}
Body: FormData with travel data
Response: { success, message, data: {...} }
```

6. **Delete Travel** (Auth Required)
```javascript
DELETE /api/travels/{id}
Headers: Authorization: Bearer {token}
Response: { success, message }
```

## Setup & Installation

### 1. Install Dependencies

```bash
npm install
# atau
pnpm install
```

### 2. Configure Environment

Buat file `.env.local` dan sesuaikan URL backend:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000/api
NEXT_PUBLIC_STORAGE_URL=http://localhost:8000/storage
```

### 3. Run Development Server

```bash
npm run dev
# atau
pnpm dev
```

Aplikasi akan berjalan di `http://localhost:3000`

## Backend Laravel Setup

### 1. Install Laravel Backend

```bash
cd laravel-backend
composer install
```

### 2. Configure Database

Edit `.env` file:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=maytravel
DB_USERNAME=root
DB_PASSWORD=
```

### 3. Run Migrations & Seeders

```bash
php artisan migrate
php artisan db:seed --class=TravelSeeder
```

### 4. Configure JWT

```bash
php artisan jwt:secret
```

### 5. Storage Link

```bash
php artisan storage:link
```

### 6. Run Laravel Server

```bash
php artisan serve
```

Backend akan berjalan di `http://localhost:8000`

## CORS Configuration

Tambahkan di `config/cors.php` (Laravel):

```php
'paths' => ['api/*', 'sanctum/csrf-cookie'],
'allowed_origins' => ['http://localhost:3000'],
'allowed_methods' => ['*'],
'allowed_headers' => ['*'],
'exposed_headers' => [],
'max_age' => 0,
'supports_credentials' => true,
```

## Authentication Storage

- **Token**: Disimpan di `localStorage` dengan key `token`
- **User Data**: Disimpan di `localStorage` dengan key `user`
- **Auto Logout**: Token akan otomatis dihapus ketika API return 401

## Error Handling

Semua error dari API akan ditangani oleh Axios interceptor:
- **401 Unauthorized**: Auto logout & redirect ke login
- **422 Validation Error**: Tampilkan error validation
- **500 Server Error**: Tampilkan pesan error umum

## Notes

1. Pastikan Laravel backend sudah running sebelum menjalankan frontend
2. Sesuaikan `NEXT_PUBLIC_API_URL` dengan URL backend Anda
3. Untuk production, ganti URL di `.env.local` dengan URL production
4. JWT token memiliki expiration time sesuai konfigurasi di Laravel

## Deployment

### Vercel (Recommended untuk Next.js)

```bash
vercel
```

Jangan lupa set environment variables di Vercel dashboard.

### Laravel Backend Deployment

Deploy backend Laravel ke hosting yang support PHP 8.1+ dan MySQL.
