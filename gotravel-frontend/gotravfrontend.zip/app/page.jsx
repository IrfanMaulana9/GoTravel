"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useAuth } from "@/contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { Bus, Search, Shield, Clock, Users, Star, MapPin, Phone, Mail, ChevronDown, Car } from "lucide-react"

export default function HomePage() {
  const { user, isAuthenticated } = useAuth()
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      {/* Navigation */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? "glass-effect shadow-lg py-3" : "bg-transparent py-5"
        }`}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3 group">
              <div className="w-11 h-11 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                <Bus className="w-6 h-6 text-white" />
              </div>
              <span
                className={`text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent ${scrolled ? "" : "text-white"}`}
              >
                GoTravel
              </span>
            </Link>

            <div className="hidden md:flex items-center gap-6">
              <a
                href="#home"
                className={`${scrolled ? "text-foreground" : "text-white"} hover:text-primary transition-colors font-medium`}
              >
                Beranda
              </a>
              <a
                href="#features"
                className={`${scrolled ? "text-foreground" : "text-white"} hover:text-primary transition-colors font-medium`}
              >
                Fitur
              </a>
              <a
                href="#about"
                className={`${scrolled ? "text-foreground" : "text-white"} hover:text-primary transition-colors font-medium`}
              >
                Tentang
              </a>
              <a
                href="#contact"
                className={`${scrolled ? "text-foreground" : "text-white"} hover:text-primary transition-colors font-medium`}
              >
                Kontak
              </a>

              {isAuthenticated ? (
                <Link
                  href={
                    user?.role === "admin"
                      ? "/admin/dashboard"
                      : user?.role === "agent"
                        ? "/agent/dashboard"
                        : "/dashboard"
                  }
                >
                  <Button className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 shadow-lg">
                    <Users className="w-4 h-4 mr-2" />
                    Dashboard
                  </Button>
                </Link>
              ) : (
                <div className="flex items-center gap-3">
                  <Link href="/login">
                    <Button variant="ghost" className={scrolled ? "" : "text-white hover:bg-white/10"}>
                      Masuk
                    </Button>
                  </Link>
                  <Link href="/register">
                    <Button className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 shadow-lg">
                      Daftar
                    </Button>
                  </Link>
                  <Link href="/agent/register">
                    <Button
                      variant="outline"
                      className={`border-2 ${scrolled ? "border-primary text-primary" : "border-white text-white"} hover:bg-primary hover:text-white`}
                    >
                      Daftar Agen
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section
        id="home"
        className="relative min-h-screen flex items-center bg-gradient-to-br from-primary via-blue-600 to-secondary overflow-hidden"
      >
        {/* Animated background elements */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-72 h-72 bg-white rounded-full blur-3xl animate-pulse"></div>
          <div
            className="absolute bottom-20 right-20 w-96 h-96 bg-teal-300 rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1.5s" }}
          ></div>
        </div>

        <div className="container mx-auto px-4 relative z-10 pt-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="text-white space-y-8">
              <div className="space-y-4">
                <h1 className="text-6xl md:text-7xl font-bold leading-tight">
                  Perjalanan <span className="text-teal-200">Nyaman</span> Dimulai Dari Sini
                </h1>
                <p className="text-xl text-white/90 leading-relaxed">
                  Platform travel agent terpercaya yang menghubungkan penumpang dengan agen travel berkualitas di
                  seluruh Indonesia. Booking mudah, harga transparan, pickup location fleksibel.
                </p>
              </div>

              <div className="flex flex-wrap gap-4">
                {isAuthenticated ? (
                  <Link href="/travels">
                    <Button size="lg" className="bg-white text-primary hover:bg-gray-100 text-lg px-8 py-7 shadow-2xl">
                      <Search className="w-5 h-5 mr-2" />
                      Cari Perjalanan
                    </Button>
                  </Link>
                ) : (
                  <>
                    <Link href="/register">
                      <Button
                        size="lg"
                        className="bg-white text-primary hover:bg-gray-100 text-lg px-8 py-7 shadow-2xl"
                      >
                        <Bus className="w-5 h-5 mr-2" />
                        Mulai Sekarang
                      </Button>
                    </Link>
                    <Link href="/agent/register">
                      <Button
                        size="lg"
                        variant="outline"
                        className="border-2 border-white text-white hover:bg-white hover:text-primary text-lg px-8 py-7 bg-transparent"
                      >
                        Daftar Sebagai Agen
                      </Button>
                    </Link>
                  </>
                )}
              </div>

              <div className="flex items-center gap-8 pt-4">
                <div className="flex items-center gap-2">
                  <div className="flex -space-x-2">
                    {[1, 2, 3, 4].map((i) => (
                      <div
                        key={i}
                        className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-blue-500 border-2 border-white"
                      ></div>
                    ))}
                  </div>
                  <div className="text-sm">
                    <div className="font-bold">5000+</div>
                    <div className="text-white/80">Pengguna Aktif</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-10 h-10 text-yellow-300 fill-yellow-300" />
                  <div className="text-sm">
                    <div className="font-bold">4.9/5</div>
                    <div className="text-white/80">Rating</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="hidden md:block relative">
              <div className="relative w-full h-[500px] flex items-center justify-center">
                <div className="absolute inset-0 bg-white/10 backdrop-blur-sm rounded-3xl rotate-6 animate-pulse"></div>
                <div className="relative bg-white/20 backdrop-blur-lg rounded-3xl p-8 shadow-2xl">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="glass-effect rounded-2xl p-6 flex flex-col items-center gap-3">
                      <Bus className="w-12 h-12 text-white" />
                      <span className="text-white font-semibold">Bus Travel</span>
                    </div>
                    <div className="glass-effect rounded-2xl p-6 flex flex-col items-center gap-3">
                      <Car className="w-12 h-12 text-white" />
                      <span className="text-white font-semibold">Mobil Travel</span>
                    </div>
                    <div className="glass-effect rounded-2xl p-6 flex flex-col items-center gap-3">
                      <MapPin className="w-12 h-12 text-white" />
                      <span className="text-white font-semibold">Pickup Point</span>
                    </div>
                    <div className="glass-effect rounded-2xl p-6 flex flex-col items-center gap-3">
                      <Shield className="w-12 h-12 text-white" />
                      <span className="text-white font-semibold">Aman & Nyaman</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown className="w-10 h-10 text-white" />
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-6">
            <div className="relative group">
              <div className="gradient-border rounded-2xl p-8 text-center hover:shadow-xl transition-shadow">
                <div className="text-5xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-2">
                  150+
                </div>
                <div className="text-muted-foreground font-medium">Travel Partner</div>
              </div>
            </div>

            <div className="relative group">
              <div className="gradient-border rounded-2xl p-8 text-center hover:shadow-xl transition-shadow">
                <div className="text-5xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-2">
                  5000+
                </div>
                <div className="text-muted-foreground font-medium">Pengguna Aktif</div>
              </div>
            </div>

            <div className="relative group">
              <div className="gradient-border rounded-2xl p-8 text-center hover:shadow-xl transition-shadow">
                <div className="text-5xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-2">
                  50+
                </div>
                <div className="text-muted-foreground font-medium">Kota Tujuan</div>
              </div>
            </div>

            <div className="relative group">
              <div className="gradient-border rounded-2xl p-8 text-center hover:shadow-xl transition-shadow">
                <div className="text-5xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-2">
                  4.9
                </div>
                <div className="text-muted-foreground font-medium">Rating Pengguna</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-5xl font-bold text-foreground">
              Mengapa Pilih{" "}
              <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">GoTravel</span>
              ?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Platform lengkap dengan fitur modern untuk pengalaman perjalanan terbaik
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3">Aman & Terpercaya</h3>
              <p className="text-muted-foreground leading-relaxed">
                Semua agen travel telah terverifikasi dan memiliki izin resmi untuk menjamin keamanan perjalanan Anda.
              </p>
            </div>

            <div className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                <MapPin className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3">Pickup Location</h3>
              <p className="text-muted-foreground leading-relaxed">
                Pilih lokasi penjemputan yang paling dekat dengan Anda. Fleksibel dan mudah dijangkau.
              </p>
            </div>

            <div className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                <Clock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3">Booking Cepat</h3>
              <p className="text-muted-foreground leading-relaxed">
                Proses booking yang mudah dan cepat, hanya dalam hitungan menit perjalanan Anda sudah terkonfirmasi.
              </p>
            </div>

            <div className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3">Harga Terbaik</h3>
              <p className="text-muted-foreground leading-relaxed">
                Bandingkan harga dari berbagai travel dan dapatkan penawaran terbaik sesuai budget Anda.
              </p>
            </div>

            <div className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3">Agent Dashboard</h3>
              <p className="text-muted-foreground leading-relaxed">
                Dashboard khusus untuk agen travel mengelola armada, booking, dan statistik perjalanan.
              </p>
            </div>

            <div className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                <Phone className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3">Support 24/7</h3>
              <p className="text-muted-foreground leading-relaxed">
                Tim customer support siap membantu Anda kapan saja untuk pengalaman perjalanan yang lancar.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-primary via-blue-600 to-secondary relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-20 w-96 h-96 bg-white rounded-full blur-3xl animate-pulse"></div>
          <div
            className="absolute bottom-10 right-20 w-96 h-96 bg-teal-300 rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1s" }}
          ></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center text-white space-y-8">
            <h2 className="text-5xl font-bold">Siap Memulai Perjalanan Anda?</h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto leading-relaxed">
              Bergabunglah dengan ribuan pengguna lain yang telah mempercayai GoTravel untuk perjalanan mereka. Daftar
              sekarang dan nikmati kemudahan booking travel!
            </p>

            <div className="flex flex-wrap gap-4 justify-center pt-4">
              {isAuthenticated ? (
                <Link href="/travels">
                  <Button size="lg" className="bg-white text-primary hover:bg-gray-100 text-lg px-10 py-7 shadow-2xl">
                    <Search className="w-5 h-5 mr-2" />
                    Mulai Cari Travel
                  </Button>
                </Link>
              ) : (
                <>
                  <Link href="/register">
                    <Button size="lg" className="bg-white text-primary hover:bg-gray-100 text-lg px-10 py-7 shadow-2xl">
                      Daftar Sebagai Penumpang
                    </Button>
                  </Link>
                  <Link href="/agent/register">
                    <Button
                      size="lg"
                      variant="outline"
                      className="border-2 border-white text-white hover:bg-white hover:text-primary text-lg px-10 py-7 bg-transparent"
                    >
                      Daftar Sebagai Agen
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
                  <Bus className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold">GoTravel</span>
              </div>
              <p className="text-white/70 leading-relaxed">
                Platform travel agent terpercaya yang menghubungkan penumpang dengan agen travel berkualitas.
              </p>
            </div>

            <div>
              <h5 className="font-bold mb-4 text-lg">Link Cepat</h5>
              <div className="space-y-2">
                <a href="#home" className="block text-white/70 hover:text-white transition-colors">
                  Beranda
                </a>
                <a href="#features" className="block text-white/70 hover:text-white transition-colors">
                  Fitur
                </a>
                <Link href="/travels" className="block text-white/70 hover:text-white transition-colors">
                  Cari Travel
                </Link>
                <Link href="/agent/register" className="block text-white/70 hover:text-white transition-colors">
                  Daftar Agen
                </Link>
              </div>
            </div>

            <div>
              <h5 className="font-bold mb-4 text-lg">Kontak</h5>
              <div className="space-y-3 text-white/70">
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5" />
                  <span>+62 812-3456-7890</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5" />
                  <span>info@gotravel.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5" />
                  <span>Jakarta, Indonesia</span>
                </div>
              </div>
            </div>

            <div>
              <h5 className="font-bold mb-4 text-lg">Sosial Media</h5>
              <div className="flex gap-3">
                <a
                  href="#"
                  className="w-12 h-12 bg-white/10 hover:bg-white/20 rounded-xl flex items-center justify-center transition-all hover:scale-110"
                >
                  <span className="text-sm font-semibold">FB</span>
                </a>
                <a
                  href="#"
                  className="w-12 h-12 bg-white/10 hover:bg-white/20 rounded-xl flex items-center justify-center transition-all hover:scale-110"
                >
                  <span className="text-sm font-semibold">IG</span>
                </a>
                <a
                  href="#"
                  className="w-12 h-12 bg-white/10 hover:bg-white/20 rounded-xl flex items-center justify-center transition-all hover:scale-110"
                >
                  <span className="text-sm font-semibold">TW</span>
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-8 text-center text-white/60">
            <p>&copy; 2025 GoTravel. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
