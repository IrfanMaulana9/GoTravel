import { Inter } from "next/font/google"
import "./globals.css"
import { AuthProvider } from "@/contexts/AuthContext"
import { Toaster } from "@/components/ui/sonner"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "GoTravel - Platform Travel Agent Terpercaya",
  description:
    "Platform travel agent terpercaya yang menghubungkan penumpang dengan agen travel berkualitas di seluruh Indonesia",
    generator: 'v0.app'
}

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body className={inter.className}>
        <AuthProvider>
          {children}
          <Toaster position="top-right" />
        </AuthProvider>
      </body>
    </html>
  )
}
