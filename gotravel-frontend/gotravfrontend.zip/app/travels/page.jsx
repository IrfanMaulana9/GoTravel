"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/AuthContext"
import { travelAPI, formatPrice, formatTime } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Car, Search, MapPin, Clock, Users, Star, ArrowRight, Filter, Loader2 } from "lucide-react"
import { toast } from "sonner"
import Link from "next/link"

export default function TravelsPage() {
  const router = useRouter()
  const { isAuthenticated, user, logout } = useAuth()

  const [travels, setTravels] = useState([])
  const [cities, setCities] = useState([])
  const [loading, setLoading] = useState(false)
  const [filters, setFilters] = useState({
    search: "",
    from_city: "",
    to_city: "",
    type: "",
    min_price: "",
    max_price: "",
    sort_by: "created_at",
    order_by: "desc",
  })
  const [pagination, setPagination] = useState({
    current_page: 1,
    total_pages: 1,
    total_items: 0,
    per_page: 10,
  })

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }
    fetchCities()
    fetchTravels()
  }, [isAuthenticated])

  const fetchCities = async () => {
    try {
      const response = await travelAPI.getCities()
      if (response.success) {
        setCities(response.data.all_cities)
      }
    } catch (error) {
      console.error("Error fetching cities:", error)
    }
  }

  const fetchTravels = async (page = 1) => {
    setLoading(true)
    try {
      const params = {
        ...filters,
        page,
        limit: 10,
      }

      const response = await travelAPI.getAll(params)

      if (response.success) {
        setTravels(response.data)
        setPagination(response.pagination)
      }
    } catch (error) {
      console.error("Error fetching travels:", error)
      toast.error("Gagal memuat data travel")
    } finally {
      setLoading(false)
    }
  }

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  const handleSearch = () => {
    fetchTravels(1)
  }

  const handleReset = () => {
    setFilters({
      search: "",
      from_city: "",
      to_city: "",
      type: "",
      min_price: "",
      max_price: "",
      sort_by: "created_at",
      order_by: "desc",
    })
    setTimeout(() => fetchTravels(1), 100)
  }

  const handleLogout = async () => {
    await logout()
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-gradient-to-r from-blue-700 to-blue-500 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 text-white text-2xl font-bold">
              <Car className="w-8 h-8" />
              MayTravel
            </Link>

            <div className="flex items-center gap-4">
              <span className="text-white">Halo, {user?.name}</span>
              <Button variant="ghost" className="text-white hover:bg-white/10" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Search & Filter Section */}
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Cari & Filter Travel
            </CardTitle>
            <CardDescription>Temukan travel yang sesuai dengan kebutuhan Anda</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="search">Cari</Label>
                  <Input
                    id="search"
                    placeholder="Nama travel, kota..."
                    value={filters.search}
                    onChange={(e) => handleFilterChange("search", e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="from_city">Dari Kota</Label>
                  <Select value={filters.from_city} onValueChange={(value) => handleFilterChange("from_city", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih kota asal" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all_cities">Semua Kota</SelectItem>
                      {cities.map((city) => (
                        <SelectItem key={city} value={city}>
                          {city}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="to_city">Ke Kota</Label>
                  <Select value={filters.to_city} onValueChange={(value) => handleFilterChange("to_city", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih kota tujuan" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all_cities">Semua Kota</SelectItem>
                      {cities.map((city) => (
                        <SelectItem key={city} value={city}>
                          {city}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="type">Tipe</Label>
                  <Select value={filters.type} onValueChange={(value) => handleFilterChange("type", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih tipe" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all_types">Semua Tipe</SelectItem>
                      <SelectItem value="Shuttle Car">Shuttle Car</SelectItem>
                      <SelectItem value="Private Car">Private Car</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="min_price">Harga Min</Label>
                  <Input
                    id="min_price"
                    type="number"
                    placeholder="0"
                    value={filters.min_price}
                    onChange={(e) => handleFilterChange("min_price", e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="max_price">Harga Max</Label>
                  <Input
                    id="max_price"
                    type="number"
                    placeholder="1000000"
                    value={filters.max_price}
                    onChange={(e) => handleFilterChange("max_price", e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="sort_by">Urutkan</Label>
                  <Select value={filters.sort_by} onValueChange={(value) => handleFilterChange("sort_by", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="created_at">Terbaru</SelectItem>
                      <SelectItem value="price">Harga</SelectItem>
                      <SelectItem value="rating">Rating</SelectItem>
                      <SelectItem value="depart_time">Waktu Berangkat</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700">
                  <Search className="w-4 h-4 mr-2" />
                  Cari Travel
                </Button>
                <Button variant="outline" onClick={handleReset}>
                  Reset Filter
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : travels.length === 0 ? (
          <Card className="p-12 text-center">
            <Car className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Tidak ada travel ditemukan</h3>
            <p className="text-gray-600">Coba ubah filter pencarian Anda</p>
          </Card>
        ) : (
          <>
            <div className="mb-4 text-gray-600">
              Menampilkan {travels.length} dari {pagination.total_items} travel
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {travels.map((travel) => (
                <Card key={travel.id} className="hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-xl">{travel.agent_name}</CardTitle>
                        <CardDescription className="flex items-center gap-1 mt-1">
                          <MapPin className="w-4 h-4" />
                          {travel.from_city} <ArrowRight className="w-4 h-4" /> {travel.to_city}
                        </CardDescription>
                      </div>
                      <Badge variant={travel.type === "Shuttle Car" ? "default" : "secondary"}>{travel.type}</Badge>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-gray-500" />
                        <span>Berangkat: {formatTime(travel.depart_time)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-gray-500" />
                        <span>Tiba: {formatTime(travel.arrival_time)}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-gray-500" />
                        <span>{travel.seats} kursi tersedia</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        <span>
                          {travel.rating} ({travel.reviews} ulasan)
                        </span>
                      </div>
                    </div>

                    {travel.facilities_array && travel.facilities_array.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {travel.facilities_array.map((facility, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {facility}
                          </Badge>
                        ))}
                      </div>
                    )}

                    <p className="text-sm text-gray-600 line-clamp-2">{travel.description}</p>
                  </CardContent>

                  <CardFooter className="flex items-center justify-between border-t pt-4">
                    <div className="text-2xl font-bold text-blue-600">{formatPrice(travel.price)}</div>
                    <Link href={`/travels/${travel.id}`}>
                      <Button className="bg-blue-600 hover:bg-blue-700">Lihat Detail</Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            {pagination.total_pages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-8">
                <Button
                  variant="outline"
                  onClick={() => fetchTravels(pagination.current_page - 1)}
                  disabled={!pagination.has_prev_page}
                >
                  Sebelumnya
                </Button>

                <span className="px-4 py-2">
                  Halaman {pagination.current_page} dari {pagination.total_pages}
                </span>

                <Button
                  variant="outline"
                  onClick={() => fetchTravels(pagination.current_page + 1)}
                  disabled={!pagination.has_next_page}
                >
                  Selanjutnya
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
