"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { useAuth } from "@/contexts/AuthContext"
import { travelAPI, formatPrice, formatTime, getImageUrl } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Car, MapPin, Clock, Users, Star, ArrowLeft, ArrowRight, Loader2, Calendar } from "lucide-react"
import { toast } from "sonner"
import Link from "next/link"
import Image from "next/image"

export default function TravelDetailPage() {
  const router = useRouter()
  const params = useParams()
  const { isAuthenticated, logout } = useAuth()

  const [travel, setTravel] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }

    if (params.id) {
      fetchTravelDetail()
    }
  }, [params.id, isAuthenticated])

  const fetchTravelDetail = async () => {
    setLoading(true)
    try {
      const response = await travelAPI.getById(params.id)

      if (response.success) {
        setTravel(response.data)
      }
    } catch (error) {
      console.error("Error fetching travel detail:", error)
      toast.error("Gagal memuat detail travel")
      router.push("/travels")
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    )
  }

  if (!travel) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-gradient-to-r from-blue-700 to-blue-500 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 text-white text-2xl font-bold">
              <Car className="w-8 h-8" />
              MayTravel
            </Link>

            <Button variant="ghost" className="text-white hover:bg-white/10" onClick={logout}>
              Logout
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <Link href="/travels">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Kembali ke Daftar Travel
          </Button>
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {/* Main Info Card */}
            <Card className="shadow-lg">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-3xl mb-2">{travel.agent_name}</CardTitle>
                    <CardDescription className="flex items-center gap-2 text-lg">
                      <MapPin className="w-5 h-5" />
                      {travel.from_city} <ArrowRight className="w-5 h-5" /> {travel.to_city}
                    </CardDescription>
                  </div>
                  <Badge
                    variant={travel.type === "Shuttle Car" ? "default" : "secondary"}
                    className="text-lg px-4 py-2"
                  >
                    {travel.type}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                {travel.image && (
                  <div className="relative w-full h-64 rounded-lg overflow-hidden">
                    <Image
                      src={getImageUrl(travel.image) || "/placeholder.svg"}
                      alt={travel.agent_name}
                      fill
                      className="object-cover"
                    />
                  </div>
                )}

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2 text-gray-600 mb-2">
                      <Clock className="w-5 h-5" />
                      <span className="font-medium">Waktu Keberangkatan</span>
                    </div>
                    <div className="text-2xl font-bold text-blue-600">{formatTime(travel.depart_time)}</div>
                  </div>

                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2 text-gray-600 mb-2">
                      <Clock className="w-5 h-5" />
                      <span className="font-medium">Waktu Tiba</span>
                    </div>
                    <div className="text-2xl font-bold text-blue-600">{formatTime(travel.arrival_time)}</div>
                  </div>

                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-2 text-gray-600 mb-2">
                      <Users className="w-5 h-5" />
                      <span className="font-medium">Kursi Tersedia</span>
                    </div>
                    <div className="text-2xl font-bold text-green-600">{travel.seats} Kursi</div>
                  </div>

                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <div className="flex items-center gap-2 text-gray-600 mb-2">
                      <Star className="w-5 h-5" />
                      <span className="font-medium">Rating</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-yellow-600">{travel.rating}</span>
                      <span className="text-gray-600">({travel.reviews} ulasan)</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-lg mb-2">Durasi Perjalanan</h3>
                  <p className="text-gray-600 flex items-center gap-2">
                    <Calendar className="w-5 h-5" />
                    {travel.duration}
                  </p>
                </div>

                {travel.facilities_array && travel.facilities_array.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Fasilitas</h3>
                    <div className="flex flex-wrap gap-2">
                      {travel.facilities_array.map((facility, idx) => (
                        <Badge key={idx} variant="outline" className="text-sm px-3 py-1">
                          {facility}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {travel.description && (
                  <div>
                    <h3 className="font-semibold text-lg mb-2">Deskripsi</h3>
                    <p className="text-gray-600 leading-relaxed">{travel.description}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Booking Card */}
          <div className="lg:col-span-1">
            <Card className="shadow-lg sticky top-4">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-500 text-white">
                <CardTitle>Detail Harga</CardTitle>
                <CardDescription className="text-white/90">Informasi pembayaran</CardDescription>
              </CardHeader>

              <CardContent className="pt-6 space-y-4">
                <div className="text-center py-4 border-b">
                  <div className="text-gray-600 mb-2">Harga per kursi</div>
                  <div className="text-4xl font-bold text-blue-600">{formatPrice(travel.price)}</div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Rute:</span>
                    <span className="font-medium">
                      {travel.from_city} - {travel.to_city}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tipe:</span>
                    <span className="font-medium">{travel.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Durasi:</span>
                    <span className="font-medium">{travel.duration}</span>
                  </div>
                </div>
              </CardContent>

              <CardFooter className="flex flex-col gap-2">
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6">Booking Sekarang</Button>
                <p className="text-xs text-gray-500 text-center">Fitur booking akan segera tersedia</p>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
