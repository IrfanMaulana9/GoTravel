<?php
require_once 'config/config.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Tentang Kami</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .hero-section {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            padding: 5rem 0;
        }
        .feature-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
            transition: all 0.3s ease;
            height: 100%;
        }
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        .feature-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            font-size: 2rem;
            color: white;
        }
        .team-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
            transition: all 0.3s ease;
        }
        .team-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }
        .team-avatar {
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 3rem;
            color: white;
        }
        .stats-section {
            background: #f8fafc;
            padding: 5rem 0;
        }
        .stat-card {
            text-align: center;
            padding: 2rem;
        }
        .stat-number {
            font-size: 3rem;
            font-weight: 800;
            color: var(--primary-blue);
            margin-bottom: 0.5rem;
        }
        .timeline {
            position: relative;
            padding: 2rem 0;
        }
        .timeline::before {
            content: '';
            position: absolute;
            left: 50%;
            top: 0;
            bottom: 0;
            width: 2px;
            background: var(--secondary-blue);
            transform: translateX(-50%);
        }
        .timeline-item {
            position: relative;
            margin-bottom: 3rem;
        }
        .timeline-content {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            width: 45%;
        }
        .timeline-item:nth-child(odd) .timeline-content {
            margin-left: auto;
        }
        .timeline-item:nth-child(even) .timeline-content {
            margin-right: auto;
        }
        .timeline-marker {
            position: absolute;
            left: 50%;
            top: 2rem;
            width: 20px;
            height: 20px;
            background: var(--secondary-blue);
            border-radius: 50%;
            transform: translateX(-50%);
            border: 4px solid white;
            box-shadow: 0 0 0 4px var(--secondary-blue);
        }
        @media (max-width: 768px) {
            .timeline::before {
                left: 30px;
            }
            .timeline-content {
                width: calc(100% - 60px);
                margin-left: 60px !important;
            }
            .timeline-marker {
                left: 30px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-car me-2"></i>MayTravel
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-home me-1"></i>Beranda
                </a>
                <a class="nav-link" href="contact-support.php">
                    <i class="fas fa-phone me-1"></i>Kontak
                </a>
                <?php if (isLoggedIn()): ?>
                    <a class="nav-link" href="<?php echo isset($_SESSION['user_id']) ? 'user-dashboard.php' : 'agent-dashboard.php'; ?>">
                        <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                    </a>
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt me-1"></i>Logout
                    </a>
                <?php else: ?>
                    <a class="nav-link" href="login.php">
                        <i class="fas fa-sign-in-alt me-1"></i>Login
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">Tentang MayTravel</h1>
                    <p class="lead mb-4">
                        Platform travel terpercaya yang menghubungkan penumpang dengan agen travel terbaik di seluruh Indonesia. 
                        Kami berkomitmen memberikan pengalaman perjalanan yang aman, nyaman, dan terjangkau.
                    </p>
                </div>
                <div class="col-lg-6 text-center">
                    <i class="fas fa-map fa-10x" style="opacity: 0.3;"></i>
                </div>
            </div>
        </div>
    </section>

    <!-- Mission & Vision -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-bullseye"></i>
                        </div>
                        <h3 class="text-primary mb-3">Misi Kami</h3>
                        <p class="text-muted">
                            Menyediakan platform yang menghubungkan penumpang dengan agen travel terpercaya, 
                            memberikan kemudahan dalam booking perjalanan, dan memastikan pengalaman travel yang berkualitas.
                        </p>
                    </div>
                </div>
                <div class="col-lg-6 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-eye"></i>
                        </div>
                        <h3 class="text-primary mb-3">Visi Kami</h3>
                        <p class="text-muted">
                            Menjadi platform travel nomor satu di Indonesia yang menghubungkan jutaan penumpang 
                            dengan ribuan agen travel dalam ekosistem transportasi yang terintegrasi.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Values -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="text-primary">Nilai-Nilai Kami</h2>
                <p class="text-muted">Prinsip yang memandu setiap langkah kami</p>
            </div>
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h4 class="text-primary mb-3">Kepercayaan</h4>
                        <p class="text-muted">
                            Membangun kepercayaan melalui transparansi, keamanan, dan layanan yang konsisten.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h4 class="text-primary mb-3">Kemitraan</h4>
                        <p class="text-muted">
                            Menjalin kemitraan yang saling menguntungkan dengan agen travel di seluruh Indonesia.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-lightbulb"></i>
                        </div>
                        <h4 class="text-primary mb-3">Inovasi</h4>
                        <p class="text-muted">
                            Terus berinovasi untuk memberikan solusi travel yang lebih baik dan efisien.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistics -->
    <section class="stats-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="text-primary">MayTravel dalam Angka</h2>
                <p class="text-muted">Pencapaian kami hingga saat ini</p>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="stat-card">
                        <div class="stat-number">1</div>
                        <h5 class="text-muted">Agen Travel</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="stat-card">
                        <div class="stat-number">2</div>
                        <h5 class="text-muted">Pengguna Aktif</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="stat-card">
                        <div class="stat-number">10</div>
                        <h5 class="text-muted">Perjalanan Sukses</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="stat-card">
                        <div class="stat-number">10</div>
                        <h5 class="text-muted">Provinsi</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Timeline -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="text-primary">Perjalanan Kami</h2>
                <p class="text-muted">Milestone penting dalam pengembangan MayTravel</p>
            </div>
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-marker"></div>
                    <div class="timeline-content">
                        <h5 class="text-primary">2025 - Ide Awal</h5>
                        <p class="text-muted">
                            Ide MayTravel lahir dari kebutuhan untuk mempermudah booking travel antar kota di Indonesia.
                        </p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-marker"></div>
                    <div class="timeline-content">
                        <h5 class="text-primary">2025 - Pengembangan Platform</h5>
                        <p class="text-muted">
                            Mulai mengembangkan platform digital dan menjalin kemitraan dengan agen travel pertama.
                        </p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-marker"></div>
                    <div class="timeline-content">
                        <h5 class="text-primary">2025 - Peluncuran Beta</h5>
                        <p class="text-muted">
                            Meluncurkan versi beta dengan 50 agen travel dan melayani rute Jakarta-Bandung.
                        </p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-marker"></div>
                    <div class="timeline-content">
                        <h5 class="text-primary">2025 - Ekspansi Nasional</h5>
                        <p class="text-muted">
                            Memperluas jangkauan ke seluruh Indonesia dengan 500+ agen travel partner.
                        </p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-marker"></div>
                    <div class="timeline-content">
                        <h5 class="text-primary">2025 - Platform Terpercaya</h5>
                        <p class="text-muted">
                            Menjadi platform travel terpercaya dengan 1000+ agen dan 50K+ pengguna aktif.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Team -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="text-primary">Tim Kami</h2>
                <p class="text-muted">Orang-orang hebat di balik MayTravel</p>
            </div>
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div class="team-card">
                        <div class="team-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <h5 class="text-primary">Muhammad Irfan Maulana</h5>
                        <p class="text-muted mb-2">Founder</p>
                        <p class="small text-muted">
                            Visioner di balik MayTravel dengan pengalaman 10+ tahun di industri teknologi dan transportasi.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <div class="team-card">
                        <div class="team-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <h5 class="text-primary">Abyan Rifqi</h5>
                        <p class="text-muted mb-2">CTO</p>
                        <p class="small text-muted">
                            Ahli teknologi yang memimpin pengembangan platform dengan fokus pada keamanan dan skalabilitas.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <div class="team-card">
                        <div class="team-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <h5 class="text-primary">M. Yapil Islami</h5>
                        <p class="text-muted mb-2">Head of Operations</p>
                        <p class="small text-muted">
                            Memastikan operasional berjalan lancar dan menjalin hubungan baik dengan mitra agen travel.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><i class="fas fa-car me-2"></i>MayTravel</h5>
                    <p class="text-muted">Platform travel terpercaya di Indonesia</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="text-muted mb-0">&copy; 2024 MayTravel. Semua hak cipta dilindungi.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
