<?php
require_once 'config/config.php';
require_once 'includes/payment.php';

// Require user login
if (!isset($_SESSION['user_id'])) {
    redirect('login.php');
}

// Check if booking exists
if (!isset($_GET['booking_id'])) {
    redirect('user-dashboard.php');
}

$bookingId = (int)$_GET['booking_id'];
$payment = new Payment();
$db = getDB();

// Get booking details
try {
    $stmt = $db->prepare("
        SELECT b.*, r.from_city, r.to_city, r.departure_time, r.arrival_time, 
               r.vehicle_type, a.company_name, a.contact_phone
        FROM bookings b
        JOIN routes r ON b.route_id = r.id
        JOIN agents a ON b.agent_id = a.id
        WHERE b.id = ? AND b.user_id = ?
    ");
    $stmt->execute([$bookingId, $_SESSION['user_id']]);
    $booking = $stmt->fetch();
    
    if (!$booking) {
        redirect('user-dashboard.php');
    }
} catch (Exception $e) {
    redirect('user-dashboard.php');
}

// Handle payment submission
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment'])) {
    $paymentData = [
        'booking_id' => $bookingId,
        'amount' => $booking['total_price'],
        'payment_method' => sanitize($_POST['payment_method']),
        'payment_reference' => $payment->generatePaymentReference($bookingId, $_POST['payment_method'])
    ];
    
    if ($payment->validatePaymentMethod($paymentData['payment_method'])) {
        $result = $payment->processPayment($paymentData);
        
        if ($result['success']) {
            $success = $result['message'];
            // Refresh booking data
            $stmt->execute([$bookingId, $_SESSION['user_id']]);
            $booking = $stmt->fetch();
        } else {
            $error = $result['message'];
        }
    } else {
        $error = 'Metode pembayaran tidak valid';
    }
}

$paymentMethods = $payment->getPaymentMethods();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
        }
        .payment-method-card {
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            padding: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 1rem;
        }
        .payment-method-card:hover {
            border-color: var(--secondary-blue);
            background: #f0f9ff;
        }
        .payment-method-card.selected {
            border-color: var(--secondary-blue);
            background: #dbeafe;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border: none;
            border-radius: 10px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-paid { background: #d1fae5; color: #065f46; }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-car me-2"></i>MayTravel
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="user-dashboard.php">
                    <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-credit-card me-2 text-primary"></i>Pembayaran</h2>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                <div class="mt-2">
                    <a href="user-dashboard.php" class="btn btn-success btn-sm">Kembali ke Dashboard</a>
                </div>
            </div>
        <?php endif; ?>

        <div class="row">
            <!-- Booking Details -->
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-ticket-alt me-2 text-primary"></i>Detail Booking
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <table class="table table-sm">
                                    <tr><td><strong>Kode Booking:</strong></td><td><?php echo $booking['booking_code']; ?></td></tr>
                                    <tr><td><strong>Rute:</strong></td><td><?php echo $booking['from_city']; ?> → <?php echo $booking['to_city']; ?></td></tr>
                                    <tr><td><strong>Tanggal:</strong></td><td><?php echo date('d/m/Y', strtotime($booking['travel_date'])); ?></td></tr>
                                    <tr><td><strong>Waktu:</strong></td><td><?php echo date('H:i', strtotime($booking['departure_time'])); ?> - <?php echo date('H:i', strtotime($booking['arrival_time'])); ?></td></tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <table class="table table-sm">
                                    <tr><td><strong>Penumpang:</strong></td><td><?php echo htmlspecialchars($booking['passenger_name']); ?></td></tr>
                                    <tr><td><strong>Kursi:</strong></td><td><?php echo $booking['seats_booked']; ?> kursi</td></tr>
                                    <tr><td><strong>Agen:</strong></td><td><?php echo htmlspecialchars($booking['company_name']); ?></td></tr>
                                    <tr><td><strong>Status Pembayaran:</strong></td><td>
                                        <span class="status-badge status-<?php echo $booking['payment_status']; ?>">
                                            <?php echo $booking['payment_status'] === 'paid' ? 'Sudah Dibayar' : 'Belum Dibayar'; ?>
                                        </span>
                                    </td></tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ($booking['payment_status'] !== 'paid'): ?>
                    <!-- Payment Methods -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-credit-card me-2 text-primary"></i>Pilih Metode Pembayaran
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="confirm_payment" value="1">
                                
                                <div class="row">
                                    <?php foreach ($paymentMethods as $key => $method): ?>
                                        <div class="col-md-6">
                                            <div class="payment-method-card" onclick="selectPaymentMethod('<?php echo $key; ?>')">
                                                <input type="radio" name="payment_method" value="<?php echo $key; ?>" id="<?php echo $key; ?>" style="display: none;">
                                                <div class="d-flex align-items-center mb-2">
                                                    <i class="fas fa-<?php echo $method['type'] === 'bank_transfer' ? 'university' : 'qrcode'; ?> text-primary me-2 fa-lg"></i>
                                                    <strong><?php echo $method['name']; ?></strong>
                                                </div>
                                                <?php if ($method['type'] === 'bank_transfer'): ?>
                                                    <small class="text-muted">
                                                        No. Rek: <?php echo $method['account_number']; ?><br>
                                                        A/n: <?php echo $method['account_name']; ?>
                                                    </small>
                                                <?php else: ?>
                                                    <small class="text-muted">Pembayaran dengan QR Code</small>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <!-- Payment Instructions -->
                                <div id="payment_instructions" class="alert alert-info mt-3" style="display: none;">
                                    <h6 class="alert-heading">Instruksi Pembayaran</h6>
                                    <div id="instruction_content"></div>
                                </div>
                                
                                <div class="text-center mt-4">
                                    <button type="submit" class="btn btn-primary btn-lg" id="confirm_payment_btn" disabled>
                                        <i class="fas fa-check me-2"></i>Konfirmasi Pembayaran
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Payment Summary -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-calculator me-2 text-primary"></i>Ringkasan Pembayaran
                        </h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <tr>
                                <td>Harga per kursi:</td>
                                <td class="text-end">Rp <?php echo number_format($booking['total_price'] / $booking['seats_booked'], 0, ',', '.'); ?></td>
                            </tr>
                            <tr>
                                <td>Jumlah kursi:</td>
                                <td class="text-end"><?php echo $booking['seats_booked']; ?></td>
                            </tr>
                            <tr class="border-top">
                                <td><strong>Total:</strong></td>
                                <td class="text-end"><strong>Rp <?php echo number_format($booking['total_price'], 0, ',', '.'); ?></strong></td>
                            </tr>
                        </table>
                        
                        <?php if ($booking['payment_status'] === 'paid'): ?>
                            <div class="alert alert-success mt-3">
                                <i class="fas fa-check-circle me-2"></i>
                                <strong>Pembayaran Berhasil!</strong><br>
                                Metode: <?php echo $paymentMethods[$booking['payment_method']]['name'] ?? $booking['payment_method']; ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="mt-3">
                            <small class="text-muted">
                                <i class="fas fa-info-circle me-1"></i>
                                Setelah pembayaran dikonfirmasi, tiket akan dikirim ke email Anda.
                            </small>
                        </div>
                    </div>
                </div>
                
                <!-- Contact Info -->
                <div class="card mt-3">
                    <div class="card-header">
                        <h6 class="mb-0">
                            <i class="fas fa-headset me-2 text-primary"></i>Butuh Bantuan?
                        </h6>
                    </div>
                    <div class="card-body">
                        <p class="mb-2">
                            <i class="fas fa-phone me-2 text-primary"></i>
                            <strong>Agen Travel:</strong><br>
                            <?php echo htmlspecialchars($booking['contact_phone']); ?>
                        </p>
                        <p class="mb-0">
                            <i class="fas fa-whatsapp me-2 text-success"></i>
                            <strong>Customer Service:</strong><br>
                            <a href="https://wa.me/6281234567890" target="_blank" class="text-success">
                                +62 812-3456-7890
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const paymentMethods = <?php echo json_encode($paymentMethods); ?>;
        
        function selectPaymentMethod(method) {
            // Remove all selected classes
            document.querySelectorAll('.payment-method-card').forEach(card => {
                card.classList.remove('selected');
            });
            
            // Add selected class to clicked method
            event.currentTarget.classList.add('selected');
            
            // Check the radio button
            document.getElementById(method).checked = true;
            
            // Show payment instructions
            showPaymentInstructions(method);
            
            // Enable confirm button
            document.getElementById('confirm_payment_btn').disabled = false;
        }
        
        function showPaymentInstructions(method) {
            const instructionsDiv = document.getElementById('payment_instructions');
            const contentDiv = document.getElementById('instruction_content');
            const methodData = paymentMethods[method];
            
            let content = `<strong>${methodData.name}</strong><br>`;
            
            if (methodData.type === 'bank_transfer') {
                content += `
                    <strong>Nomor Rekening:</strong> ${methodData.account_number}<br>
                    <strong>Atas Nama:</strong> ${methodData.account_name}<br>
                    <strong>Bank:</strong> ${methodData.bank_code}<br><br>
                `;
            }
            
            content += methodData.instructions;
            
            contentDiv.innerHTML = content;
            instructionsDiv.style.display = 'block';
        }
    </script>
</body>
</html>
