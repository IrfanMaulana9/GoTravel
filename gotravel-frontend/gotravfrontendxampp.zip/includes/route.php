<?php
// includes/route.php
require_once 'config/config.php';

class Route {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    // Create new route
    public function createRoute($data) {
        try {
            // Validate input
            $errors = $this->validateRouteData($data);
            if (!empty($errors)) {
                return ['success' => false, 'errors' => $errors];
            }
            
            // Insert route
            $stmt = $this->db->prepare("
                INSERT INTO routes (
                    agent_id, from_city, to_city, departure_time, arrival_time, 
                    price, vehicle_type, seats_total, seats_available, description
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['agent_id'],
                $data['from_city'],
                $data['to_city'],
                $data['departure_time'],
                $data['arrival_time'],
                $data['price'],
                $data['vehicle_type'],
                $data['seats_total'],
                $data['seats_total'], // seats_available = seats_total initially
                $data['description'] ?? null
            ]);
            
            return ['success' => true, 'message' => 'Rute berhasil ditambahkan'];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()];
        }
    }
    
    // Update route
    public function updateRoute($routeId, $data, $agentId) {
        try {
            // Validate input
            $errors = $this->validateRouteData($data);
            if (!empty($errors)) {
                return ['success' => false, 'errors' => $errors];
            }
            
            // Update route
            $stmt = $this->db->prepare("
                UPDATE routes SET 
                    from_city = ?, to_city = ?, departure_time = ?, arrival_time = ?, 
                    price = ?, vehicle_type = ?, seats_total = ?, description = ?, status = ?
                WHERE id = ? AND agent_id = ?
            ");
            
            $stmt->execute([
                $data['from_city'],
                $data['to_city'],
                $data['departure_time'],
                $data['arrival_time'],
                $data['price'],
                $data['vehicle_type'],
                $data['seats_total'],
                $data['description'] ?? null,
                $data['status'] ?? 'active',
                $routeId,
                $agentId
            ]);
            
            if ($stmt->rowCount() > 0) {
                return ['success' => true, 'message' => 'Rute berhasil diupdate'];
            } else {
                return ['success' => false, 'message' => 'Rute tidak ditemukan atau tidak ada perubahan'];
            }
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()];
        }
    }
    
    // Delete route
    public function deleteRoute($routeId, $agentId) {
        try {
            // Check if route has active bookings
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as booking_count 
                FROM bookings 
                WHERE route_id = ? AND status IN ('pending', 'confirmed')
            ");
            $stmt->execute([$routeId]);
            $result = $stmt->fetch();
            
            if ($result['booking_count'] > 0) {
                return ['success' => false, 'message' => 'Tidak dapat menghapus rute yang memiliki booking aktif'];
            }
            
            // Delete route
            $stmt = $this->db->prepare("DELETE FROM routes WHERE id = ? AND agent_id = ?");
            $stmt->execute([$routeId, $agentId]);
            
            if ($stmt->rowCount() > 0) {
                return ['success' => true, 'message' => 'Rute berhasil dihapus'];
            } else {
                return ['success' => false, 'message' => 'Rute tidak ditemukan'];
            }
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()];
        }
    }
    
    // Get agent routes
    public function getAgentRoutes($agentId) {
        try {
            $stmt = $this->db->prepare("
                SELECT * FROM routes 
                WHERE agent_id = ? 
                ORDER BY created_at DESC
            ");
            $stmt->execute([$agentId]);
            
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Validation function
    private function validateRouteData($data) {
        $errors = [];
        
        if (empty($data['from_city'])) $errors[] = 'Kota asal wajib diisi';
        if (empty($data['to_city'])) $errors[] = 'Kota tujuan wajib diisi';
        if (empty($data['departure_time'])) $errors[] = 'Waktu berangkat wajib diisi';
        if (empty($data['arrival_time'])) $errors[] = 'Waktu tiba wajib diisi';
        if (empty($data['price']) || $data['price'] <= 0) $errors[] = 'Harga harus lebih dari 0';
        if (empty($data['vehicle_type'])) $errors[] = 'Jenis kendaraan wajib diisi';
        if (empty($data['seats_total']) || $data['seats_total'] <= 0) $errors[] = 'Jumlah kursi harus lebih dari 0';
        
        if ($data['from_city'] === $data['to_city']) {
            $errors[] = 'Kota asal dan tujuan tidak boleh sama';
        }
        
        if ($data['departure_time'] >= $data['arrival_time']) {
            $errors[] = 'Waktu tiba harus setelah waktu berangkat';
        }
        
        return $errors;
    }
}
?>
