<?php
// includes/booking.php
require_once 'config/config.php';

class Booking {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    // Get available routes
    public function getRoutes($fromCity = null, $toCity = null, $date = null) {
        try {
            $sql = "
                SELECT r.*, a.company_name, a.contact_phone 
                FROM routes r 
                JOIN agents a ON r.agent_id = a.id 
                WHERE r.status = 'active' AND a.status = 'approved' AND r.seats_available > 0
            ";
            $params = [];
            
            if ($fromCity) {
                $sql .= " AND r.from_city = ?";
                $params[] = $fromCity;
            }
            
            if ($toCity) {
                $sql .= " AND r.to_city = ?";
                $params[] = $toCity;
            }
            
            $sql .= " ORDER BY r.departure_time ASC";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Create booking
    public function createBooking($data) {
        try {
            $this->db->beginTransaction();
            
            // Validate route availability
            $stmt = $this->db->prepare("
                SELECT r.*, a.company_name 
                FROM routes r 
                JOIN agents a ON r.agent_id = a.id 
                WHERE r.id = ? AND r.seats_available >= ? AND r.status = 'active'
            ");
            $stmt->execute([$data['route_id'], $data['seats_booked'] ?? 1]);
            $route = $stmt->fetch();
            
            if (!$route) {
                throw new Exception('Rute tidak tersedia atau kursi tidak mencukupi');
            }
            
            // Generate booking code
            $bookingCode = 'TRV' . date('Ymd') . strtoupper(substr(uniqid(), -6));
            
            // Calculate total price
            $totalPrice = $route['price'] * ($data['seats_booked'] ?? 1);
            
            // Insert booking
            $stmt = $this->db->prepare("
                INSERT INTO bookings (
                    booking_code, user_id, route_id, agent_id, passenger_name, 
                    passenger_phone, passenger_email, travel_date, seats_booked, 
                    total_price, payment_method, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $bookingCode,
                $data['user_id'] ?? null,
                $data['route_id'],
                $route['agent_id'],
                $data['passenger_name'],
                $data['passenger_phone'],
                $data['passenger_email'] ?? null,
                $data['travel_date'],
                $data['seats_booked'] ?? 1,
                $totalPrice,
                $data['payment_method'] ?? null,
                $data['notes'] ?? null
            ]);
            
            $bookingId = $this->db->lastInsertId();
            
            // Update available seats
            $stmt = $this->db->prepare("
                UPDATE routes 
                SET seats_available = seats_available - ? 
                WHERE id = ?
            ");
            $stmt->execute([$data['seats_booked'] ?? 1, $data['route_id']]);
            
            $this->db->commit();
            
            return [
                'success' => true, 
                'booking_id' => $bookingId,
                'booking_code' => $bookingCode,
                'total_price' => $totalPrice,
                'payment_method' => $data['payment_method'] ?? null,
                'message' => 'Booking berhasil dibuat'
            ];
            
        } catch (Exception $e) {
            $this->db->rollBack();
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    // Get user bookings
    public function getUserBookings($userId) {
        try {
            $stmt = $this->db->prepare("
                SELECT b.*, r.from_city, r.to_city, r.departure_time, r.arrival_time, 
                       r.vehicle_type, a.company_name, a.contact_phone
                FROM bookings b
                JOIN routes r ON b.route_id = r.id
                JOIN agents a ON b.agent_id = a.id
                WHERE b.user_id = ?
                ORDER BY b.created_at DESC
            ");
            $stmt->execute([$userId]);
            
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Get agent bookings
    public function getAgentBookings($agentId) {
        try {
            $stmt = $this->db->prepare("
                SELECT b.*, r.from_city, r.to_city, r.departure_time, r.arrival_time, r.vehicle_type
                FROM bookings b
                JOIN routes r ON b.route_id = r.id
                WHERE b.agent_id = ?
                ORDER BY b.created_at DESC
            ");
            $stmt->execute([$agentId]);
            
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Update booking status
    public function updateBookingStatus($bookingId, $status, $agentId = null) {
        try {
            $sql = "UPDATE bookings SET status = ? WHERE id = ?";
            $params = [$status, $bookingId];
            
            if ($agentId) {
                $sql .= " AND agent_id = ?";
                $params[] = $agentId;
            }
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return ['success' => true, 'message' => 'Status booking berhasil diupdate'];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    // Cancel booking
    public function cancelBooking($bookingId, $userId = null, $agentId = null) {
        try {
            $this->db->beginTransaction();
            
            // Get booking details
            $sql = "SELECT * FROM bookings WHERE id = ?";
            $params = [$bookingId];
            
            if ($userId) {
                $sql .= " AND user_id = ?";
                $params[] = $userId;
            } elseif ($agentId) {
                $sql .= " AND agent_id = ?";
                $params[] = $agentId;
            }
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $booking = $stmt->fetch();
            
            if (!$booking) {
                throw new Exception('Booking tidak ditemukan');
            }
            
            if ($booking['status'] === 'cancelled') {
                throw new Exception('Booking sudah dibatalkan');
            }
            
            // Update booking status
            $stmt = $this->db->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?");
            $stmt->execute([$bookingId]);
            
            // Return seats to route
            $stmt = $this->db->prepare("
                UPDATE routes 
                SET seats_available = seats_available + ? 
                WHERE id = ?
            ");
            $stmt->execute([$booking['seats_booked'], $booking['route_id']]);
            
            $this->db->commit();
            
            return ['success' => true, 'message' => 'Booking berhasil dibatalkan'];
            
        } catch (Exception $e) {
            $this->db->rollBack();
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    // Get cities
    public function getCities() {
        try {
            $stmt = $this->db->query("
                SELECT DISTINCT from_city as city FROM routes WHERE status = 'active'
                UNION 
                SELECT DISTINCT to_city as city FROM routes WHERE status = 'active'
                ORDER BY city
            ");
            
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
            
        } catch (Exception $e) {
            return [];
        }
    }
}
?>
