<?php
// includes/auth.php
require_once 'config/config.php';

class Auth {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    // User registration
    public function registerUser($data) {
        try {
            // Validate input
            $errors = $this->validateUserData($data);
            if (!empty($errors)) {
                return ['success' => false, 'errors' => $errors];
            }
            
            // Check if username or email exists
            $stmt = $this->db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$data['username'], $data['email']]);
            if ($stmt->fetch()) {
                return ['success' => false, 'message' => 'Username atau email sudah digunakan'];
            }
            
            // Hash password
            $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
            
            // Insert user
            $stmt = $this->db->prepare("
                INSERT INTO users (username, email, password, full_name, phone) 
                VALUES (?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['username'],
                $data['email'],
                $hashedPassword,
                $data['full_name'],
                $data['phone'] ?? null
            ]);
            
            return ['success' => true, 'message' => 'Registrasi berhasil'];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()];
        }
    }
    
    // Agent registration
    public function registerAgent($data) {
        try {
            // Validate input
            $errors = $this->validateAgentData($data);
            if (!empty($errors)) {
                return ['success' => false, 'errors' => $errors];
            }
            
            // Check if username or email exists
            $stmt = $this->db->prepare("SELECT id FROM agents WHERE username = ? OR email = ?");
            $stmt->execute([$data['username'], $data['email']]);
            if ($stmt->fetch()) {
                return ['success' => false, 'message' => 'Username atau email sudah digunakan'];
            }
            
            // Hash password
            $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
            
            // Insert agent
            $stmt = $this->db->prepare("
                INSERT INTO agents (
                    username, email, password, company_name, business_type, 
                    contact_name, contact_phone, business_license, establishment_year, 
                    fleet_size, operating_cities, vehicle_types
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['username'],
                $data['email'],
                $hashedPassword,
                $data['company_name'],
                $data['business_type'] ?? null,
                $data['contact_name'],
                $data['contact_phone'],
                $data['business_license'] ?? null,
                $data['establishment_year'] ?? null,
                $data['fleet_size'] ?? 0,
                isset($data['operating_cities']) ? implode(',', $data['operating_cities']) : null,
                isset($data['vehicle_types']) ? implode(',', $data['vehicle_types']) : null
            ]);
            
            return ['success' => true, 'message' => 'Registrasi agen berhasil, menunggu persetujuan'];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()];
        }
    }
    
    // User login
    public function loginUser($username, $password) {
        try {
            $stmt = $this->db->prepare("
                SELECT id, username, email, password, full_name, status 
                FROM users 
                WHERE username = ? OR email = ?
            ");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();
            
            if (!$user || !password_verify($password, $user['password'])) {
                return ['success' => false, 'message' => 'Username atau password salah'];
            }
            
            if ($user['status'] !== 'active') {
                return ['success' => false, 'message' => 'Akun Anda tidak aktif'];
            }
            
            // Set session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['user_type'] = 'user';
            
            return ['success' => true, 'message' => 'Login berhasil', 'redirect' => 'user-dashboard.php'];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()];
        }
    }
    
    // Agent login
    public function loginAgent($username, $password) {
        try {
            $stmt = $this->db->prepare("
                SELECT id, username, email, password, company_name, status 
                FROM agents 
                WHERE username = ? OR email = ?
            ");
            $stmt->execute([$username, $username]);
            $agent = $stmt->fetch();
            
            if (!$agent || !password_verify($password, $agent['password'])) {
                return ['success' => false, 'message' => 'Username atau password salah'];
            }
            
            if ($agent['status'] !== 'approved') {
                return ['success' => false, 'message' => 'Akun agen belum disetujui atau ditangguhkan'];
            }
            
            // Set session
            $_SESSION['agent_id'] = $agent['id'];
            $_SESSION['username'] = $agent['username'];
            $_SESSION['company_name'] = $agent['company_name'];
            $_SESSION['user_type'] = 'agent';
            
            return ['success' => true, 'message' => 'Login berhasil', 'redirect' => 'agent-dashboard.php'];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()];
        }
    }
    
    // Logout
    public function logout() {
        session_destroy();
        return ['success' => true, 'message' => 'Logout berhasil'];
    }
    
    // Validation functions
    private function validateUserData($data) {
        $errors = [];
        
        if (empty($data['username'])) $errors[] = 'Username wajib diisi';
        if (empty($data['email'])) $errors[] = 'Email wajib diisi';
        if (empty($data['password'])) $errors[] = 'Password wajib diisi';
        if (empty($data['full_name'])) $errors[] = 'Nama lengkap wajib diisi';
        
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Format email tidak valid';
        }
        
        if (strlen($data['password']) < 6) {
            $errors[] = 'Password minimal 6 karakter';
        }
        
        return $errors;
    }
    
    private function validateAgentData($data) {
        $errors = [];
        
        if (empty($data['username'])) $errors[] = 'Username wajib diisi';
        if (empty($data['email'])) $errors[] = 'Email wajib diisi';
        if (empty($data['password'])) $errors[] = 'Password wajib diisi';
        if (empty($data['company_name'])) $errors[] = 'Nama perusahaan wajib diisi';
        if (empty($data['contact_name'])) $errors[] = 'Nama penanggung jawab wajib diisi';
        if (empty($data['contact_phone'])) $errors[] = 'Nomor telepon wajib diisi';
        
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Format email tidak valid';
        }
        
        if (strlen($data['password']) < 6) {
            $errors[] = 'Password minimal 6 karakter';
        }
        
        return $errors;
    }
}
?>
