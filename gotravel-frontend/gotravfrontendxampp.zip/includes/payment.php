<?php
// includes/payment.php
require_once 'config/config.php';

class Payment {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    // Get payment methods with details
    public function getPaymentMethods() {
        return [
            'transfer_bca' => [
                'name' => 'Transfer BCA',
                'type' => 'bank_transfer',
                'account_number' => '1234567890',
                'account_name' => 'PT MayTravel Indonesia',
                'bank_code' => 'BCA',
                'instructions' => 'Transfer sesuai nominal yang tertera, lalu kirim bukti transfer ke WhatsApp kami'
            ],
            'transfer_bri' => [
                'name' => 'Transfer BRI',
                'type' => 'bank_transfer',
                'account_number' => '0987654321',
                'account_name' => 'PT MayTravel Indonesia',
                'bank_code' => 'BRI',
                'instructions' => 'Transfer sesuai nominal yang tertera, lalu kirim bukti transfer ke WhatsApp kami'
            ],
            'transfer_bni' => [
                'name' => 'Transfer BNI',
                'type' => 'bank_transfer',
                'account_number' => '1122334455',
                'account_name' => 'PT MayTravel Indonesia',
                'bank_code' => 'BNI',
                'instructions' => 'Transfer sesuai nominal yang tertera, lalu kirim bukti transfer ke WhatsApp kami'
            ],
            'qris' => [
                'name' => 'QRIS',
                'type' => 'qr_code',
                'instructions' => 'Scan QR Code yang akan dikirim setelah booking dikonfirmasi. QR Code berlaku selama 30 menit setelah booking.'
            ]
        ];
    }
    
    // Process payment
    public function processPayment($data) {
        try {
            $this->db->beginTransaction();
            
            // Validate booking exists
            $stmt = $this->db->prepare("SELECT * FROM bookings WHERE id = ?");
            $stmt->execute([$data['booking_id']]);
            $booking = $stmt->fetch();
            
            if (!$booking) {
                throw new Exception('Booking tidak ditemukan');
            }
            
            // Insert payment record
            $stmt = $this->db->prepare("
                INSERT INTO payments (booking_id, amount, payment_method, payment_reference, status, paid_at) 
                VALUES (?, ?, ?, ?, 'success', NOW())
            ");
            
            $stmt->execute([
                $data['booking_id'],
                $data['amount'],
                $data['payment_method'],
                $data['payment_reference'] ?? null
            ]);
            
            // Update booking payment status
            $stmt = $this->db->prepare("
                UPDATE bookings 
                SET payment_status = 'paid', payment_method = ? 
                WHERE id = ?
            ");
            $stmt->execute([$data['payment_method'], $data['booking_id']]);
            
            $this->db->commit();
            
            return ['success' => true, 'message' => 'Pembayaran berhasil diproses'];
            
        } catch (Exception $e) {
            $this->db->rollBack();
            return ['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()];
        }
    }
    
    // Get payment history
    public function getPaymentHistory($bookingId) {
        try {
            $stmt = $this->db->prepare("
                SELECT * FROM payments 
                WHERE booking_id = ? 
                ORDER BY created_at DESC
            ");
            $stmt->execute([$bookingId]);
            
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Generate payment reference
    public function generatePaymentReference($bookingId, $paymentMethod) {
        $prefix = strtoupper(substr($paymentMethod, 0, 3));
        return $prefix . date('Ymd') . str_pad($bookingId, 6, '0', STR_PAD_LEFT);
    }
    
    // Validate payment method
    public function validatePaymentMethod($method) {
        $validMethods = array_keys($this->getPaymentMethods());
        return in_array($method, $validMethods);
    }
    
    // Get payment method details
    public function getPaymentMethodDetails($method) {
        $methods = $this->getPaymentMethods();
        return $methods[$method] ?? null;
    }
}
?>
