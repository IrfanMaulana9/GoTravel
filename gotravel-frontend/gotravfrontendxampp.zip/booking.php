<?php
require_once 'config/config.php';
require_once 'includes/booking.php';

// Require user login
if (!isset($_SESSION['user_id'])) {
    redirect('login.php');
}

$booking = new Booking();
$error = '';
$success = '';

// Get available cities
$cities = $booking->getCities();

// Handle search
$routes = [];
$searchData = [];
if (isset($_GET['from']) && isset($_GET['to']) && isset($_GET['date'])) {
    $searchData = [
        'from' => sanitize($_GET['from']),
        'to' => sanitize($_GET['to']),
        'date' => sanitize($_GET['date'])
    ];
    $routes = $booking->getRoutes($searchData['from'], $searchData['to']);
}

// Handle booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_route'])) {
    $bookingData = [
        'user_id' => $_SESSION['user_id'],
        'route_id' => (int)$_POST['route_id'],
        'passenger_name' => sanitize($_POST['passenger_name']),
        'passenger_phone' => sanitize($_POST['passenger_phone']),
        'passenger_email' => sanitize($_POST['passenger_email']),
        'travel_date' => sanitize($_POST['travel_date']),
        'seats_booked' => (int)$_POST['seats_booked'],
        'notes' => sanitize($_POST['notes'])
    ];
    
    $result = $booking->createBooking($bookingData);
    
    if ($result['success']) {
        $success = $result['message'];
        $_SESSION['last_booking'] = $result;
    } else {
        $error = $result['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Booking Travel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .search-card, .route-card, .booking-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
            transition: all 0.3s ease;
        }
        .search-card:hover, .route-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }
        .route-card {
            margin-bottom: 1rem;
            cursor: pointer;
        }
        .route-card.selected {
            border: 2px solid var(--secondary-blue);
            background: linear-gradient(135deg, #dbeafe, #f0f9ff);
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border: none;
            border-radius: 10px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(30, 64, 175, 0.3);
        }
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e2e8f0;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--secondary-blue);
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
        .price-tag {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 1.1rem;
        }
        .vehicle-badge {
            background: var(--secondary-blue);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
        }
        .step-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 2rem;
        }
        .step {
            display: flex;
            align-items: center;
            margin: 0 1rem;
        }
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e2e8f0;
            color: #64748b;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            margin-right: 0.5rem;
        }
        .step.active .step-number {
            background: var(--secondary-blue);
            color: white;
        }
        .step.completed .step-number {
            background: #10b981;
            color: white;
        }
        .payment-method-card {
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            padding: 0.75rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .payment-method-card:hover {
            border-color: var(--secondary-blue);
            background: #f0f9ff;
        }
        .payment-method-card.selected {
            border-color: var(--secondary-blue);
            background: #dbeafe;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-car me-2"></i>MayTravel
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="user-dashboard.php">
                    <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <!-- Step Indicator -->
        <div class="step-indicator">
            <div class="step <?php echo empty($routes) ? 'active' : 'completed'; ?>">
                <div class="step-number">1</div>
                <span>Cari Travel</span>
            </div>
            <div class="step <?php echo !empty($routes) && empty($_POST['book_route']) ? 'active' : ''; ?>">
                <div class="step-number">2</div>
                <span>Pilih Rute</span>
            </div>
            <div class="step <?php echo isset($_POST['book_route']) ? 'active' : ''; ?>">
                <div class="step-number">3</div>
                <span>Booking</span>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                <div class="mt-2">
                    <a href="user-dashboard.php" class="btn btn-success btn-sm">Lihat Booking Saya</a>
                </div>
            </div>
        <?php endif; ?>

        <!-- Search Form -->
        <?php if (empty($routes) || isset($_GET['new_search'])): ?>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="search-card card p-4">
                        <h3 class="text-center mb-4">
                            <i class="fas fa-search me-2 text-primary"></i>Cari Travel
                        </h3>
                        <form method="GET">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="from" class="form-label">Dari Kota</label>
                                    <select class="form-select" id="from" name="from" required>
                                        <option value="">Pilih kota asal</option>
                                        <?php foreach ($cities as $city): ?>
                                            <option value="<?php echo $city; ?>" <?php echo (isset($searchData['from']) && $searchData['from'] === $city) ? 'selected' : ''; ?>>
                                                <?php echo $city; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="to" class="form-label">Ke Kota</label>
                                    <select class="form-select" id="to" name="to" required>
                                        <option value="">Pilih kota tujuan</option>
                                        <?php foreach ($cities as $city): ?>
                                            <option value="<?php echo $city; ?>" <?php echo (isset($searchData['to']) && $searchData['to'] === $city) ? 'selected' : ''; ?>>
                                                <?php echo $city; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="date" class="form-label">Tanggal Keberangkatan</label>
                                <input type="date" class="form-control" id="date" name="date" 
                                       value="<?php echo isset($searchData['date']) ? $searchData['date'] : date('Y-m-d', strtotime('+1 day')); ?>" 
                                       min="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search me-2"></i>Cari Travel
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Search Results -->
        <?php if (!empty($routes)): ?>
            <div class="row">
                <div class="col-12">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4>
                            <i class="fas fa-route me-2 text-primary"></i>
                            Rute Tersedia: <?php echo $searchData['from']; ?> → <?php echo $searchData['to']; ?>
                        </h4>
                        <a href="?new_search=1" class="btn btn-outline-primary">
                            <i class="fas fa-search me-1"></i>Cari Lagi
                        </a>
                    </div>
                    
                    <?php if (empty($routes)): ?>
                        <div class="alert alert-info text-center">
                            <i class="fas fa-info-circle me-2"></i>
                            Tidak ada rute yang tersedia untuk pencarian Anda. Silakan coba tanggal atau rute lain.
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach ($routes as $route): ?>
                                <div class="col-lg-6 mb-3">
                                    <div class="route-card card p-3" onclick="selectRoute(<?php echo $route['id']; ?>)">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <div>
                                                <h5 class="mb-1"><?php echo htmlspecialchars($route['company_name']); ?></h5>
                                                <span class="vehicle-badge"><?php echo $route['vehicle_type']; ?></span>
                                            </div>
                                            <div class="price-tag">
                                                Rp <?php echo number_format($route['price'], 0, ',', '.'); ?>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <small class="text-muted">Berangkat</small>
                                                <div class="fw-bold"><?php echo date('H:i', strtotime($route['departure_time'])); ?></div>
                                            </div>
                                            <div class="col-6">
                                                <small class="text-muted">Tiba</small>
                                                <div class="fw-bold"><?php echo date('H:i', strtotime($route['arrival_time'])); ?></div>
                                            </div>
                                        </div>
                                        <div class="mt-2">
                                            <small class="text-muted">
                                                <i class="fas fa-users me-1"></i><?php echo $route['seats_available']; ?> kursi tersedia
                                                <span class="ms-3">
                                                    <i class="fas fa-phone me-1"></i><?php echo $route['contact_phone']; ?>
                                                </span>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Booking Modal -->
    <div class="modal fade" id="bookingModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-ticket-alt me-2"></i>Form Booking
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="book_route" value="1">
                        <input type="hidden" name="route_id" id="modal_route_id">
                        <input type="hidden" name="travel_date" value="<?php echo $searchData['date'] ?? ''; ?>">
                        
                        <div id="route_details" class="alert alert-info mb-4"></div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="passenger_name" class="form-label">Nama Penumpang *</label>
                                <input type="text" class="form-control" id="passenger_name" name="passenger_name" 
                                       value="<?php echo $_SESSION['full_name'] ?? ''; ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="passenger_phone" class="form-label">Nomor Telepon *</label>
                                <input type="tel" class="form-control" id="passenger_phone" name="passenger_phone" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="passenger_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="passenger_email" name="passenger_email">
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="seats_booked" class="form-label">Jumlah Kursi</label>
                                <select class="form-select" id="seats_booked" name="seats_booked">
                                    <option value="1">1 Kursi</option>
                                    <option value="2">2 Kursi</option>
                                    <option value="3">3 Kursi</option>
                                    <option value="4">4 Kursi</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Total Harga</label>
                                <div class="form-control" id="total_price">Rp 0</div>
                            </div>
                        </div>
                        
                        <!-- Payment Method Selection -->
                        <div class="mb-3">
                            <label class="form-label">Metode Pembayaran *</label>
                            <div class="row">
                                <div class="col-md-6 mb-2">
                                    <div class="payment-method-card" onclick="selectPaymentMethod('transfer_bca')">
                                        <input type="radio" name="payment_method" value="transfer_bca" id="transfer_bca" style="display: none;">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-university text-primary me-2"></i>
                                            <span>Transfer BCA</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="payment-method-card" onclick="selectPaymentMethod('transfer_bri')">
                                        <input type="radio" name="payment_method" value="transfer_bri" id="transfer_bri" style="display: none;">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-university text-primary me-2"></i>
                                            <span>Transfer BRI</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="payment-method-card" onclick="selectPaymentMethod('transfer_bni')">
                                        <input type="radio" name="payment_method" value="transfer_bni" id="transfer_bni" style="display: none;">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-university text-primary me-2"></i>
                                            <span>Transfer BNI</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="payment-method-card" onclick="selectPaymentMethod('qris')">
                                        <input type="radio" name="payment_method" value="qris" id="qris" style="display: none;">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-qrcode text-primary me-2"></i>
                                            <span>QRIS</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Payment Details -->
                        <div id="payment_details" class="mb-3" style="display: none;">
                            <div class="alert alert-warning">
                                <h6 class="alert-heading">Detail Pembayaran</h6>
                                <div id="payment_info"></div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="notes" class="form-label">Catatan Tambahan</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" id="confirm_booking_btn" disabled>
                            <i class="fas fa-check me-2"></i>Konfirmasi Booking
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const routes = <?php echo json_encode($routes); ?>;
        let selectedRoute = null;
        
        function selectRoute(routeId) {
            // Remove previous selection
            document.querySelectorAll('.route-card').forEach(card => {
                card.classList.remove('selected');
            });
            
            // Add selection to clicked card
            event.currentTarget.classList.add('selected');
            
            // Find route data
            selectedRoute = routes.find(route => route.id == routeId);
            
            if (selectedRoute) {
                // Update modal
                document.getElementById('modal_route_id').value = routeId;
                document.getElementById('route_details').innerHTML = `
                    <strong>${selectedRoute.company_name}</strong><br>
                    ${selectedRoute.from_city} → ${selectedRoute.to_city}<br>
                    ${selectedRoute.departure_time} - ${selectedRoute.arrival_time}<br>
                    ${selectedRoute.vehicle_type} | Rp ${parseInt(selectedRoute.price).toLocaleString('id-ID')}
                `;
                
                updateTotalPrice();
                
                // Show modal
                new bootstrap.Modal(document.getElementById('bookingModal')).show();
            }
        }
        
        function updateTotalPrice() {
            if (selectedRoute) {
                const seats = parseInt(document.getElementById('seats_booked').value);
                const total = selectedRoute.price * seats;
                document.getElementById('total_price').textContent = 'Rp ' + total.toLocaleString('id-ID');
            }
        }
        
        // Update price when seats change
        document.getElementById('seats_booked').addEventListener('change', updateTotalPrice);
        
        // Prevent same city selection
        document.getElementById('from').addEventListener('change', function() {
            const fromValue = this.value;
            const toSelect = document.getElementById('to');
            
            Array.from(toSelect.options).forEach(option => {
                option.disabled = option.value === fromValue;
            });
            
            if (toSelect.value === fromValue) {
                toSelect.value = '';
            }
        });
        
        document.getElementById('to').addEventListener('change', function() {
            const toValue = this.value;
            const fromSelect = document.getElementById('from');
            
            Array.from(fromSelect.options).forEach(option => {
                option.disabled = option.value === toValue;
            });
            
            if (fromSelect.value === toValue) {
                fromSelect.value = '';
            }
        });

        function selectPaymentMethod(method) {
            // Remove all selected classes
            document.querySelectorAll('.payment-method-card').forEach(card => {
                card.classList.remove('selected');
            });
            
            // Add selected class to clicked method
            event.currentTarget.classList.add('selected');
            
            // Check the radio button
            document.getElementById(method).checked = true;
            
            // Show payment details
            showPaymentDetails(method);
            
            // Enable confirm button
            document.getElementById('confirm_booking_btn').disabled = false;
        }
        
        function showPaymentDetails(method) {
            const paymentDetails = document.getElementById('payment_details');
            const paymentInfo = document.getElementById('payment_info');
            
            let info = '';
            
            switch(method) {
                case 'transfer_bca':
                    info = `
                        <strong>Bank BCA</strong><br>
                        No. Rekening: <strong>1234567890</strong><br>
                        Atas Nama: <strong>PT MayTravel Indonesia</strong><br>
                        <small class="text-muted">Transfer sesuai nominal yang tertera, lalu kirim bukti transfer ke WhatsApp kami</small>
                    `;
                    break;
                case 'transfer_bri':
                    info = `
                        <strong>Bank BRI</strong><br>
                        No. Rekening: <strong>0987654321</strong><br>
                        Atas Nama: <strong>PT MayTravel Indonesia</strong><br>
                        <small class="text-muted">Transfer sesuai nominal yang tertera, lalu kirim bukti transfer ke WhatsApp kami</small>
                    `;
                    break;
                case 'transfer_bni':
                    info = `
                        <strong>Bank BNI</strong><br>
                        No. Rekening: <strong>1122334455</strong><br>
                        Atas Nama: <strong>PT MayTravel Indonesia</strong><br>
                        <small class="text-muted">Transfer sesuai nominal yang tertera, lalu kirim bukti transfer ke WhatsApp kami</small>
                    `;
                    break;
                case 'qris':
                    info = `
                        <strong>Pembayaran QRIS</strong><br>
                        Scan QR Code yang akan dikirim setelah booking dikonfirmasi<br>
                        <small class="text-muted">QR Code berlaku selama 30 menit setelah booking</small>
                    `;
                    break;
            }
            
            paymentInfo.innerHTML = info;
            paymentDetails.style.display = 'block';
        }
    </script>
</body>
</html>
