<?php
require_once 'config/config.php';
require_once 'includes/booking.php';

// Require user login
if (!isset($_SESSION['user_id'])) {
    redirect('login.php');
}

$booking = new Booking();
$userBookings = $booking->getUserBookings($_SESSION['user_id']);

// Handle booking cancellation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_booking'])) {
    $result = $booking->cancelBooking($_POST['booking_id'], $_SESSION['user_id']);
    if ($result['success']) {
        $success = $result['message'];
        // Refresh bookings
        $userBookings = $booking->getUserBookings($_SESSION['user_id']);
    } else {
        $error = $result['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Dashboard Pengguna</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .dashboard-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
            transition: all 0.3s ease;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }
        .stat-card {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }
        .booking-card {
            border-left: 4px solid var(--secondary-blue);
            transition: all 0.3s ease;
        }
        .booking-card:hover {
            border-left-color: var(--primary-blue);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-confirmed { background: #d1fae5; color: #065f46; }
        .status-cancelled { background: #fee2e2; color: #991b1b; }
        .status-completed { background: #dbeafe; color: #1e40af; }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border: none;
            border-radius: 10px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(30, 64, 175, 0.3);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-car me-2"></i>MayTravel
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    <i class="fas fa-user me-1"></i>
                    Selamat datang, <?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?>
                </span>
                <a class="nav-link" href="booking.php">
                    <i class="fas fa-plus me-1"></i>Booking Baru
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-tachometer-alt me-2 text-primary"></i>Dashboard Pengguna</h2>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo count($userBookings); ?></div>
                    <div>Total Booking</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number">
                        <?php echo count(array_filter($userBookings, function($b) { return $b['status'] === 'confirmed'; })); ?>
                    </div>
                    <div>Terkonfirmasi</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number">
                        <?php echo count(array_filter($userBookings, function($b) { return $b['status'] === 'pending'; })); ?>
                    </div>
                    <div>Menunggu</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number">
                        <?php echo count(array_filter($userBookings, function($b) { return $b['status'] === 'completed'; })); ?>
                    </div>
                    <div>Selesai</div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="dashboard-card card p-4">
                    <h5 class="mb-3"><i class="fas fa-bolt me-2 text-primary"></i>Aksi Cepat</h5>
                    <div class="row">
                        <div class="col-md-4 mb-2">
                            <a href="booking.php" class="btn btn-primary w-100">
                                <i class="fas fa-plus me-2"></i>Booking Baru
                            </a>
                        </div>
                        <div class="col-md-4 mb-2">
                            <a href="#bookings" class="btn btn-outline-primary w-100">
                                <i class="fas fa-list me-2"></i>Lihat Semua Booking
                            </a>
                        </div>
                        <div class="col-md-4 mb-2">
                            <a href="contact-support.php" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-headset me-2"></i>Bantuan
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bookings List -->
        <div class="row" id="bookings">
            <div class="col-12">
                <div class="dashboard-card card">
                    <div class="card-header bg-transparent">
                        <h5 class="mb-0">
                            <i class="fas fa-ticket-alt me-2 text-primary"></i>Riwayat Booking
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($userBookings)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-ticket-alt fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Belum ada booking</h5>
                                <p class="text-muted">Mulai perjalanan Anda dengan membuat booking pertama</p>
                                <a href="booking.php" class="btn btn-primary">
                                    <i class="fas fa-plus me-2"></i>Booking Sekarang
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Kode Booking</th>
                                            <th>Rute</th>
                                            <th>Tanggal</th>
                                            <th>Waktu</th>
                                            <th>Agen</th>
                                            <th>Harga</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($userBookings as $bookingItem): ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo $bookingItem['booking_code']; ?></strong>
                                                </td>
                                                <td>
                                                    <?php echo $bookingItem['from_city']; ?> → <?php echo $bookingItem['to_city']; ?>
                                                    <br>
                                                    <small class="text-muted">
                                                        <i class="fas fa-car me-1"></i><?php echo $bookingItem['vehicle_type']; ?>
                                                        <span class="ms-2">
                                                            <i class="fas fa-users me-1"></i><?php echo $bookingItem['seats_booked']; ?> kursi
                                                        </span>
                                                    </small>
                                                </td>
                                                <td>
                                                    <?php echo date('d/m/Y', strtotime($bookingItem['travel_date'])); ?>
                                                </td>
                                                <td>
                                                    <?php echo date('H:i', strtotime($bookingItem['departure_time'])); ?> - 
                                                    <?php echo date('H:i', strtotime($bookingItem['arrival_time'])); ?>
                                                </td>
                                                <td>
                                                    <?php echo htmlspecialchars($bookingItem['company_name']); ?>
                                                    <br>
                                                    <small class="text-muted">
                                                        <i class="fas fa-phone me-1"></i><?php echo $bookingItem['contact_phone']; ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <strong>Rp <?php echo number_format($bookingItem['total_price'], 0, ',', '.'); ?></strong>
                                                </td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $bookingItem['status']; ?>">
                                                        <?php 
                                                        $statusLabels = [
                                                            'pending' => 'Menunggu',
                                                            'confirmed' => 'Terkonfirmasi',
                                                            'cancelled' => 'Dibatalkan',
                                                            'completed' => 'Selesai'
                                                        ];
                                                        echo $statusLabels[$bookingItem['status']] ?? $bookingItem['status'];
                                                        ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <button type="button" class="btn btn-outline-primary" 
                                                                onclick="showBookingDetails(<?php echo htmlspecialchars(json_encode($bookingItem)); ?>)">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <?php if ($bookingItem['status'] === 'pending'): ?>
                                                            <form method="POST" style="display: inline;" 
                                                                  onsubmit="return confirm('Yakin ingin membatalkan booking ini?')">
                                                                <input type="hidden" name="cancel_booking" value="1">
                                                                <input type="hidden" name="booking_id" value="<?php echo $bookingItem['id']; ?>">
                                                                <button type="submit" class="btn btn-outline-danger">
                                                                    <i class="fas fa-times"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Booking Details Modal -->
    <div class="modal fade" id="bookingDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-ticket-alt me-2"></i>Detail Booking
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="bookingDetailsContent">
                    <!-- Content will be populated by JavaScript -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showBookingDetails(booking) {
            const statusLabels = {
                'pending': 'Menunggu Konfirmasi',
                'confirmed': 'Terkonfirmasi',
                'cancelled': 'Dibatalkan',
                'completed': 'Selesai'
            };
            
            const content = `
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Booking</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Kode Booking:</strong></td><td>${booking.booking_code}</td></tr>
                            <tr><td><strong>Status:</strong></td><td><span class="status-badge status-${booking.status}">${statusLabels[booking.status]}</span></td></tr>
                            <tr><td><strong>Tanggal Booking:</strong></td><td>${new Date(booking.created_at).toLocaleDateString('id-ID')}</td></tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Perjalanan</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Rute:</strong></td><td>${booking.from_city} → ${booking.to_city}</td></tr>
                            <tr><td><strong>Tanggal:</strong></td><td>${new Date(booking.travel_date).toLocaleDateString('id-ID')}</td></tr>
                            <tr><td><strong>Waktu:</strong></td><td>${booking.departure_time} - ${booking.arrival_time}</td></tr>
                            <tr><td><strong>Kendaraan:</strong></td><td>${booking.vehicle_type}</td></tr>
                            <tr><td><strong>Kursi:</strong></td><td>${booking.seats_booked} kursi</td></tr>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Penumpang</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Nama:</strong></td><td>${booking.passenger_name}</td></tr>
                            <tr><td><strong>Telepon:</strong></td><td>${booking.passenger_phone}</td></tr>
                            ${booking.passenger_email ? `<tr><td><strong>Email:</strong></td><td>${booking.passenger_email}</td></tr>` : ''}
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Agen</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Nama:</strong></td><td>${booking.company_name}</td></tr>
                            <tr><td><strong>Telepon:</strong></td><td>${booking.contact_phone}</td></tr>
                        </table>
                        <h6 class="text-primary mt-3">Total Pembayaran</h6>
                        <h4 class="text-success">Rp ${parseInt(booking.total_price).toLocaleString('id-ID')}</h4>
                    </div>
                </div>
                ${booking.notes ? `
                <div class="row">
                    <div class="col-12">
                        <h6 class="text-primary">Catatan</h6>
                        <p class="text-muted">${booking.notes}</p>
                    </div>
                </div>
                ` : ''}
            `;
            
            document.getElementById('bookingDetailsContent').innerHTML = content;
            new bootstrap.Modal(document.getElementById('bookingDetailsModal')).show();
        }
    </script>
</body>
</html>
