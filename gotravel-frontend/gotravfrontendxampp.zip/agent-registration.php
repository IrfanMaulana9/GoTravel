<?php
require_once 'config/config.php';
require_once 'includes/auth.php';

$auth = new Auth();
$error = '';
$success = '';


if (isLoggedIn()) {
    redirect('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'username' => sanitize($_POST['username']),
        'email' => sanitize($_POST['email']),
        'password' => $_POST['password'],
        'company_name' => sanitize($_POST['company_name']),
        'business_type' => sanitize($_POST['business_type']),
        'contact_name' => sanitize($_POST['contact_name']),
        'contact_phone' => sanitize($_POST['contact_phone']),
        'business_license' => sanitize($_POST['business_license']),
        'establishment_year' => sanitize($_POST['establishment_year']),
        'fleet_size' => (int)$_POST['fleet_size'],
        'operating_cities' => $_POST['operating_cities'] ?? [],
        'vehicle_types' => $_POST['vehicle_types'] ?? []
    ];
    
    $result = $auth->registerAgent($data);
    
    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = $result['message'];
    }
}

$cities = ['Jakarta', 'Bandung', 'Surabaya', 'Yogyakarta', 'Semarang', 'Solo', 'Malang', 'Banyuwangi', 'Bogor', 'Madiun'];
$vehicleTypes = ['Minivan', 'SUV', 'Bus', 'Sedan', 'Hiace'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Daftar Agen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: linear-gradient(135deg, var(--primary-blue) 0%, var(--secondary-blue) 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 2rem 0;
        }
        .register-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            max-width: 800px;
            margin: 0 auto;
        }
        .register-header {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            padding: 2rem;
            text-align: center;
        }
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e2e8f0;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--secondary-blue);
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
        .btn-register {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border: none;
            border-radius: 10px;
            padding: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(30, 64, 175, 0.3);
        }
        .section-divider {
            border-top: 2px solid #e2e8f0;
            margin: 2rem 0 1.5rem;
            padding-top: 1.5rem;
            position: relative;
        }
        .section-divider::before {
            content: attr(data-title);
            position: absolute;
            top: -12px;
            left: 50%;
            transform: translateX(-50%);
            background: white;
            padding: 0 1rem;
            color: var(--primary-blue);
            font-weight: 600;
        }
        .checkbox-group {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 0.5rem;
        }
        .form-check {
            background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            padding: 0.75rem;
            transition: all 0.3s ease;
        }
        .form-check:hover {
            border-color: var(--secondary-blue);
            background: #dbeafe;
        }
        .form-check-input:checked + .form-check-label {
            color: var(--primary-blue);
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="register-card">
            <div class="register-header">
                <h2><i class="fas fa-building me-2"></i>Daftar Agen Travel</h2>
                <p class="mb-0">Bergabunglah dengan jaringan agen MayTravel</p>
            </div>
            <div class="p-4">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                        <div class="mt-2">
                            <a href="login.php" class="btn btn-success btn-sm">Login Sekarang</a>
                        </div>
                    </div>
                <?php else: ?>
                    <form method="POST">
                        <!-- Informasi Perusahaan -->
                        <div class="section-divider" data-title="Informasi Perusahaan"></div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="company_name" class="form-label">Nama Perusahaan *</label>
                                <input type="text" class="form-control" id="company_name" name="company_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="business_type" class="form-label">Jenis Usaha</label>
                                <select class="form-select" id="business_type" name="business_type">
                                    <option value="">Pilih jenis usaha</option>
                                    <option value="PT">Perseroan Terbatas (PT)</option>
                                    <option value="CV">Persekutuan Komanditer (CV)</option>
                                    <option value="UD">Usaha Dagang (UD)</option>
                                    <option value="Individual">Pemilik Tunggal</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="business_license" class="form-label">Nomor Izin Usaha</label>
                                <input type="text" class="form-control" id="business_license" name="business_license">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="establishment_year" class="form-label">Tahun Berdiri</label>
                                <input type="number" class="form-control" id="establishment_year" name="establishment_year" min="1900" max="2024">
                            </div>
                        </div>
                        
                        <!-- Informasi Kontak -->
                        <div class="section-divider" data-title="Informasi Kontak"></div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="contact_name" class="form-label">Nama Penanggung Jawab *</label>
                                <input type="text" class="form-control" id="contact_name" name="contact_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="contact_phone" class="form-label">Nomor Telepon *</label>
                                <input type="tel" class="form-control" id="contact_phone" name="contact_phone" required>
                            </div>
                        </div>
                        
                        <!-- Layanan Travel -->
                        <div class="section-divider" data-title="Layanan Travel"></div>
                        <div class="mb-3">
                            <label class="form-label">Jenis Kendaraan *</label>
                            <div class="checkbox-group">
                                <?php foreach ($vehicleTypes as $type): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="vehicle_types[]" value="<?php echo $type; ?>" id="vehicle_<?php echo $type; ?>">
                                        <label class="form-check-label" for="vehicle_<?php echo $type; ?>">
                                            <?php echo $type; ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Kota Beroperasi *</label>
                            <div class="checkbox-group">
                                <?php foreach ($cities as $city): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="operating_cities[]" value="<?php echo $city; ?>" id="city_<?php echo $city; ?>">
                                        <label class="form-check-label" for="city_<?php echo $city; ?>">
                                            <?php echo $city; ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="fleet_size" class="form-label">Jumlah Armada *</label>
                            <input type="number" class="form-control" id="fleet_size" name="fleet_size" min="1" required>
                        </div>
                        
                        <!-- Informasi Akun -->
                        <div class="section-divider" data-title="Informasi Akun"></div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="username" class="form-label">Username *</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Password *</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="password" name="password" required>
                                <button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">
                                    <i class="fas fa-eye" id="passwordToggle"></i>
                                </button>
                            </div>
                            <div class="form-text">Minimal 6 karakter</div>
                        </div>
                        
                        <button type="submit" class="btn btn-register btn-primary w-100 mb-3">
                            <i class="fas fa-building me-2"></i>Daftar Sebagai Agen
                        </button>
                    </form>
                <?php endif; ?>
                
                <div class="text-center">
                    <p class="mb-2">Sudah punya akun? <a href="login.php">Login di sini</a></p>
                    <p class="mb-2">Daftar sebagai pengguna? <a href="register.php">Daftar Pengguna</a></p>
                </div>
                
                <div class="text-center mt-3">
                    <a href="index.php" class="text-muted">
                        <i class="fas fa-arrow-left me-1"></i>Kembali ke Beranda
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const passwordToggle = document.getElementById('passwordToggle');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                passwordToggle.classList.remove('fa-eye');
                passwordToggle.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                passwordToggle.classList.remove('fa-eye-slash');
                passwordToggle.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
