<?php
require_once '../config/config.php';

// Check admin authentication
if (!isset($_SESSION['admin_logged_in'])) {
    redirect('index.php');
}

$db = getDB();
$error = '';
$success = '';

// Handle user actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_user_status'])) {
        try {
            $stmt = $db->prepare("UPDATE users SET status = ? WHERE id = ?");
            $stmt->execute([$_POST['status'], $_POST['user_id']]);
            $success = 'Status user berhasil diupdate';
        } catch (Exception $e) {
            $error = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    } elseif (isset($_POST['delete_user'])) {
        try {
            // Check if user has active bookings
            $stmt = $db->prepare("SELECT COUNT(*) as count FROM bookings WHERE user_id = ? AND status IN ('pending', 'confirmed')");
            $stmt->execute([$_POST['user_id']]);
            $activeBookings = $stmt->fetch()['count'];
            
            if ($activeBookings > 0) {
                $error = 'Tidak dapat menghapus user yang memiliki booking aktif';
            } else {
                $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$_POST['user_id']]);
                $success = 'User berhasil dihapus';
            }
        } catch (Exception $e) {
            $error = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    }
}

// Get all users with booking statistics - Fixed the undefined key issue
try {
    $stmt = $db->query("
        SELECT u.*, 
               COUNT(b.id) as total_bookings,
               COALESCE(SUM(CASE WHEN b.status IN ('confirmed', 'completed') THEN b.total_price ELSE 0 END), 0) as total_spent,
               MAX(b.created_at) as last_booking
        FROM users u
        LEFT JOIN bookings b ON u.id = b.user_id
        GROUP BY u.id
        ORDER BY u.created_at DESC
    ");
    $users = $stmt->fetchAll();
} catch (Exception $e) {
    $users = [];
}

// Calculate statistics
$totalUsers = count($users);
$activeUsers = count(array_filter($users, function($u) { return $u['status'] === 'active'; }));
$inactiveUsers = count(array_filter($users, function($u) { return $u['status'] === 'inactive'; }));
$suspendedUsers = count(array_filter($users, function($u) { return $u['status'] === 'suspended'; }));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Kelola User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
        }
        .stat-card {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
        }
        .stat-card.success {
            background: linear-gradient(135deg, #10b981, #059669);
        }
        .stat-card.warning {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }
        .stat-card.danger {
            background: linear-gradient(135deg, #ef4444, #dc2626);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-active { background: #d1fae5; color: #065f46; }
        .status-inactive { background: #fee2e2; color: #991b1b; }
        .status-suspended { background: #e5e7eb; color: #374151; }
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-car me-2"></i>MayTravel Admin
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
                <a class="nav-link" href="agents.php">
                    <i class="fas fa-building me-1"></i>Kelola Agen
                </a>
                <a class="nav-link active" href="users.php">
                    <i class="fas fa-users me-1"></i>Kelola User
                </a>
                <a class="nav-link" href="bookings.php">
                    <i class="fas fa-ticket-alt me-1"></i>Kelola Booking
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-users me-2 text-primary"></i>Kelola User</h2>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalUsers; ?></div>
                    <div>Total User</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card success">
                    <div class="stat-number"><?php echo $activeUsers; ?></div>
                    <div>Aktif</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card warning">
                    <div class="stat-number"><?php echo $inactiveUsers; ?></div>
                    <div>Tidak Aktif</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card danger">
                    <div class="stat-number"><?php echo $suspendedUsers; ?></div>
                    <div>Ditangguhkan</div>
                </div>
            </div>
        </div>

        <!-- Users List -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2 text-primary"></i>Daftar User
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($users)): ?>
                            <div class="text-center py-3">
                                <p class="text-muted">Belum ada user terdaftar</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Kontak</th>
                                            <th>Statistik Booking</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($users as $user): ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="user-avatar me-3">
                                                            <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                                                        </div>
                                                        <div>
                                                            <strong><?php echo htmlspecialchars($user['full_name']); ?></strong>
                                                            <br>
                                                            <small class="text-muted">
                                                                Bergabung: <?php echo date('d/m/Y', strtotime($user['created_at'])); ?>
                                                            </small>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <small class="text-muted">
                                                        <i class="fas fa-envelope me-1"></i><?php echo htmlspecialchars($user['email']); ?>
                                                    </small>
                                                    <?php if (!empty($user['phone'])): ?>
                                                        <br>
                                                        <small class="text-muted">
                                                            <i class="fas fa-phone me-1"></i><?php echo htmlspecialchars($user['phone']); ?>
                                                        </small>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <small class="text-muted">
                                                        <i class="fas fa-ticket-alt me-1"></i><?php echo $user['total_bookings']; ?> booking<br>
                                                        <i class="fas fa-money-bill-wave me-1"></i>Rp <?php echo number_format($user['total_spent'], 0, ',', '.'); ?><br>
                                                        <?php if ($user['last_booking']): ?>
                                                            <i class="fas fa-clock me-1"></i>Terakhir: <?php echo date('d/m/Y', strtotime($user['last_booking'])); ?>
                                                        <?php else: ?>
                                                            <i class="fas fa-clock me-1"></i>Belum pernah booking
                                                        <?php endif; ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $user['status']; ?>">
                                                        <?php 
                                                        $statusLabels = [
                                                            'active' => 'Aktif',
                                                            'inactive' => 'Tidak Aktif',
                                                            'suspended' => 'Ditangguhkan'
                                                        ];
                                                        echo $statusLabels[$user['status']] ?? $user['status'];
                                                        ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <button type="button" class="btn btn-outline-primary" 
                                                                onclick="showUserDetails(<?php echo htmlspecialchars(json_encode($user)); ?>)">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <div class="dropdown">
                                                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                                <i class="fas fa-edit"></i>
                                                            </button>
                                                            <ul class="dropdown-menu">
                                                                <li><a class="dropdown-item" href="#" onclick="updateUserStatus(<?php echo $user['id']; ?>, 'active')">Aktifkan</a></li>
                                                                <li><a class="dropdown-item" href="#" onclick="updateUserStatus(<?php echo $user['id']; ?>, 'inactive')">Nonaktifkan</a></li>
                                                                <li><a class="dropdown-item text-warning" href="#" onclick="updateUserStatus(<?php echo $user['id']; ?>, 'suspended')">Tangguhkan</a></li>
                                                                <li><hr class="dropdown-divider"></li>
                                                                <li><a class="dropdown-item text-danger" href="#" onclick="deleteUser(<?php echo $user['id']; ?>)">Hapus</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- User Details Modal -->
    <div class="modal fade" id="userDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-user me-2"></i>Detail User
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="userDetailsContent">
                    <!-- Content will be populated by JavaScript -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Hidden Forms -->
    <form id="statusUpdateForm" method="POST" style="display: none;">
        <input type="hidden" name="update_user_status" value="1">
        <input type="hidden" name="user_id" id="statusUserId">
        <input type="hidden" name="status" id="statusValue">
    </form>

    <form id="deleteUserForm" method="POST" style="display: none;">
        <input type="hidden" name="delete_user" value="1">
        <input type="hidden" name="user_id" id="deleteUserId">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showUserDetails(user) {
            const statusLabels = {
                'active': 'Aktif',
                'inactive': 'Tidak Aktif',
                'suspended': 'Ditangguhkan'
            };
            
            const content = `
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Personal</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Nama Lengkap:</strong></td><td>${user.full_name}</td></tr>
                            <tr><td><strong>Email:</strong></td><td>${user.email}</td></tr>
                            <tr><td><strong>Telepon:</strong></td><td>${user.phone || 'N/A'}</td></tr>
                            <tr><td><strong>Status:</strong></td><td><span class="status-badge status-${user.status}">${statusLabels[user.status]}</span></td></tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Akun</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Tanggal Daftar:</strong></td><td>${new Date(user.created_at).toLocaleDateString('id-ID')}</td></tr>
                            <tr><td><strong>Terakhir Update:</strong></td><td>${new Date(user.updated_at).toLocaleDateString('id-ID')}</td></tr>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <h6 class="text-primary">Statistik Booking</h6>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="text-center p-3 bg-light rounded">
                                    <h4 class="text-primary">${user.total_bookings}</h4>
                                    <small class="text-muted">Total Booking</small>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="text-center p-3 bg-light rounded">
                                    <h4 class="text-success">Rp ${parseInt(user.total_spent).toLocaleString('id-ID')}</h4>
                                    <small class="text-muted">Total Pengeluaran</small>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="text-center p-3 bg-light rounded">
                                    <h4 class="text-info">${user.last_booking ? new Date(user.last_booking).toLocaleDateString('id-ID') : 'N/A'}</h4>
                                    <small class="text-muted">Booking Terakhir</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            document.getElementById('userDetailsContent').innerHTML = content;
            new bootstrap.Modal(document.getElementById('userDetailsModal')).show();
        }
        
        function updateUserStatus(userId, status) {
            const statusLabels = {
                'active': 'mengaktifkan',
                'inactive': 'menonaktifkan',
                'suspended': 'menangguhkan'
            };
            
            if (confirm(`Yakin ingin ${statusLabels[status]} user ini?`)) {
                document.getElementById('statusUserId').value = userId;
                document.getElementById('statusValue').value = status;
                document.getElementById('statusUpdateForm').submit();
            }
        }
        
        function deleteUser(userId) {
            if (confirm('Yakin ingin menghapus user ini? Tindakan ini tidak dapat dibatalkan!')) {
                document.getElementById('deleteUserId').value = userId;
                document.getElementById('deleteUserForm').submit();
            }
        }
    </script>
</body>
</html>
