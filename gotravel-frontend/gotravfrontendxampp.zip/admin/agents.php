<?php
require_once '../config/config.php';

// Check admin authentication
if (!isset($_SESSION['admin_logged_in'])) {
    redirect('index.php');
}

$db = getDB();
$error = '';
$success = '';

// Handle agent actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_agent_status'])) {
        try {
            $stmt = $db->prepare("UPDATE agents SET status = ? WHERE id = ?");
            $stmt->execute([$_POST['status'], $_POST['agent_id']]);
            $success = 'Status agen berhasil diupdate';
        } catch (Exception $e) {
            $error = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    } elseif (isset($_POST['delete_agent'])) {
        try {
            // Check if agent has active bookings
            $stmt = $db->prepare("SELECT COUNT(*) as count FROM bookings WHERE agent_id = ? AND status IN ('pending', 'confirmed')");
            $stmt->execute([$_POST['agent_id']]);
            $activeBookings = $stmt->fetch()['count'];
            
            if ($activeBookings > 0) {
                $error = 'Tidak dapat menghapus agen yang memiliki booking aktif';
            } else {
                $stmt = $db->prepare("DELETE FROM agents WHERE id = ?");
                $stmt->execute([$_POST['agent_id']]);
                $success = 'Agen berhasil dihapus';
            }
        } catch (Exception $e) {
            $error = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    }
}

// Get all agents
try {
    $stmt = $db->query("
        SELECT a.*, 
               COUNT(r.id) as total_routes,
               COUNT(b.id) as total_bookings,
               COALESCE(SUM(CASE WHEN b.status IN ('confirmed', 'completed') THEN b.total_price ELSE 0 END), 0) as total_revenue
        FROM agents a
        LEFT JOIN routes r ON a.id = r.agent_id
        LEFT JOIN bookings b ON a.id = b.agent_id
        GROUP BY a.id
        ORDER BY a.created_at DESC
    ");
    $agents = $stmt->fetchAll();
} catch (Exception $e) {
    $agents = [];
}

// Calculate statistics
$totalAgents = count($agents);
$approvedAgents = count(array_filter($agents, function($a) { return $a['status'] === 'approved'; }));
$pendingAgents = count(array_filter($agents, function($a) { return $a['status'] === 'pending'; }));
$rejectedAgents = count(array_filter($agents, function($a) { return $a['status'] === 'rejected'; }));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Kelola Agen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
        }
        .stat-card {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
        }
        .stat-card.warning {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }
        .stat-card.success {
            background: linear-gradient(135deg, #10b981, #059669);
        }
        .stat-card.danger {
            background: linear-gradient(135deg, #ef4444, #dc2626);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-approved { background: #d1fae5; color: #065f46; }
        .status-rejected { background: #fee2e2; color: #991b1b; }
        .status-suspended { background: #e5e7eb; color: #374151; }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-car me-2"></i>MayTravel Admin
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
                <a class="nav-link active" href="agents.php">
                    <i class="fas fa-building me-1"></i>Kelola Agen
                </a>
                <a class="nav-link" href="users.php">
                    <i class="fas fa-users me-1"></i>Kelola User
                </a>
                <a class="nav-link" href="bookings.php">
                    <i class="fas fa-ticket-alt me-1"></i>Kelola Booking
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-building me-2 text-primary"></i>Kelola Agen</h2>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalAgents; ?></div>
                    <div>Total Agen</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card success">
                    <div class="stat-number"><?php echo $approvedAgents; ?></div>
                    <div>Disetujui</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card warning">
                    <div class="stat-number"><?php echo $pendingAgents; ?></div>
                    <div>Menunggu</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card danger">
                    <div class="stat-number"><?php echo $rejectedAgents; ?></div>
                    <div>Ditolak</div>
                </div>
            </div>
        </div>

        <!-- Agents List -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2 text-primary"></i>Daftar Agen
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($agents)): ?>
                            <div class="text-center py-3">
                                <p class="text-muted">Belum ada agen terdaftar</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Perusahaan</th>
                                            <th>Kontak</th>
                                            <th>Statistik</th>
                                            <th>Tanggal Daftar</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($agents as $agent): ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($agent['company_name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        <?php echo htmlspecialchars($agent['business_type'] ?? 'N/A'); ?>
                                                    </small>
                                                    <?php if (!empty($agent['company_address'])): ?>
                                                        <br>
                                                        <small class="text-muted">
                                                            <i class="fas fa-map-marker-alt me-1"></i>
                                                            <?php echo htmlspecialchars($agent['company_address']); ?>
                                                        </small>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($agent['contact_name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        <i class="fas fa-envelope me-1"></i><?php echo htmlspecialchars($agent['email']); ?>
                                                    </small>
                                                    <br>
                                                    <small class="text-muted">
                                                        <i class="fas fa-phone me-1"></i><?php echo htmlspecialchars($agent['contact_phone']); ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <small class="text-muted">
                                                        <i class="fas fa-route me-1"></i><?php echo $agent['total_routes']; ?> rute<br>
                                                        <i class="fas fa-ticket-alt me-1"></i><?php echo $agent['total_bookings']; ?> booking<br>
                                                        <i class="fas fa-money-bill-wave me-1"></i>Rp <?php echo number_format($agent['total_revenue'], 0, ',', '.'); ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <?php echo date('d/m/Y', strtotime($agent['created_at'])); ?>
                                                    <br>
                                                    <small class="text-muted">
                                                        <?php echo date('H:i', strtotime($agent['created_at'])); ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $agent['status']; ?>">
                                                        <?php 
                                                        $statusLabels = [
                                                            'pending' => 'Menunggu',
                                                            'approved' => 'Disetujui',
                                                            'rejected' => 'Ditolak',
                                                            'suspended' => 'Ditangguhkan'
                                                        ];
                                                        echo $statusLabels[$agent['status']] ?? $agent['status'];
                                                        ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <button type="button" class="btn btn-outline-primary" 
                                                                onclick="showAgentDetails(<?php echo htmlspecialchars(json_encode($agent)); ?>)">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <div class="dropdown">
                                                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                                <i class="fas fa-edit"></i>
                                                            </button>
                                                            <ul class="dropdown-menu">
                                                                <li><a class="dropdown-item" href="#" onclick="updateAgentStatus(<?php echo $agent['id']; ?>, 'approved')">Setujui</a></li>
                                                                <li><a class="dropdown-item" href="#" onclick="updateAgentStatus(<?php echo $agent['id']; ?>, 'pending')">Pending</a></li>
                                                                <li><a class="dropdown-item" href="#" onclick="updateAgentStatus(<?php echo $agent['id']; ?>, 'suspended')">Tangguhkan</a></li>
                                                                <li><a class="dropdown-item text-warning" href="#" onclick="updateAgentStatus(<?php echo $agent['id']; ?>, 'rejected')">Tolak</a></li>
                                                                <li><hr class="dropdown-divider"></li>
                                                                <li><a class="dropdown-item text-danger" href="#" onclick="deleteAgent(<?php echo $agent['id']; ?>)">Hapus</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Agent Details Modal -->
    <div class="modal fade" id="agentDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-building me-2"></i>Detail Agen
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="agentDetailsContent">
                    <!-- Content will be populated by JavaScript -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Hidden Forms -->
    <form id="statusUpdateForm" method="POST" style="display: none;">
        <input type="hidden" name="update_agent_status" value="1">
        <input type="hidden" name="agent_id" id="statusAgentId">
        <input type="hidden" name="status" id="statusValue">
    </form>

    <form id="deleteAgentForm" method="POST" style="display: none;">
        <input type="hidden" name="delete_agent" value="1">
        <input type="hidden" name="agent_id" id="deleteAgentId">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showAgentDetails(agent) {
            const statusLabels = {
                'pending': 'Menunggu Persetujuan',
                'approved': 'Disetujui',
                'rejected': 'Ditolak',
                'suspended': 'Ditangguhkan'
            };
            
            const content = `
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Perusahaan</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Nama Perusahaan:</strong></td><td>${agent.company_name}</td></tr>
                            <tr><td><strong>Jenis Bisnis:</strong></td><td>${agent.business_type || 'N/A'}</td></tr>
                            <tr><td><strong>Alamat:</strong></td><td>${agent.company_address || 'N/A'}</td></tr>
                            <tr><td><strong>Status:</strong></td><td><span class="status-badge status-${agent.status}">${statusLabels[agent.status]}</span></td></tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Kontak</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Nama Kontak:</strong></td><td>${agent.contact_name}</td></tr>
                            <tr><td><strong>Email:</strong></td><td>${agent.email}</td></tr>
                            <tr><td><strong>Telepon:</strong></td><td>${agent.contact_phone}</td></tr>
                            <tr><td><strong>Tanggal Daftar:</strong></td><td>${new Date(agent.created_at).toLocaleDateString('id-ID')}</td></tr>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <h6 class="text-primary">Statistik</h6>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="text-center p-3 bg-light rounded">
                                    <h4 class="text-primary">${agent.total_routes}</h4>
                                    <small class="text-muted">Total Rute</small>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="text-center p-3 bg-light rounded">
                                    <h4 class="text-success">${agent.total_bookings}</h4>
                                    <small class="text-muted">Total Booking</small>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="text-center p-3 bg-light rounded">
                                    <h4 class="text-info">Rp ${parseInt(agent.total_revenue).toLocaleString('id-ID')}</h4>
                                    <small class="text-muted">Total Revenue</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            document.getElementById('agentDetailsContent').innerHTML = content;
            new bootstrap.Modal(document.getElementById('agentDetailsModal')).show();
        }
        
        function updateAgentStatus(agentId, status) {
            const statusLabels = {
                'approved': 'menyetujui',
                'pending': 'mengembalikan ke pending',
                'suspended': 'menangguhkan',
                'rejected': 'menolak'
            };
            
            if (confirm(`Yakin ingin ${statusLabels[status]} agen ini?`)) {
                document.getElementById('statusAgentId').value = agentId;
                document.getElementById('statusValue').value = status;
                document.getElementById('statusUpdateForm').submit();
            }
        }
        
        function deleteAgent(agentId) {
            if (confirm('Yakin ingin menghapus agen ini? Tindakan ini tidak dapat dibatalkan!')) {
                document.getElementById('deleteAgentId').value = agentId;
                document.getElementById('deleteAgentForm').submit();
            }
        }
    </script>
</body>
</html>
