<?php
require_once '../config/config.php';

// Destroy admin session
if (isset($_SESSION['admin_logged_in'])) {
    unset($_SESSION['admin_logged_in']);
    unset($_SESSION['admin_username']);
}

// Destroy entire session if no other user is logged in
if (!isset($_SESSION['user_id']) && !isset($_SESSION['agent_id'])) {
    session_destroy();
}

redirect('index.php');
?>
