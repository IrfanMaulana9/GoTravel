<?php
require_once '../config/config.php';

// Check admin authentication
if (!isset($_SESSION['admin_logged_in'])) {
    redirect('index.php');
}

$db = getDB();

// Get statistics
try {
    $stmt = $db->query("SELECT COUNT(*) as total_users FROM users");
    $totalUsers = $stmt->fetch()['total_users'];
    
    $stmt = $db->query("SELECT COUNT(*) as total_agents FROM agents");
    $totalAgents = $stmt->fetch()['total_agents'];
    
    $stmt = $db->query("SELECT COUNT(*) as pending_agents FROM agents WHERE status = 'pending'");
    $pendingAgents = $stmt->fetch()['pending_agents'];
    
    $stmt = $db->query("SELECT COUNT(*) as total_bookings FROM bookings");
    $totalBookings = $stmt->fetch()['total_bookings'];
    
    $stmt = $db->query("SELECT COUNT(*) as total_routes FROM routes");
    $totalRoutes = $stmt->fetch()['total_routes'];
} catch (Exception $e) {
    $totalUsers = $totalAgents = $pendingAgents = $totalBookings = $totalRoutes = 0;
}

// Handle agent approval
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_agent'])) {
    try {
        $stmt = $db->prepare("UPDATE agents SET status = ? WHERE id = ?");
        $stmt->execute([$_POST['status'], $_POST['agent_id']]);
        $success = 'Status agen berhasil diupdate';
    } catch (Exception $e) {
        $error = 'Terjadi kesalahan: ' . $e->getMessage();
    }
}

// Get pending agents
try {
    $stmt = $db->query("
        SELECT * FROM agents 
        WHERE status = 'pending' 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    $pendingAgentsList = $stmt->fetchAll();
} catch (Exception $e) {
    $pendingAgentsList = [];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
        }
        .stat-card {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
        }
        .stat-card.warning {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }
        .stat-card.success {
            background: linear-gradient(135deg, #10b981, #059669);
        }
        .stat-card.info {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-car me-2"></i>MayTravel Admin
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    <i class="fas fa-user-shield me-1"></i>
                    Admin: <?php echo $_SESSION['admin_username'] ?? 'Administrator'; ?>
                </span>
                <a class="nav-link" href="agents.php">
                    <i class="fas fa-building me-1"></i>Kelola Agen
                </a>
                <a class="nav-link" href="users.php">
                    <i class="fas fa-users me-1"></i>Kelola User
                </a>
                <a class="nav-link" href="bookings.php">
                    <i class="fas fa-ticket-alt me-1"></i>Kelola Booking
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-tachometer-alt me-2 text-primary"></i>Admin Dashboard</h2>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalUsers; ?></div>
                    <div>Total Users</div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                <div class="stat-card success">
                    <div class="stat-number"><?php echo $totalAgents; ?></div>
                    <div>Total Agen</div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                <div class="stat-card warning">
                    <div class="stat-number"><?php echo $pendingAgents; ?></div>
                    <div>Agen Pending</div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                <div class="stat-card info">
                    <div class="stat-number"><?php echo $totalBookings; ?></div>
                    <div>Total Booking</div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalRoutes; ?></div>
                    <div>Total Rute</div>
                </div>
            </div>
        </div>

        <!-- Pending Agents -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-clock me-2 text-primary"></i>Agen Menunggu Persetujuan
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($pendingAgentsList)): ?>
                            <div class="text-center py-3">
                                <p class="text-muted">Tidak ada agen yang menunggu persetujuan</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Perusahaan</th>
                                            <th>Penanggung Jawab</th>
                                            <th>Email</th>
                                            <th>Telepon</th>
                                            <th>Tanggal Daftar</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($pendingAgentsList as $agent): ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($agent['company_name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($agent['business_type'] ?? 'N/A'); ?></small>
                                                </td>
                                                <td><?php echo htmlspecialchars($agent['contact_name']); ?></td>
                                                <td><?php echo htmlspecialchars($agent['email']); ?></td>
                                                <td><?php echo htmlspecialchars($agent['contact_phone']); ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($agent['created_at'])); ?></td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <form method="POST" style="display: inline;">
                                                            <input type="hidden" name="approve_agent" value="1">
                                                            <input type="hidden" name="agent_id" value="<?php echo $agent['id']; ?>">
                                                            <input type="hidden" name="status" value="approved">
                                                            <button type="submit" class="btn btn-success" onclick="return confirm('Setujui agen ini?')">
                                                                <i class="fas fa-check"></i>
                                                            </button>
                                                        </form>
                                                        <form method="POST" style="display: inline;">
                                                            <input type="hidden" name="approve_agent" value="1">
                                                            <input type="hidden" name="agent_id" value="<?php echo $agent['id']; ?>">
                                                            <input type="hidden" name="status" value="rejected">
                                                            <button type="submit" class="btn btn-danger" onclick="return confirm('Tolak agen ini?')">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
