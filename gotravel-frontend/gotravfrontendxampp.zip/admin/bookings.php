<?php
require_once '../config/config.php';

// Check admin authentication
if (!isset($_SESSION['admin_logged_in'])) {
    redirect('index.php');
}

$db = getDB();

// Handle booking status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_booking'])) {
    try {
        $stmt = $db->prepare("UPDATE bookings SET status = ? WHERE id = ?");
        $stmt->execute([$_POST['status'], $_POST['booking_id']]);
        $success = 'Status booking berhasil diupdate';
    } catch (Exception $e) {
        $error = 'Terjadi kesalahan: ' . $e->getMessage();
    }
}

// Get all bookings with details
try {
    $stmt = $db->query("
        SELECT b.*, r.from_city, r.to_city, r.departure_time, r.arrival_time, 
               r.vehicle_type, a.company_name, u.full_name as user_name
        FROM bookings b
        LEFT JOIN routes r ON b.route_id = r.id
        LEFT JOIN agents a ON b.agent_id = a.id
        LEFT JOIN users u ON b.user_id = u.id
        ORDER BY b.created_at DESC
    ");
    $allBookings = $stmt->fetchAll();
} catch (Exception $e) {
    $allBookings = [];
}

// Calculate statistics
$totalBookings = count($allBookings);
$pendingBookings = count(array_filter($allBookings, function($b) { return $b['status'] === 'pending'; }));
$confirmedBookings = count(array_filter($allBookings, function($b) { return $b['status'] === 'confirmed'; }));
$totalRevenue = array_sum(array_map(function($b) { 
    return $b['status'] === 'confirmed' || $b['status'] === 'completed' ? $b['total_price'] : 0; 
}, $allBookings));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Kelola Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
        }
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
        }
        .stat-card {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
        }
        .stat-card.warning {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }
        .stat-card.success {
            background: linear-gradient(135deg, #10b981, #059669);
        }
        .stat-card.info {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-confirmed { background: #d1fae5; color: #065f46; }
        .status-cancelled { background: #fee2e2; color: #991b1b; }
        .status-completed { background: #dbeafe; color: #1e40af; }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-car me-2"></i>MayTravel Admin
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
                <a class="nav-link" href="agents.php">
                    <i class="fas fa-building me-1"></i>Kelola Agen
                </a>
                <a class="nav-link" href="users.php">
                    <i class="fas fa-users me-1"></i>Kelola User
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-ticket-alt me-2 text-primary"></i>Kelola Booking</h2>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalBookings; ?></div>
                    <div>Total Booking</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card warning">
                    <div class="stat-number"><?php echo $pendingBookings; ?></div>
                    <div>Menunggu</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card success">
                    <div class="stat-number"><?php echo $confirmedBookings; ?></div>
                    <div>Terkonfirmasi</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stat-card info">
                    <div class="stat-number">Rp <?php echo number_format($totalRevenue / 1000000, 1); ?>M</div>
                    <div>Total Revenue</div>
                </div>
            </div>
        </div>

        <!-- Bookings List -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2 text-primary"></i>Semua Booking
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($allBookings)): ?>
                            <div class="text-center py-3">
                                <p class="text-muted">Belum ada booking</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Kode Booking</th>
                                            <th>Penumpang</th>
                                            <th>Rute</th>
                                            <th>Tanggal</th>
                                            <th>Agen</th>
                                            <th>Total</th>
                                            <th>Pembayaran</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($allBookings as $booking): ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo $booking['booking_code']; ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        <?php echo date('d/m/Y H:i', strtotime($booking['created_at'])); ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($booking['passenger_name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        <i class="fas fa-phone me-1"></i><?php echo $booking['passenger_phone']; ?>
                                                    </small>
                                                    <?php if ($booking['user_name']): ?>
                                                        <br><small class="text-muted">User: <?php echo $booking['user_name']; ?></small>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php echo $booking['from_city']; ?> → <?php echo $booking['to_city']; ?>
                                                    <br>
                                                    <small class="text-muted">
                                                        <i class="fas fa-car me-1"></i><?php echo $booking['vehicle_type']; ?>
                                                        <span class="ms-2">
                                                            <i class="fas fa-users me-1"></i><?php echo $booking['seats_booked']; ?> kursi
                                                        </span>
                                                    </small>
                                                </td>
                                                <td>
                                                    <?php echo date('d/m/Y', strtotime($booking['travel_date'])); ?>
                                                    <br>
                                                    <small class="text-muted">
                                                        <?php echo date('H:i', strtotime($booking['departure_time'])); ?> - 
                                                        <?php echo date('H:i', strtotime($booking['arrival_time'])); ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <?php echo htmlspecialchars($booking['company_name']); ?>
                                                </td>
                                                <td>
                                                    <strong>Rp <?php echo number_format($booking['total_price'], 0, ',', '.'); ?></strong>
                                                </td>
                                                <td>
                                                    <?php if ($booking['payment_method']): ?>
                                                        <span class="badge bg-info">
                                                            <?php 
                                                            $paymentLabels = [
                                                                'transfer_bca' => 'Transfer BCA',
                                                                'transfer_bri' => 'Transfer BRI', 
                                                                'transfer_bni' => 'Transfer BNI',
                                                                'qris' => 'QRIS'
                                                            ];
                                                            echo $paymentLabels[$booking['payment_method']] ?? $booking['payment_method'];
                                                            ?>
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $booking['status']; ?>">
                                                        <?php 
                                                        $statusLabels = [
                                                            'pending' => 'Menunggu',
                                                            'confirmed' => 'Terkonfirmasi',
                                                            'cancelled' => 'Dibatalkan',
                                                            'completed' => 'Selesai'
                                                        ];
                                                        echo $statusLabels[$booking['status']] ?? $booking['status'];
                                                        ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <button type="button" class="btn btn-outline-primary" 
                                                                onclick="showBookingDetails(<?php echo htmlspecialchars(json_encode($booking)); ?>)">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <?php if ($booking['status'] !== 'cancelled'): ?>
                                                            <div class="dropdown">
                                                                <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                                    <i class="fas fa-edit"></i>
                                                                </button>
                                                                <ul class="dropdown-menu">
                                                                    <li><a class="dropdown-item" href="#" onclick="updateStatus(<?php echo $booking['id']; ?>, 'pending')">Pending</a></li>
                                                                    <li><a class="dropdown-item" href="#" onclick="updateStatus(<?php echo $booking['id']; ?>, 'confirmed')">Konfirmasi</a></li>
                                                                    <li><a class="dropdown-item" href="#" onclick="updateStatus(<?php echo $booking['id']; ?>, 'completed')">Selesai</a></li>
                                                                    <li><hr class="dropdown-divider"></li>
                                                                    <li><a class="dropdown-item text-danger" href="#" onclick="updateStatus(<?php echo $booking['id']; ?>, 'cancelled')">Batalkan</a></li>
                                                                </ul>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Booking Details Modal -->
    <div class="modal fade" id="bookingDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-ticket-alt me-2"></i>Detail Booking
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="bookingDetailsContent">
                    <!-- Content will be populated by JavaScript -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Status Update Form (Hidden) -->
    <form id="statusUpdateForm" method="POST" style="display: none;">
        <input type="hidden" name="update_booking" value="1">
        <input type="hidden" name="booking_id" id="statusBookingId">
        <input type="hidden" name="status" id="statusValue">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showBookingDetails(booking) {
            const statusLabels = {
                'pending': 'Menunggu Konfirmasi',
                'confirmed': 'Terkonfirmasi',
                'cancelled': 'Dibatalkan',
                'completed': 'Selesai'
            };
            
            const paymentLabels = {
                'transfer_bca': 'Transfer BCA',
                'transfer_bri': 'Transfer BRI',
                'transfer_bni': 'Transfer BNI',
                'qris': 'QRIS'
            };
            
            const content = `
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Booking</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Kode Booking:</strong></td><td>${booking.booking_code}</td></tr>
                            <tr><td><strong>Status:</strong></td><td><span class="status-badge status-${booking.status}">${statusLabels[booking.status]}</span></td></tr>
                            <tr><td><strong>Tanggal Booking:</strong></td><td>${new Date(booking.created_at).toLocaleDateString('id-ID')}</td></tr>
                            <tr><td><strong>Metode Pembayaran:</strong></td><td>${booking.payment_method ? paymentLabels[booking.payment_method] || booking.payment_method : '-'}</td></tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Perjalanan</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Rute:</strong></td><td>${booking.from_city} → ${booking.to_city}</td></tr>
                            <tr><td><strong>Tanggal:</strong></td><td>${new Date(booking.travel_date).toLocaleDateString('id-ID')}</td></tr>
                            <tr><td><strong>Waktu:</strong></td><td>${booking.departure_time} - ${booking.arrival_time}</td></tr>
                            <tr><td><strong>Kendaraan:</strong></td><td>${booking.vehicle_type}</td></tr>
                            <tr><td><strong>Kursi:</strong></td><td>${booking.seats_booked} kursi</td></tr>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Penumpang</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Nama:</strong></td><td>${booking.passenger_name}</td></tr>
                            <tr><td><strong>Telepon:</strong></td><td>${booking.passenger_phone}</td></tr>
                            ${booking.passenger_email ? `<tr><td><strong>Email:</strong></td><td>${booking.passenger_email}</td></tr>` : ''}
                            ${booking.user_name ? `<tr><td><strong>User:</strong></td><td>${booking.user_name}</td></tr>` : ''}
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-primary">Informasi Agen</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Perusahaan:</strong></td><td>${booking.company_name}</td></tr>
                        </table>
                        <h6 class="text-primary mt-3">Total Pembayaran</h6>
                        <h4 class="text-success">Rp ${parseInt(booking.total_price).toLocaleString('id-ID')}</h4>
                    </div>
                </div>
                ${booking.notes ? `
                <div class="row">
                    <div class="col-12">
                        <h6 class="text-primary">Catatan</h6>
                        <p class="text-muted">${booking.notes}</p>
                    </div>
                </div>
                ` : ''}
            `;
            
            document.getElementById('bookingDetailsContent').innerHTML = content;
            new bootstrap.Modal(document.getElementById('bookingDetailsModal')).show();
        }
        
        function updateStatus(bookingId, status) {
            const statusLabels = {
                'pending': 'mengembalikan ke pending',
                'confirmed': 'mengkonfirmasi',
                'cancelled': 'membatalkan',
                'completed': 'menyelesaikan'
            };
            
            if (confirm(`Yakin ingin ${statusLabels[status]} booking ini?`)) {
                document.getElementById('statusBookingId').value = bookingId;
                document.getElementById('statusValue').value = status;
                document.getElementById('statusUpdateForm').submit();
            }
        }
    </script>
</body>
</html>
