<?php
// api/cities.php
header('Content-Type: application/json');
require_once '../config/config.php';
require_once '../includes/booking.php';

$booking = new Booking();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $cities = $booking->getCities();
    
    echo json_encode([
        'success' => true,
        'data' => $cities
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
}
?>
