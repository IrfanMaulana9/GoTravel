<?php
// api/routes.php
header('Content-Type: application/json');
require_once '../config/config.php';
require_once '../includes/booking.php';

$booking = new Booking();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $fromCity = $_GET['from'] ?? null;
    $toCity = $_GET['to'] ?? null;
    $date = $_GET['date'] ?? null;
    
    $routes = $booking->getRoutes($fromCity, $toCity, $date);
    
    echo json_encode([
        'success' => true,
        'data' => $routes
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
}
?>
