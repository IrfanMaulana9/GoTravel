-- Buat database jika belum ada
CREATE DATABASE IF NOT EXISTS maytrav CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE maytrav;

-- Users table (for customers)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active'
);

-- Agents table (for travel agents)
CREATE TABLE IF NOT EXISTS agents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    company_name VARCHAR(100) NOT NULL,
    business_type VARCHAR(50),
    contact_name VARCHAR(100) NOT NULL,
    contact_phone VARCHAR(20),
    business_license VARCHAR(100),
    establishment_year YEAR,
    fleet_size INT DEFAULT 0,
    operating_cities TEXT,
    vehicle_types TEXT,
    status ENUM('pending', 'approved', 'rejected', 'suspended') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Routes table
CREATE TABLE IF NOT EXISTS routes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    agent_id INT NOT NULL,
    from_city VARCHAR(50) NOT NULL,
    to_city VARCHAR(50) NOT NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    vehicle_type VARCHAR(50) NOT NULL,
    seats_total INT NOT NULL,
    seats_available INT NOT NULL,
    description TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE
);

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_code VARCHAR(20) UNIQUE NOT NULL,
    user_id INT,
    route_id INT NOT NULL,
    agent_id INT NOT NULL,
    passenger_name VARCHAR(100) NOT NULL,
    passenger_phone VARCHAR(20) NOT NULL,
    passenger_email VARCHAR(100),
    travel_date DATE NOT NULL,
    seats_booked INT DEFAULT 1,
    total_price DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'refunded') DEFAULT 'pending',
    payment_method VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE,
    FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE
);

-- Payments table
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    payment_reference VARCHAR(100),
    status ENUM('pending', 'success', 'failed', 'refunded') DEFAULT 'pending',
    paid_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);

-- Hapus data lama jika ada
DELETE FROM payments;
DELETE FROM bookings;
DELETE FROM routes;
DELETE FROM agents;
DELETE FROM users;

-- Reset AUTO_INCREMENT
ALTER TABLE users AUTO_INCREMENT = 1;
ALTER TABLE agents AUTO_INCREMENT = 1;
ALTER TABLE routes AUTO_INCREMENT = 1;
ALTER TABLE bookings AUTO_INCREMENT = 1;
ALTER TABLE payments AUTO_INCREMENT = 1;

-- Insert sample users
-- Password untuk semua akun sample: password123
INSERT INTO users (username, email, password, full_name, phone) VALUES
('user1', 'user1@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ahmad Wijaya', '081234567892'),
('user2', 'user2@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Siti Nurhaliza', '081234567893'),
('testuser', 'test@user.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Test User', '081234567894');

-- Insert sample agents (SUDAH DISETUJUI)
INSERT INTO agents (username, email, password, company_name, business_type, contact_name, contact_phone, business_license, establishment_year, fleet_size, operating_cities, vehicle_types, status) VALUES
('agent1', 'agent1@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Travel Sejahtera', 'PT', 'John Doe', '081234567890', 'SIUP-001', 2020, 5, 'Jakarta,Bandung,Bogor', 'Minivan,SUV', 'approved'),
('agent2', 'agent2@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Nusantara Travel', 'CV', 'Jane Smith', '081234567891', 'SIUP-002', 2019, 8, 'Jakarta,Surabaya,Yogyakarta', 'Bus,Minivan', 'approved'),
('testagent', 'test@agent.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Test Travel Agency', 'UD', 'Test Agent', '081234567895', 'SIUP-003', 2021, 3, 'Jakarta,Bandung', 'Minivan', 'approved');

-- Insert sample routes
INSERT INTO routes (agent_id, from_city, to_city, departure_time, arrival_time, price, vehicle_type, seats_total, seats_available, description) VALUES
(1, 'Jakarta', 'Bandung', '08:00:00', '11:00:00', 75000, 'Minivan', 8, 8, 'Perjalanan nyaman Jakarta-Bandung dengan AC dan WiFi'),
(1, 'Bandung', 'Jakarta', '14:00:00', '17:00:00', 75000, 'Minivan', 8, 8, 'Perjalanan nyaman Bandung-Jakarta dengan AC dan WiFi'),
(1, 'Jakarta', 'Bogor', '09:00:00', '10:30:00', 35000, 'Minivan', 8, 8, 'Rute cepat Jakarta-Bogor'),
(2, 'Jakarta', 'Surabaya', '20:00:00', '06:00:00', 200000, 'Bus', 20, 20, 'Bus malam Jakarta-Surabaya dengan fasilitas lengkap'),
(2, 'Surabaya', 'Jakarta', '21:00:00', '07:00:00', 200000, 'Bus', 20, 20, 'Bus malam Surabaya-Jakarta dengan fasilitas lengkap'),
(2, 'Jakarta', 'Yogyakarta', '19:00:00', '05:00:00', 150000, 'Bus', 20, 20, 'Bus malam Jakarta-Yogyakarta'),
(3, 'Jakarta', 'Bandung', '10:00:00', '13:00:00', 80000, 'Minivan', 6, 6, 'Travel premium Jakarta-Bandung'),
(3, 'Bandung', 'Jakarta', '16:00:00', '19:00:00', 80000, 'Minivan', 6, 6, 'Travel premium Bandung-Jakarta');
