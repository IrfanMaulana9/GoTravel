<?php
require_once 'config/config.php';
require_once 'includes/auth.php';

$auth = new Auth();
$error = '';
$success = '';

// Redirect if already logged in
if (isLoggedIn()) {
    if (isset($_SESSION['user_id'])) {
        redirect('user-dashboard.php');
    } else {
        redirect('agent-dashboard.php');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    $loginType = $_POST['login_type'] ?? 'user';
    
    if ($loginType === 'agent') {
        $result = $auth->loginAgent($username, $password);
    } else {
        $result = $auth->loginUser($username, $password);
    }
    
    if ($result['success']) {
        redirect($result['redirect']);
    } else {
        $error = $result['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MayTravel - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1e40af;
            --secondary-blue: #3b82f6;
            --light-blue: #dbeafe;
        }
        body {
            background: linear-gradient(135deg, var(--primary-blue) 0%, var(--secondary-blue) 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 0;
        }
        .login-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            max-width: 400px;
            width: 100%;
        }
        .login-header {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            padding: 2rem;
            text-align: center;
        }
        .login-body {
            padding: 2rem;
        }
        .form-control {
            border-radius: 10px;
            border: 2px solid #e2e8f0;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: var(--secondary-blue);
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
        .btn-login {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border: none;
            border-radius: 10px;
            padding: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(30, 64, 175, 0.3);
        }
        .login-tabs {
            display: flex;
            margin-bottom: 1.5rem;
        }
        .login-tab {
            flex: 1;
            padding: 0.75rem;
            text-align: center;
            background: #f8fafc;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .login-tab.active {
            background: var(--secondary-blue);
            color: white;
        }
        .login-tab:first-child {
            border-radius: 10px 0 0 10px;
        }
        .login-tab:last-child {
            border-radius: 0 10px 10px 0;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <h2><i class="fas fa-car me-2"></i>MayTravel</h2>
                <p class="mb-0">Masuk ke akun Anda</p>
            </div>
            <div class="login-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="login-tabs">
                        <button type="button" class="login-tab active" onclick="switchTab('user')">
                            <i class="fas fa-user me-1"></i>Pengguna
                        </button>
                        <button type="button" class="login-tab" onclick="switchTab('agent')">
                            <i class="fas fa-building me-1"></i>Agen
                        </button>
                    </div>
                    
                    <input type="hidden" name="login_type" id="loginType" value="user">
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Username atau Email</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="password" name="password" required>
                            <button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">
                                <i class="fas fa-eye" id="passwordToggle"></i>
                            </button>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-login btn-primary w-100 mb-3">
                        <i class="fas fa-sign-in-alt me-2"></i>Masuk
                    </button>
                </form>
                
                <div class="text-center">
                    <p class="mb-2">Belum punya akun?</p>
                    <a href="register.php" class="btn btn-outline-primary me-2">Daftar Pengguna</a>
                    <a href="agent-registration.php" class="btn btn-outline-secondary">Daftar Agen</a>
                </div>
                
                <div class="text-center mt-3">
                    <a href="index.php" class="text-muted">
                        <i class="fas fa-arrow-left me-1"></i>Kembali ke Beranda
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function switchTab(type) {
            const tabs = document.querySelectorAll('.login-tab');
            tabs.forEach(tab => tab.classList.remove('active'));
            
            if (type === 'agent') {
                tabs[1].classList.add('active');
                document.getElementById('loginType').value = 'agent';
            } else {
                tabs[0].classList.add('active');
                document.getElementById('loginType').value = 'user';
            }
        }
        
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const passwordToggle = document.getElementById('passwordToggle');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                passwordToggle.classList.remove('fa-eye');
                passwordToggle.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                passwordToggle.classList.remove('fa-eye-slash');
                passwordToggle.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
